const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const BASE = __dirname;
const CFG = JSON.parse(fs.readFileSync(path.join(BASE, 'config_guardian.json'), 'utf8'));

const TIPOS = [
  { nome: 'Comportamento de Risco', arquivo: 'Guardian_Comportamento_Risco.xlsx' },
  { nome: 'Condição de Risco', arquivo: 'Guardian_Condicao_Risco.xlsx' },
  { nome: 'Incidente', arquivo: 'Guardian_Incidente.xlsx' },
  { nome: 'Reconhecimento', arquivo: 'Guardian_Reconhecimento.xlsx' },
];

const sleep = ms => new Promise(r => setTimeout(r, ms));
const log = m => console.log(`[${new Date().toLocaleTimeString('pt-BR')}] ${m}`);

function pad2(n){ return String(n).padStart(2,'0'); }
function periodoAtual(){
  const d = new Date();
  return {
    inicio: `01/${pad2(d.getMonth()+1)}/${d.getFullYear()}`,
    fim: `${pad2(d.getDate())}/${pad2(d.getMonth()+1)}/${d.getFullYear()}`
  };
}
function ensureDir(p){ fs.mkdirSync(p,{recursive:true}); }
function esperarEnter(){
  return new Promise(resolve=>{
    process.stdin.resume();
    process.stdin.once('data',()=>resolve());
  });
}

async function esperarGuardian(page){
  await page.goto(CFG.guardian_url,{waitUntil:'domcontentloaded',timeout:45000}).catch(()=>{});
  try{
    await page.getByText('Gerenciamento de Registros',{exact:false}).first().waitFor({timeout:12000});
  }catch{
    console.log('');
    console.log('Faça o login no Guardian normalmente.');
    console.log('Quando estiver em "Gerenciamento de Registros", volte aqui e pressione ENTER.');
    await esperarEnter();
    await page.goto(CFG.guardian_url,{waitUntil:'domcontentloaded',timeout:45000});
    await page.getByText('Gerenciamento de Registros',{exact:false}).first().waitFor({timeout:30000});
  }
}

async function limparFiltros(page){
  const b = page.getByRole('button',{name:/Limpar filtros/i}).first();
  if(await b.count()){
    if(await b.isEnabled().catch(()=>false)){
      await b.click({timeout:8000}).catch(()=>{});
      await sleep(600);
    }
  }
}

async function selecionarPeriodo(page){
  let sel = page.locator('[aria-label="Período de tempo requerido"]').first();
  if(!(await sel.count())){
    sel = page.locator('nz-select').filter({hasText:/Data em que o fato ocorreu|Período de tempo requerido/i}).first();
  }
  if(!(await sel.count())) throw new Error('Não encontrei o seletor "Período de tempo requerido".');

  const atual=(await sel.innerText().catch(()=>'' )).trim();
  if(/Data em que o fato ocorreu/i.test(atual)) return;

  await sel.click({timeout:10000});
  await sleep(400);
  let opt=page.locator('nz-option-item[title="Data em que o fato ocorreu"]').last();
  if(!(await opt.count())) opt=page.locator('.ant-select-item-option[title="Data em que o fato ocorreu"]').last();
  if(!(await opt.count())) opt=page.getByText('Data em que o fato ocorreu',{exact:true}).last();
  await opt.click({timeout:10000});
  await sleep(500);
}

async function setData(input,valor){
  await input.click({timeout:8000});
  await input.press('Control+A');
  await input.type(valor,{delay:35});
  await input.press('Tab');
  await sleep(300);

  const atual=await input.inputValue().catch(()=> '');
  if(atual!==valor){
    await input.evaluate((el,v)=>{
      const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
      setter.call(el,v);
      el.dispatchEvent(new Event('input',{bubbles:true}));
      el.dispatchEvent(new Event('change',{bubbles:true}));
      el.dispatchEvent(new Event('blur',{bubbles:true}));
    },valor);
    await sleep(300);
  }
}

async function preencherDatas(page,p){
  const ini=page.locator('input[placeholder="Data inicial"]').first();
  const fim=page.locator('input[placeholder="Data final"]').first();
  if(!(await ini.count()) || !(await fim.count())) throw new Error('Campos de data não encontrados.');
  await setData(ini,p.inicio);
  await setData(fim,p.fim);
}

async function selecionarTipo(page,tipo){
  let sel=page.locator('[data-testid="register-type-multi-select-component"]').first();
  if(!(await sel.count())) sel=page.locator('nz-select[aria-label="Tipo de registro"]').first();
  if(!(await sel.count())) throw new Error('Seletor "Tipo de registro" não encontrado.');

  const atual=(await sel.innerText().catch(()=>'' )).trim();
  if(atual.includes(tipo)) return;

  await sel.click({timeout:10000});
  await sleep(400);
  let opt=page.locator(`nz-option-item[title="${tipo}"]`).last();
  if(!(await opt.count())) opt=page.locator(`.ant-select-item-option[title="${tipo}"]`).last();
  if(!(await opt.count())) opt=page.getByText(tipo,{exact:true}).last();
  await opt.click({timeout:10000});
  await sleep(500);
}

function linhasDoTipo(page,item,p){
  return page.locator('tr')
    .filter({hasText:item.nome})
    .filter({hasText:p.inicio})
    .filter({hasText:p.fim});
}

async function procurarLinhaAtual(page,item,p){
  await page.goto(CFG.downloads_url || 'https://guardian.ab-inbev.com/downloads',
    {waitUntil:'domcontentloaded',timeout:45000}).catch(()=>{});
  await sleep(700);

  const rows=linhasDoTipo(page,item,p);
  const n=await rows.count();
  if(!n) return null;

  // O Guardian está exibindo os pedidos mais novos embaixo.
  return rows.nth(n-1);
}

async function linhaExiste(page,item,p){
  const row=await procurarLinhaAtual(page,item,p);
  if(!row) return false;
  const txt=(await row.innerText().catch(()=>'' )).replace(/\s+/g,' ');
  log(`Já existe pedido atual de ${item.nome}: ${txt.includes('Pronto para download') ? 'Pronto' : 'Processando/registrado'}.`);
  return true;
}

async function prepararEBuscar(page,item,p){
  await page.goto(CFG.guardian_url,{waitUntil:'domcontentloaded',timeout:45000});
  await limparFiltros(page);
  await selecionarPeriodo(page);
  await preencherDatas(page,p);
  await selecionarTipo(page,item.nome);

  const buscar=page.getByRole('button',{name:/Buscar registros/i}).first();
  if(!(await buscar.count())) throw new Error('Botão Buscar registros não encontrado.');
  await buscar.click({timeout:10000});
  log(`Busca feita: ${item.nome}`);

  const exportar=page.getByRole('button',{name:/Exportar relatório/i}).first();
  if(!(await exportar.count())) throw new Error('Botão Exportar relatório não encontrado.');

  const limite=Date.now()+60000;
  while(Date.now()<limite){
    if(await exportar.isEnabled().catch(()=>false)) break;
    await sleep(1000);
  }
  if(!(await exportar.isEnabled().catch(()=>false))){
    throw new Error(`Exportar relatório não habilitou para ${item.nome}.`);
  }

  // Dá alguns segundos extras para o Guardian terminar de montar o resultado.
  await sleep(2500);

  const respPromise=page.waitForResponse(r=>/\/export/i.test(r.url()),{timeout:20000}).catch(()=>null);
  await exportar.click({timeout:10000});
  const resp=await respPromise;

  if(resp){
    log(`Export ${item.nome}: HTTP ${resp.status()}`);
    if(resp.status()>=500){
      throw new Error(`Guardian retornou HTTP ${resp.status()} ao exportar ${item.nome}.`);
    }
  }else{
    log(`Export ${item.nome}: resposta de rede não capturada; vou validar pela página de Downloads.`);
  }
}

async function aguardarPedidoAparecer(page,item,p,segundos=35){
  const limite=Date.now()+segundos*1000;
  while(Date.now()<limite){
    const row=await procurarLinhaAtual(page,item,p);
    if(row){
      const txt=(await row.innerText().catch(()=>'' )).replace(/\s+/g,' ');
      log(`Pedido apareceu em Downloads: ${item.nome}.`);
      return true;
    }
    await sleep(4000);
  }
  return false;
}

async function garantirPedido(page,item,p){
  if(await linhaExiste(page,item,p)) return;

  for(let tentativa=1; tentativa<=2; tentativa++){
    log(`Não existe pedido atual de ${item.nome}. Tentativa ${tentativa}/2.`);
    await prepararEBuscar(page,item,p);

    if(await aguardarPedidoAparecer(page,item,p,35)) return;

    log(`O pedido de ${item.nome} ainda não apareceu em Downloads.`);
    if(tentativa<2){
      log('Vou repetir SOMENTE este indicador, sem duplicar os que já existem.');
      await sleep(3000);
    }
  }

  throw new Error(`O Guardian não criou o pedido de ${item.nome} em Downloads após 2 tentativas.`);
}

async function esperarPronto(page,item,p){
  log(`Aguardando ${item.nome} ficar pronto...`);
  const limite=Date.now()+(CFG.download_wait_ms || 360000);

  while(Date.now()<limite){
    const row=await procurarLinhaAtual(page,item,p);
    if(row){
      const txt=(await row.innerText().catch(()=>'' )).replace(/\s+/g,' ');
      if(/Pronto para download/i.test(txt)) return row;
      if(/Falha|Erro/i.test(txt)) throw new Error(`Guardian informou falha em ${item.nome}: ${txt}`);
    }
    await sleep(5000);
  }
  throw new Error(`Tempo esgotado esperando ${item.nome}.`);
}

async function baixar(page,row,item){
  ensureDir(CFG.output_dir);
  const destino=path.join(CFG.output_dir,item.arquivo);

  if(fs.existsSync(destino)){
    fs.renameSync(destino,destino.replace(/\.xlsx$/i,`.anterior_${Date.now()}.xlsx`));
  }

  let icon=row.locator('span.icon-wrapper.icon-clickable').first();
  if(!(await icon.count())) icon=row.locator('[class*="icon-clickable"]').first();
  if(!(await icon.count())) throw new Error(`Ícone de download não encontrado para ${item.nome}.`);

  const dlPromise=page.waitForEvent('download',{timeout:60000});
  await icon.click({timeout:10000});
  const dl=await dlPromise;
  await dl.saveAs(destino);

  const s=fs.statSync(destino).size;
  if(s<1000) throw new Error(`Arquivo inválido: ${item.arquivo}`);
  log(`Baixado: ${item.arquivo} (${(s/1024).toFixed(1)} KB)`);
}

async function main(){
  const p=periodoAtual();
  ensureDir(CFG.output_dir);
  ensureDir(CFG.chrome_profile_dir);

  console.log('============================================================');
  console.log(' GUARDIAN 504 - V2.2 RECUPERAÇÃO');
  console.log(' Não duplica pedidos já existentes');
  console.log('============================================================');
  log(`Período: ${p.inicio} até ${p.fim}`);

  const context=await chromium.launchPersistentContext(CFG.chrome_profile_dir,{
    channel:'chrome',
    headless:false,
    acceptDownloads:true,
    viewport:null,
    chromiumSandbox:true,
    args:['--start-maximized']
  });

  const page=context.pages()[0] || await context.newPage();

  try{
    await esperarGuardian(page);

    // 1) Garante que os quatro pedidos realmente existem.
    for(const item of TIPOS){
      log('');
      log(`===== VALIDANDO ${item.nome} =====`);
      await garantirPedido(page,item,p);
    }

    // 2) Só depois baixa cada um quando estiver pronto.
    for(const item of TIPOS){
      log('');
      log(`===== BAIXANDO ${item.nome} =====`);
      const row=await esperarPronto(page,item,p);
      await baixar(page,row,item);
    }

    log('');
    log('=== SUCESSO: 4 RELATÓRIOS BAIXADOS ===');
    log(`Pasta: ${CFG.output_dir}`);
    console.log('Pressione ENTER para fechar.');
    await esperarEnter();

  }catch(e){
    console.error('');
    console.error('=== FALHA ===');
    console.error(e && e.stack ? e.stack : e);
    console.error('');
    console.error('Pressione ENTER para encerrar.');
    await esperarEnter();
  }finally{
    await context.close().catch(()=>{});
  }
}

main();
