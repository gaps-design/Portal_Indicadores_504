const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const BASE = __dirname;
const CFG = JSON.parse(fs.readFileSync(path.join(BASE, 'config_guardian.json'), 'utf8'));

const TIPOS = [
  { nome: 'Comportamento de Risco', arquivo: 'Guardian_Comportamento_Risco.xlsx' },
  { nome: 'Condição de Risco', arquivo: 'Guardian_Condicao_Risco.xlsx' },
  { nome: 'Incidente', arquivo: 'Guardian_Incidente.xlsx' },
  { nome: 'Reconhecimento', arquivo: 'Guardian_Reconhecimento.xlsx' },
];

const sleep = ms => new Promise(r => setTimeout(r, ms));
const log = m => console.log(`[${new Date().toLocaleTimeString('pt-BR')}] ${m}`);

function pad2(n){ return String(n).padStart(2, '0'); }
function periodoAtual(){
  const d = new Date();
  return {
    inicio: `01/${pad2(d.getMonth()+1)}/${d.getFullYear()}`,
    fim: `${pad2(d.getDate())}/${pad2(d.getMonth()+1)}/${d.getFullYear()}`
  };
}
function ensureDir(p){ fs.mkdirSync(p, { recursive: true }); }

function esperarEnter(){
  return new Promise(resolve => {
    process.stdin.resume();
    process.stdin.once('data', () => resolve());
  });
}

async function screenshotErro(page, nome='erro'){
  try {
    const dir = path.join(BASE, 'diagnostico');
    ensureDir(dir);
    const arq = path.join(dir, `${nome}_${Date.now()}.png`);
    await page.screenshot({ path: arq, fullPage: true });
    log(`Screenshot de diagnóstico salvo: ${arq}`);
  } catch {}
}

async function esperarGuardian(page){
  log('Abrindo Gerenciamento de Registros...');
  await page.goto(CFG.guardian_url, { waitUntil: 'domcontentloaded', timeout: 45000 }).catch(()=>{});

  try {
    await page.getByText('Gerenciamento de Registros', { exact:false }).first().waitFor({ timeout:12000 });
    log('Guardian carregado.');
  } catch {
    log('Se o Guardian pedir login, faça o login normalmente no Chrome.');
    console.log('Quando estiver na tela "Gerenciamento de Registros", volte aqui e pressione ENTER.');
    await esperarEnter();
    await page.goto(CFG.guardian_url, { waitUntil:'domcontentloaded', timeout:45000 });
    await page.getByText('Gerenciamento de Registros', { exact:false }).first().waitFor({ timeout:30000 });
    log('Guardian carregado após login.');
  }
}

async function limparFiltros(page){
  log('Etapa 1/5: Limpar filtros');
  const btn = page.getByRole('button', { name: /Limpar filtros/i }).first();
  if (await btn.count()) {
    if (await btn.isEnabled().catch(()=>false)) {
      await btn.click({ timeout:8000 });
      await sleep(700);
      log('Filtros limpos.');
    } else {
      log('Botão "Limpar filtros" está desabilitado; seguindo.');
    }
  } else {
    log('Botão "Limpar filtros" não encontrado; seguindo sem limpar.');
  }
}

async function selecionarPeriodo(page){
  log('Etapa 2/5: Selecionar "Data em que o fato ocorreu"');

  let sel = page.locator('[aria-label="Período de tempo requerido"]').first();
  if (!(await sel.count())) {
    sel = page.locator('nz-select').filter({hasText:/Data em que o fato ocorreu|Período de tempo requerido/i}).first();
  }
  if (!(await sel.count())) throw new Error('Não encontrei o seletor "Período de tempo requerido".');

  const atual = (await sel.innerText().catch(()=>'' )).trim();
  if (/Data em que o fato ocorreu/i.test(atual)) {
    log('Período requerido já está correto.');
    return;
  }

  await sel.click({ timeout:10000 });
  await sleep(500);

  let opt = page.locator('nz-option-item[title="Data em que o fato ocorreu"]').last();
  if (!(await opt.count())) opt = page.locator('.ant-select-item-option[title="Data em que o fato ocorreu"]').last();
  if (!(await opt.count())) opt = page.getByText('Data em que o fato ocorreu', { exact:true }).last();

  await opt.click({ timeout:10000 });
  await sleep(700);
  log('Período requerido selecionado.');
}

async function preencherInputData(input, valor, nome){
  await input.click({ timeout:8000 });
  await input.press('Control+A');
  await input.type(valor, { delay:40 });
  await input.press('Tab');
  await sleep(350);

  const atual = await input.inputValue().catch(()=> '');
  if (atual !== valor) {
    // fallback para componentes Ant Design
    await input.evaluate((el, v) => {
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
      setter.call(el, v);
      el.dispatchEvent(new Event('input', {bubbles:true}));
      el.dispatchEvent(new Event('change', {bubbles:true}));
      el.dispatchEvent(new Event('blur', {bubbles:true}));
    }, valor);
    await sleep(350);
  }
  log(`${nome}: ${valor}`);
}

async function preencherDatas(page, periodo){
  log('Etapa 3/5: Preencher datas');
  const ini = page.locator('input[placeholder="Data inicial"]').first();
  const fim = page.locator('input[placeholder="Data final"]').first();

  if (!(await ini.count())) throw new Error('Campo "Data inicial" não encontrado.');
  if (!(await fim.count())) throw new Error('Campo "Data final" não encontrado.');

  await preencherInputData(ini, periodo.inicio, 'Data inicial');
  await preencherInputData(fim, periodo.fim, 'Data final');
}

async function selecionarTipo(page, tipo){
  log(`Etapa 4/5: Selecionar tipo "${tipo}"`);

  let sel = page.locator('[data-testid="register-type-multi-select-component"]').first();
  if (!(await sel.count())) sel = page.locator('nz-select[aria-label="Tipo de registro"]').first();
  if (!(await sel.count())) throw new Error('Seletor "Tipo de registro" não encontrado.');

  const atual = (await sel.innerText().catch(()=>'' )).trim();
  if (atual.includes(tipo)) {
    log(`Tipo já está selecionado: ${tipo}`);
    return;
  }

  await sel.click({ timeout:10000 });
  await sleep(500);

  let opt = page.locator(`nz-option-item[title="${tipo}"]`).last();
  if (!(await opt.count())) opt = page.locator(`.ant-select-item-option[title="${tipo}"]`).last();
  if (!(await opt.count())) opt = page.getByText(tipo, { exact:true }).last();

  await opt.click({ timeout:10000 });
  await sleep(700);
  log(`Tipo selecionado: ${tipo}`);
}

async function buscarEExportar(page, tipo){
  log('Etapa 5/5: Buscar registros');
  const buscar = page.getByRole('button', { name:/Buscar registros/i }).first();
  if (!(await buscar.count())) throw new Error('Botão "Buscar registros" não encontrado.');

  await buscar.click({ timeout:10000 });
  log('Clique em "Buscar registros" realizado.');

  // Não dependemos do endpoint da API. Esperamos apenas a interface terminar.
  await sleep(2500);

  const exportar = page.getByRole('button', { name:/Exportar relatório/i }).first();
  if (!(await exportar.count())) throw new Error('Botão "Exportar relatório" não encontrado.');

  const limite = Date.now() + 60000;
  while (Date.now() < limite) {
    if (await exportar.isEnabled().catch(()=>false)) break;
    await sleep(1000);
  }
  if (!(await exportar.isEnabled().catch(()=>false))) {
    throw new Error(`O botão "Exportar relatório" não habilitou para ${tipo}.`);
  }

  log('Botão "Exportar relatório" habilitado.');
  await exportar.click({ timeout:10000 });
  log(`Exportação solicitada: ${tipo}`);
  await sleep(1200);
}

function rowMatching(page, item, periodo){
  return page.locator('tr')
    .filter({ hasText:item.nome })
    .filter({ hasText:periodo.inicio })
    .filter({ hasText:periodo.fim });
}

async function esperarPronto(page, item, periodo){
  log(`Aguardando "${item.nome}" ficar Pronto para download...`);
  const limite = Date.now() + (CFG.download_wait_ms || 360000);

  while (Date.now() < limite) {
    await page.goto(CFG.downloads_url || 'https://guardian.ab-inbev.com/downloads',
      {waitUntil:'domcontentloaded', timeout:45000}).catch(()=>{});
    await sleep(1000);

    const rows = rowMatching(page, item, periodo);
    const n = await rows.count();
    if (n > 0) {
      const row = rows.nth(n-1);
      const txt = (await row.innerText().catch(()=>'' )).replace(/\s+/g,' ');
      if (/Pronto para download/i.test(txt)) {
        log(`Pronto: ${item.nome}`);
        return row;
      }
      if (/Falha|Erro/i.test(txt)) throw new Error(`Guardian informou falha: ${txt}`);
    }
    await sleep(5000);
  }
  throw new Error(`Tempo esgotado aguardando ${item.nome}.`);
}

async function baixar(page, row, item){
  ensureDir(CFG.output_dir);
  const destino = path.join(CFG.output_dir, item.arquivo);

  if (fs.existsSync(destino)) {
    fs.renameSync(destino, destino.replace(/\.xlsx$/i, `.anterior_${Date.now()}.xlsx`));
  }

  let icon = row.locator('span.icon-wrapper.icon-clickable').first();
  if (!(await icon.count())) {
    // fallback: qualquer elemento clicável na coluna Ação
    icon = row.locator('[class*="icon-clickable"]').first();
  }
  if (!(await icon.count())) throw new Error(`Ícone de download não encontrado para ${item.nome}.`);

  const dlPromise = page.waitForEvent('download', {timeout:60000});
  await icon.click({timeout:10000});
  const dl = await dlPromise;
  await dl.saveAs(destino);

  const size = fs.statSync(destino).size;
  if (size < 1000) throw new Error(`Arquivo baixado parece inválido: ${item.arquivo}`);
  log(`Baixado: ${item.arquivo} (${(size/1024).toFixed(1)} KB)`);
}

async function main(){
  const periodo = periodoAtual();
  ensureDir(CFG.output_dir);
  ensureDir(CFG.chrome_profile_dir);

  console.log('============================================================');
  console.log(' GUARDIAN 504 - V2.1 DIAGNÓSTICO');
  console.log(' Node + Playwright + Chrome');
  console.log('============================================================');
  log(`Período: ${periodo.inicio} até ${periodo.fim}`);

  const context = await chromium.launchPersistentContext(CFG.chrome_profile_dir, {
    channel:'chrome',
    headless:false,
    acceptDownloads:true,
    viewport:null,
    args:['--start-maximized']
  });

  const page = context.pages()[0] || await context.newPage();

  try {
    await esperarGuardian(page);

    for (const item of TIPOS) {
      log('');
      log(`===== ${item.nome} =====`);
      await page.goto(CFG.guardian_url, {waitUntil:'domcontentloaded', timeout:45000});
      await limparFiltros(page);
      await selecionarPeriodo(page);
      await preencherDatas(page, periodo);
      await selecionarTipo(page, item.nome);
      await buscarEExportar(page, item.nome);
    }

    log('');
    log('As 4 exportações foram solicitadas.');
    for (const item of TIPOS) {
      const row = await esperarPronto(page, item, periodo);
      await baixar(page, row, item);
    }

    log('');
    log('=== SUCESSO: 4 relatórios baixados ===');
    log(`Pasta: ${CFG.output_dir}`);
    console.log('Pressione ENTER para fechar.');
    await esperarEnter();
  } catch (e) {
    console.error('');
    console.error('=== FALHA ===');
    console.error(e && e.stack ? e.stack : e);
    await screenshotErro(page, 'falha_guardian');
    console.error('');
    console.error('O Chrome ficará aberto. Pressione ENTER para encerrar.');
    await esperarEnter();
  } finally {
    await context.close().catch(()=>{});
  }
}
main();
