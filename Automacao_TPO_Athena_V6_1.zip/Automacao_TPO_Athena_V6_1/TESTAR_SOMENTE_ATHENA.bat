﻿@echo off
setlocal
chcp 65001 >nul
title Teste Athena - TPO
cd /d "%~dp0"
if not exist "node_modules\playwright\package.json" call npm install
for /f "tokens=2 delims=:," %%A in ('tasklist /FI "IMAGENAME eq chrome.exe" /FO CSV /NH 2^>nul') do set CHROME_ENCONTRADO=1
if defined CHROME_ENCONTRADO taskkill /F /IM chrome.exe /T >nul 2>nul
timeout /t 2 /nobreak >nul
node "%~dp0automacao_tpo.js" athena
pause
