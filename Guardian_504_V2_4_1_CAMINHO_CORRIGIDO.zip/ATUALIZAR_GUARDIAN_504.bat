@echo off
chcp 65001 >nul
title Guardian 504 - Atualizacao Portal Seguranca
cd /d "%~dp0"

echo ============================================================
echo  GUARDIAN 504 - V2.4
echo  Guardian ^> Relatorios ^> Portal Seguranca
echo ============================================================
echo.

if not exist "node_modules\playwright" (
  echo ERRO: Playwright nao encontrado nesta pasta.
  echo Rode primeiro PREPARAR_AMBIENTE.bat
  echo.
  pause
  exit /b 1
)

node Atualizar_Guardian_504.js
pause
