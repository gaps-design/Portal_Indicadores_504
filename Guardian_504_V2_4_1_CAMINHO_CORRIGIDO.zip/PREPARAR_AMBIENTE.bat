@echo off
chcp 65001 >nul
title Preparar Guardian 504
cd /d "%~dp0"

echo ============================================================
echo  PREPARANDO AMBIENTE DO GUARDIAN 504
echo  Nao precisa de Administrador
echo ============================================================
echo.

echo Verificando Node...
node --version
if errorlevel 1 (
  echo.
  echo ERRO: Node.js nao foi encontrado.
  pause
  exit /b 1
)

echo.
echo Criando package.json se necessario...
if not exist package.json (
  call npm init -y
)

echo.
echo Instalando Playwright SOMENTE nesta pasta...
call npm install playwright
if errorlevel 1 (
  echo.
  echo ERRO ao instalar Playwright.
  pause
  exit /b 1
)

echo.
echo Ambiente pronto.
echo Agora rode ATUALIZAR_GUARDIAN_504.bat
pause
