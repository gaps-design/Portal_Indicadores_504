@echo off
chcp 65001 >nul
title Teste de Caminhos Guardian 504

echo ============================================================
echo  TESTE DOS CAMINHOS DE REDE
echo ============================================================
echo.

if exist "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal Segurança\index_seguranca_504.html" (
  echo [OK] Index do Portal Seguranca encontrado.
) else (
  echo [ERRO] Index nao encontrado.
)

if exist "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal Segurança\Relatórios" (
  echo [OK] Pasta Relatorios encontrada.
) else (
  echo [ERRO] Pasta Relatorios nao encontrada.
)

echo.
echo IMPORTANTE: execute sempre em terminal normal, nunca como Administrador.
pause
