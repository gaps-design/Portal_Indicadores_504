@echo off
chcp 65001 >nul
title Guardian 504 - V2.5 FINAL
cd /d "%~dp0"

echo ============================================================
echo  GUARDIAN 504 - V2.5 FINAL
echo  Guardian ^> 4 Relatorios ^> Portal Seguranca ^> Novo Index
echo ============================================================
echo.

rem Evita o erro "Abrindo em uma sessao de navegador existente".
tasklist /FI "IMAGENAME eq chrome.exe" 2>NUL | find /I "chrome.exe" >NUL
if not errorlevel 1 (
  echo ATENCAO: existe Google Chrome aberto.
  echo.
  echo Feche TODAS as janelas do Chrome antes de iniciar a automacao.
  echo Depois execute este arquivo novamente.
  echo.
  pause
  exit /b 2
)

where node >nul 2>&1
if errorlevel 1 (
  echo ERRO: Node.js nao foi encontrado neste usuario.
  echo.
  pause
  exit /b 1
)

if not exist "node_modules\playwright" (
  echo ERRO: Playwright nao foi encontrado nesta pasta.
  echo.
  echo Rode PREPARAR_AMBIENTE.bat uma unica vez e depois tente novamente.
  echo.
  pause
  exit /b 1
)

node Atualizar_Guardian_504.js

echo.
pause
