@echo off
setlocal
chcp 65001 >nul
title Restaurar ultimo backup TPO
set "PORTAL=N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal Qualidade\Portal TPO"
set "BACKUPS=%PORTAL%\Backups_Automacao_TPO"

echo Procurando o backup mais recente...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$b=Get-ChildItem -LiteralPath '%BACKUPS%' -Filter 'index_*.html' -File -ErrorAction SilentlyContinue ^| Sort-Object LastWriteTime -Descending ^| Select-Object -First 1; if(-not $b){Write-Host 'Nenhum backup da V4 foi encontrado.' -ForegroundColor Yellow; exit 2}; Write-Host ('Backup encontrado: '+$b.FullName); Copy-Item -LiteralPath $b.FullName -Destination '%PORTAL%\index.html' -Force; Write-Host 'index.html restaurado com sucesso.' -ForegroundColor Green"

echo.
pause
