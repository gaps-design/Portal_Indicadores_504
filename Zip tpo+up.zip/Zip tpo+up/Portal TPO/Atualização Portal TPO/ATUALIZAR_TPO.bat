@echo off
setlocal
chcp 65001 >nul
title Atualizar TPO - Athena
cd /d "%~dp0"

echo ============================================================
echo   AUTOMACAO TPO - ATHENA ^> PORTAL TPO
echo   BAT + PowerShell + Node/Playwright (sem Python)
echo ============================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js nao foi encontrado neste computador.
  echo Como o Guardian ja usa Node/Playwright, confirme se esta rodando no mesmo VD.
  echo.
  pause
  exit /b 1
)

if not exist "node_modules\playwright\package.json" (
  echo [SETUP] Playwright ainda nao esta instalado nesta pasta.
  echo Vou tentar instalar agora com npm install...
  call npm install
  if errorlevel 1 (
    echo.
    echo [ERRO] Nao consegui instalar as dependencias.
    echo Me envie uma foto desta tela que ajustamos usando a instalacao do Guardian.
    pause
    exit /b 1
  )
)

for /f "tokens=2 delims=:," %%A in ('tasklist /FI "IMAGENAME eq chrome.exe" /FO CSV /NH 2^>nul') do set CHROME_ENCONTRADO=1
if defined CHROME_ENCONTRADO (
  echo [INFO] Chrome aberto detectado. Fechando antes da automacao...
  taskkill /F /IM chrome.exe /T >nul 2>nul
  timeout /t 2 /nobreak >nul
)

echo [INICIO] Executando fluxo completo...
echo.
node "%~dp0automacao_tpo.js" full
set RC=%ERRORLEVEL%

echo.
if "%RC%"=="0" (
  echo ============================================================
  echo   TPO ATUALIZADO COM SUCESSO
  echo ============================================================
) else (
  echo ============================================================
  echo   A AUTOMACAO PAROU EM ALGUMA ETAPA
  echo   Me envie a foto da tela + o ultimo passo mostrado acima.
  echo ============================================================
)
echo.
pause
exit /b %RC%
