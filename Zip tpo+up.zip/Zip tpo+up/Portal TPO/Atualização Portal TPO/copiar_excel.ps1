param(
    [Parameter(Mandatory=$true)][string]$Arquivo,
    [Parameter(Mandatory=$true)][string]$Saida
)

$ErrorActionPreference = 'Stop'
$excel = $null
$wb = $null

try {
    if (-not (Test-Path -LiteralPath $Arquivo)) {
        throw "Arquivo Excel não encontrado: $Arquivo"
    }

    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $true
    $excel.DisplayAlerts = $false

    $wb = $excel.Workbooks.Open($Arquivo, 0, $true)
    $ws = $wb.Worksheets.Item(1)
    $range = $ws.UsedRange

    # Reproduz o processo manual solicitado: seleciona toda a área usada e copia.
    $ws.Activate() | Out-Null
    $range.Select() | Out-Null
    $range.Copy() | Out-Null
    Start-Sleep -Milliseconds 1200

    $texto = Get-Clipboard -Raw
    if ([string]::IsNullOrWhiteSpace($texto)) {
        throw "A área de transferência ficou vazia após copiar o Excel."
    }

    [System.IO.File]::WriteAllText($Saida, $texto, (New-Object System.Text.UTF8Encoding($false)))
}
finally {
    if ($wb -ne $null) {
        try { $wb.Close($false) | Out-Null } catch {}
    }
    if ($excel -ne $null) {
        try { $excel.Quit() | Out-Null } catch {}
    }

    if ($range -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($range) }
    if ($ws -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($ws) }
    if ($wb -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($wb) }
    if ($excel -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
