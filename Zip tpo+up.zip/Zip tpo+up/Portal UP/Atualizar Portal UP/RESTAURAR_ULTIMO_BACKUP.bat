@echo off
chcp 65001 >nul
set "DEST=N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal Qualidade\Portal UP"
set "BKP=%DEST%\Backups_Automacao_UP"
for /f "delims=" %%F in ('dir /b /a-d /o-d "%BKP%\index_*.html" 2^>nul') do (
  echo Restaurando %%F...
  copy /y "%BKP%\%%F" "%DEST%\index.html" >nul
  echo Backup restaurado com sucesso.
  goto :fim
)
echo Nenhum backup encontrado.
:fim
pause
