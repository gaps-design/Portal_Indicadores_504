@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Teste Portal UP
set "NODE_OPTIONS=--max-old-space-size=2048"
if not exist node_modules call npm install
node automacao_up.js portal
pause
