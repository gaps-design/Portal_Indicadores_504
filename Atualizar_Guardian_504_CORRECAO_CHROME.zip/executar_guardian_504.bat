@echo off
setlocal
title Guardian 504 - Atualizacao Automatica

echo.
echo ============================================================
echo        PORTAL SEGURANCA 504 - GUARDIAN
echo ============================================================
echo.

echo Automacao iniciada pela pagina do Portal Seguranca.
echo.

REM Da tempo para o processo ser desvinculado do Chrome
timeout /t 3 /nobreak >nul

echo [1/4] Verificando Google Chrome...

REM Fecha o Chrome para liberar o perfil usado pela automacao
taskkill /F /IM chrome.exe >nul 2>&1

REM Aguarda a liberacao completa do perfil
timeout /t 3 /nobreak >nul

echo [OK] Chrome liberado.
echo.

REM Entra na pasta onde este BAT esta salvo
cd /d "%~dp0"

echo [2/4] Iniciando automacao Guardian...
echo.

REM O arquivo automacao_guardian.js deve permanecer nesta pasta
node automacao_guardian.js

set "ERRO=%ERRORLEVEL%"

echo.
echo ============================================================

if "%ERRO%"=="0" (
    echo [OK] AUTOMACAO GUARDIAN FINALIZADA COM SUCESSO.
) else (
    echo [ERRO] A AUTOMACAO TERMINOU COM CODIGO %ERRO%.
)

echo ============================================================
echo.

pause
endlocal
