@echo off
setlocal

title Atualizacao Guardian 504

REM ============================================================
REM PORTAL SEGURANCA 504
REM Launcher da automacao Guardian
REM ============================================================

REM Abre a automacao em outro CMD para nao ficar presa
REM ao Chrome que chamou este arquivo.
start "Guardian 504" cmd /c "%~dp0executar_guardian_504.bat"

exit /b
