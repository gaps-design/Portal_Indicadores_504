@echo off
chcp 65001 >nul
title Guardian 504 - V2.5.1 FINAL
cd /d "%~dp0"

echo ============================================================
echo  GUARDIAN 504 - V2.5.1 FINAL
echo  Guardian ^> 4 Relatorios ^> Portal Seguranca ^> Novo Index
echo ============================================================
echo.

echo Verificando somente a sessao do Chrome usada pela automacao...

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$perfil = Join-Path (Get-Location) 'Perfil_Chrome';" ^
  "$procs = Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $_.CommandLine -like '*Perfil_Chrome*' };" ^
  "if ($procs) { Write-Host 'Encontrada sessao antiga do Chrome da automacao. Encerrando somente ela...'; $procs | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; Start-Sleep -Seconds 2 } else { Write-Host 'Nenhuma sessao antiga da automacao encontrada.' }"

echo.

where node >nul 2>&1
if errorlevel 1 (
  echo ERRO: Node.js nao foi encontrado neste usuario.
  echo.
  pause
  exit /b 1
)

if not exist "node_modules\playwright" (
  echo ERRO: Playwright nao foi encontrado nesta pasta.
  echo.
  echo Rode PREPARAR_AMBIENTE.bat uma unica vez e depois tente novamente.
  echo.
  pause
  exit /b 1
)

node Atualizar_Guardian_504.js

echo.
pause
