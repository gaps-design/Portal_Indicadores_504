@echo off
chcp 65001 >nul
title Preparar Guardian 504
cd /d "%~dp0"

echo ============================================================
echo  PREPARAR AMBIENTE - GUARDIAN 504
echo  Executar normalmente, SEM Administrador
echo ============================================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo ERRO: Node.js nao foi encontrado.
  pause
  exit /b 1
)

node --version
npm --version

if not exist package.json (
  call npm init -y
)

call npm install playwright
if errorlevel 1 (
  echo.
  echo ERRO ao instalar Playwright.
  pause
  exit /b 1
)

echo.
echo Ambiente pronto.
echo Agora use ATUALIZAR_GUARDIAN_504.bat
echo.
pause
