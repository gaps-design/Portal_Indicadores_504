(function () {
  const RPC_BASE_OPERACIONAL = "app_programacao_base_operacional";
  const RPC_ORDENS = "app_programacao_carregar_ordens";
  const RPC_IMPORTAR_ORDENS = "app_programacao_importar_ordens";
  const RPC_SALVAR_ORDENS = "app_programacao_salvar_ordens";

  function conectado() {
    return Boolean(window.pgSupabase && typeof window.pgSupabase.rpc === "function");
  }

  async function buscarBaseOperacional() {
    if (!conectado()) {
      return { data: null, error: new Error("Cliente Supabase não configurado.") };
    }

    const inicio = performance.now();
    console.info("[Programação 504] Leitura operacional iniciada.", {
      rpc: RPC_BASE_OPERACIONAL,
      autenticacaoPortal: false
    });

    const resultado = await window.pgSupabase.rpc(RPC_BASE_OPERACIONAL);
    if (resultado.error) {
      console.error("[Programação 504] Falha na leitura operacional.", {
        rpc: RPC_BASE_OPERACIONAL,
        codigo: resultado.error.code,
        mensagem: resultado.error.message
      });
      return { data: null, error: resultado.error };
    }

    const dados = resultado.data || {};
    console.info("[Programação 504] Leitura operacional concluída.", {
      rpc: RPC_BASE_OPERACIONAL,
      funcionarios: Array.isArray(dados.funcionarios) ? dados.funcionarios.length : 0,
      duracaoMs: Math.round(performance.now() - inicio),
      somenteLeitura: dados.somenteLeitura === true
    });
    return { data: dados, error: null };
  }

  async function buscarOrdens() {
    if (!conectado()) return { data: null, error: new Error("Cliente Supabase não configurado.") };
    const resultado = await window.pgSupabase.rpc(RPC_ORDENS);
    return { data: resultado.data || {}, error: resultado.error };
  }

  async function importarOrdensSap(ordens, origem = "SAP HTML") {
    if (!conectado()) return { data: null, error: new Error("Cliente Supabase não configurado.") };
    const resultado = await window.pgSupabase.rpc(RPC_IMPORTAR_ORDENS, {
      p_ordens: ordens,
      p_origem: origem
    });
    return { data: resultado.data || {}, error: resultado.error };
  }

  async function salvarOrdens(ordens) {
    if (!conectado()) return { data: null, error: new Error("Cliente Supabase não configurado.") };
    const resultado = await window.pgSupabase.rpc(RPC_SALVAR_ORDENS, { p_ordens: ordens });
    return { data: resultado.data || {}, error: resultado.error };
  }

  window.ProgramacaoRepo = Object.freeze({
    RPC_BASE_OPERACIONAL,
    RPC_ORDENS,
    RPC_IMPORTAR_ORDENS,
    RPC_SALVAR_ORDENS,
    conectado,
    buscarBaseOperacional,
    buscarOrdens,
    importarOrdensSap,
    salvarOrdens
  });
})();
