const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const raiz = path.join(__dirname, "..");
const pagina = fs.readFileSync(path.join(raiz, "index_programacao_operacional_504_v4.html"), "utf8");
const repo = fs.readFileSync(path.join(raiz, "js", "programacao-repo.js"), "utf8");
const migration = fs.readFileSync(path.join(raiz, "supabase", "migrations", "001_ordens_operacionais.sql"), "utf8");

function extrairDemo() {
  const inicio = pagina.indexOf("const DEMO =");
  const abre = pagina.indexOf("[", inicio);
  let nivel = 0;
  let string = false;
  let aspas = "";
  let escape = false;
  for (let i = abre; i < pagina.length; i += 1) {
    const char = pagina[i];
    if (string) {
      if (escape) escape = false;
      else if (char === "\\") escape = true;
      else if (char === aspas) string = false;
      continue;
    }
    if (char === '"' || char === "'" || char === "`") { string = true; aspas = char; continue; }
    if (char === "[") nivel += 1;
    if (char === "]" && --nivel === 0) return vm.runInNewContext(`(${pagina.slice(abre, i + 1)})`);
  }
  throw new Error("Base DEMO inválida.");
}

const inline = [...pagina.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)]
  .map(match => match[1])
  .filter(script => script.trim());
inline.forEach(script => new Function(script));

assert.strictEqual(extrairDemo().length, 95, "as 95 ordens existentes devem ser preservadas");
assert(pagina.includes('accept=".htm,.html,text/html"'), "upload deve aceitar HTM e HTML");
assert(pagina.includes("best.headerRowIndex+1"), "parser deve localizar o cabeçalho SAP dentro da tabela");
assert(pagina.includes("await window.ProgramacaoRepo.importarOrdensSap"), "upload deve aguardar a gravação no Supabase");
assert(pagina.includes("await carregarOrdensSupabase()"), "interface deve reler o Supabase após importar");
assert(repo.includes("app_programacao_importar_ordens"), "RPC de importação ausente");
assert(repo.includes("app_programacao_carregar_ordens"), "RPC de leitura ausente");
assert(migration.includes("ordem text primary key"), "número SAP deve ser a chave lógica");
assert(migration.includes("v_existente || v_sap"), "campos SAP devem atualizar sem apagar dados operacionais");
assert(!/\b(?:delete|truncate|drop)\b/i.test(migration), "migration não deve remover dados");

console.log("OK: 95 ordens, parser SAP, upsert e releitura Supabase validados.");
