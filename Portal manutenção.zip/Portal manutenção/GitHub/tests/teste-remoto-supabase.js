const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const raiz = path.join(__dirname, "..");
const pagina = fs.readFileSync(path.join(raiz, "index_programacao_operacional_504_v4.html"), "utf8");
const cliente = fs.readFileSync(path.join(raiz, "js", "supabaseClient.js"), "utf8");
const url = cliente.match(/"(https:\/\/[^"]+\.supabase\.co)"/)?.[1];
const key = cliente.match(/"(sb_publishable_[^"]+)"/)?.[1];

function extrairDemo() {
  const inicio = pagina.indexOf("const DEMO =");
  const abre = pagina.indexOf("[", inicio);
  let nivel = 0;
  let string = false;
  let aspas = "";
  let escape = false;
  for (let i = abre; i < pagina.length; i += 1) {
    const char = pagina[i];
    if (string) {
      if (escape) escape = false;
      else if (char === "\\") escape = true;
      else if (char === aspas) string = false;
      continue;
    }
    if (char === '"' || char === "'" || char === "`") { string = true; aspas = char; continue; }
    if (char === "[") nivel += 1;
    if (char === "]" && --nivel === 0) return vm.runInNewContext(`(${pagina.slice(abre, i + 1)})`);
  }
  throw new Error("Base DEMO inválida.");
}

async function rpc(nome, body = {}) {
  const resposta = await fetch(`${url}/rest/v1/rpc/${nome}`, {
    method: "POST",
    headers: { apikey: key, "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const dados = await resposta.json();
  if (!resposta.ok) throw new Error(`${nome}: HTTP ${resposta.status} - ${JSON.stringify(dados)}`);
  return dados;
}

async function executar() {
  assert(url && key, "configuração pública do Supabase ausente");
  const demo = extrairDemo();
  const ordensEsperadas = new Set(demo.map(item => String(item.order)));
  await rpc("app_programacao_importar_ordens", { p_ordens: demo, p_origem: "Teste remoto base SAP 95" });
  await rpc("app_programacao_importar_ordens", { p_ordens: demo, p_origem: "Teste remoto idempotência" });
  const base = await rpc("app_programacao_carregar_ordens");
  const ordens = Array.isArray(base.ordens) ? base.ordens : [];
  const ids = ordens.map(item => String(item.order));

  assert.strictEqual(new Set(ids).size, ids.length, "Supabase contém ordens duplicadas");
  assert([...ordensEsperadas].every(id => ids.includes(id)), "alguma das 95 ordens foi perdida");
  assert(ordens.length >= 95, "a base remota deve preservar ao menos as 95 ordens existentes");
  console.log(`OK: ${ordens.length} ordens relidas do Supabase, 95 preservadas e nenhuma duplicação.`);
}

executar().catch(error => {
  console.error(error.message);
  process.exitCode = 1;
});
