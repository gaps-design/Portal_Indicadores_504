const assert = require("assert");
const path = require("path");
const { chromium } = require("playwright");

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
  });
  try {
    const page = await browser.newPage();
    page.setDefaultTimeout(20000);
    page.on("pageerror", error => console.error("PAGE ERROR:", error.message));
    await page.goto("http://127.0.0.1:8766/index_programacao_operacional_504_v4.html", {
      waitUntil: "domcontentloaded"
    });
    await page.waitForFunction(() => document.querySelector("#hOrders")?.textContent === "95");
    await page.click('.tab[data-page="importar"]');
    await page.setInputFiles("#sapHtmlFile", path.join(__dirname, "fixture-sap.html"));
    await page.click('button[onclick="importSapHtmlFile()"]');
    await page.waitForFunction(() =>
      document.querySelector("#importResult")?.textContent.includes("1 ordens confirmadas no Supabase")
    );
    assert.strictEqual(await page.textContent("#hOrders"), "95");
    assert((await page.textContent("#portalSourceState")).includes("38 operadores"));
    console.log("OK: HTML SAP extraído, gravado, relido e exibido com 95 ordens e 38 operadores.");
  } finally {
    await browser.close();
  }
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
