begin;

create table if not exists public.ordens_operacionais (
  ordem text primary key check (ordem ~ '^[0-9]{6,}$'),
  dados jsonb not null default '{}'::jsonb,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create table if not exists public.ordens_operacionais_importacoes (
  id bigint generated always as identity primary key,
  origem text not null,
  lidas integer not null,
  inseridas integer not null,
  atualizadas integer not null,
  novas_confirmadas integer not null default 0,
  criado_em timestamptz not null default now()
);

alter table public.ordens_operacionais enable row level security;
alter table public.ordens_operacionais_importacoes enable row level security;
revoke all on public.ordens_operacionais from public, anon, authenticated;
revoke all on public.ordens_operacionais_importacoes from public, anon, authenticated;

create or replace function public.app_programacao_importar_ordens(
  p_ordens jsonb,
  p_origem text default 'SAP HTML'
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_item jsonb;
  v_ordem text;
  v_existente jsonb;
  v_sap jsonb;
  v_novo jsonb;
  v_inseridas integer := 0;
  v_atualizadas integer := 0;
  v_novas_confirmadas integer := 0;
  v_linhas integer;
begin
  if jsonb_typeof(p_ordens) <> 'array' then
    raise exception 'A lista de ordens SAP deve ser um array';
  end if;
  if jsonb_array_length(p_ordens) = 0 or jsonb_array_length(p_ordens) > 5000 then
    raise exception 'Quantidade de ordens SAP inválida';
  end if;

  for v_item in select value from jsonb_array_elements(p_ordens)
  loop
    v_ordem := trim(coalesce(v_item->>'order', v_item->>'ordem', ''));
    if v_ordem !~ '^[0-9]{6,}$' then
      continue;
    end if;

    v_sap := jsonb_build_object(
      'order', v_ordem,
      'orderType', left(coalesce(v_item->>'orderType', ''), 80),
      'date', left(coalesce(v_item->>'date', ''), 20),
      'desc', left(coalesce(v_item->>'desc', ''), 1000),
      'loc', left(coalesce(v_item->>'loc', ''), 500),
      'workCenter', left(coalesce(v_item->>'workCenter', ''), 120),
      'type', left(coalesce(v_item->>'type', ''), 120),
      'userStatus', left(coalesce(v_item->>'userStatus', ''), 300),
      'sap', left(coalesce(v_item->>'sap', ''), 500),
      'importedAt', now()
    );

    select o.dados into v_existente
    from public.ordens_operacionais o
    where o.ordem = v_ordem
    for update;

    if found then
      v_novo := v_existente || v_sap;
      if position('CONF' in upper(coalesce(v_existente->>'sap', ''))) = 0
         and position('CONF' in upper(coalesce(v_novo->>'sap', ''))) > 0 then
        v_novo := v_novo || jsonb_build_object('completedAt', now());
        v_novas_confirmadas := v_novas_confirmadas + 1;
      end if;
      update public.ordens_operacionais
      set dados = v_novo,
          atualizado_em = now()
      where ordem = v_ordem
        and dados is distinct from v_novo;
      get diagnostics v_linhas = row_count;
      v_atualizadas := v_atualizadas + v_linhas;
    else
      v_novo := v_sap || jsonb_build_object(
        'equipment', left(coalesce(v_item->>'equipment', ''), 300),
        'firstSeenAt', now()
      );
      insert into public.ordens_operacionais(ordem, dados)
      values (v_ordem, v_novo);
      v_inseridas := v_inseridas + 1;
    end if;
  end loop;

  insert into public.ordens_operacionais_importacoes(
    origem, lidas, inseridas, atualizadas, novas_confirmadas
  ) values (
    left(coalesce(nullif(trim(p_origem), ''), 'SAP HTML'), 200),
    jsonb_array_length(p_ordens), v_inseridas, v_atualizadas, v_novas_confirmadas
  );

  return jsonb_build_object(
    'ok', true,
    'lidas', jsonb_array_length(p_ordens),
    'inseridas', v_inseridas,
    'atualizadas', v_atualizadas,
    'novas_confirmadas', v_novas_confirmadas
  );
end
$$;

create or replace function public.app_programacao_salvar_ordens(p_ordens jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_item jsonb;
  v_ordem text;
  v_chave text;
  v_operacional jsonb;
  v_atualizadas integer := 0;
  v_linhas integer;
begin
  if jsonb_typeof(p_ordens) <> 'array' or jsonb_array_length(p_ordens) > 5000 then
    raise exception 'A lista operacional de ordens é inválida';
  end if;

  for v_item in select value from jsonb_array_elements(p_ordens)
  loop
    v_ordem := trim(coalesce(v_item->>'order', v_item->>'ordem', ''));
    if v_ordem !~ '^[0-9]{6,}$' then
      continue;
    end if;

    v_operacional := '{}'::jsonb;
    foreach v_chave in array array[
      'owner', 'ownerId', 'ownerSnapshot', 'ownerLinkStatus', 'programShift',
      'group', 'cell', 'equipment', 'completedAt', 'statusOperacional',
      'execucao', 'historico'
    ]
    loop
      if v_item ? v_chave then
        v_operacional := v_operacional || jsonb_build_object(v_chave, v_item->v_chave);
      end if;
    end loop;

    update public.ordens_operacionais o
    set dados = o.dados || v_operacional,
        atualizado_em = now()
    where o.ordem = v_ordem
      and o.dados is distinct from (o.dados || v_operacional);
    get diagnostics v_linhas = row_count;
    v_atualizadas := v_atualizadas + v_linhas;
  end loop;

  return jsonb_build_object('ok', true, 'atualizadas', v_atualizadas);
end
$$;

create or replace function public.app_programacao_carregar_ordens()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'ordens',
    coalesce((
      select jsonb_agg(o.dados || jsonb_build_object('order', o.ordem) order by o.ordem)
      from public.ordens_operacionais o
    ), '[]'::jsonb),
    'importHistory',
    coalesce((
      select jsonb_agg(jsonb_build_object(
        'at', i.criado_em,
        'source', i.origem,
        'read', i.lidas,
        'created', i.inseridas,
        'updated', i.atualizadas,
        'newlyConfirmed', i.novas_confirmadas
      ) order by i.id)
      from (
        select * from public.ordens_operacionais_importacoes
        order by id desc
        limit 100
      ) i
    ), '[]'::jsonb)
  )
$$;

revoke all on function public.app_programacao_importar_ordens(jsonb, text) from public;
revoke all on function public.app_programacao_salvar_ordens(jsonb) from public;
revoke all on function public.app_programacao_carregar_ordens() from public;
grant execute on function public.app_programacao_importar_ordens(jsonb, text) to anon, authenticated;
grant execute on function public.app_programacao_salvar_ordens(jsonb) to anon, authenticated;
grant execute on function public.app_programacao_carregar_ordens() to anon, authenticated;

notify pgrst, 'reload schema';
commit;
