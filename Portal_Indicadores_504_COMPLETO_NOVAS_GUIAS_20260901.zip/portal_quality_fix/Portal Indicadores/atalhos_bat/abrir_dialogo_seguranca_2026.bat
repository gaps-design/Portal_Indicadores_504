﻿@echo off
start "" explorer.exe "N:\Gente\Seguranca\_Compartilhado\00 - MATINAL ÁREA - TAREFA MÊS\16 - MATINAIS DE SEXTA FEIRA\2026"
exit /b
