﻿@echo off
start "" explorer.exe "\\Acswpj5\jc\NOVA\Engenharia\PCM\Compartilhado\00. Pilar Manutenção\02 - Manutenção Preventiva (Fundamentos)\02 - Manuais Técnicos"
exit /b
