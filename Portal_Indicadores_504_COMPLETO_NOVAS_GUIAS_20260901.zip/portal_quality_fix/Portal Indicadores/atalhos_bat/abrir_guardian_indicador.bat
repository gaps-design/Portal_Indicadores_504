﻿@echo off
start "" explorer.exe "N:\Gente\Gestao\Compartilhado\VPO\03-PILAR GESTÃO\02. Gerenciar para Manter\05. Revisão da Rotina\01. Agenda da Rotina\03. Reunião Quinzenal\2026\01. PACKAGING RGB + LN\3. Segurança\2 - Guardian"
exit /b
