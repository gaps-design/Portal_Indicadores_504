﻿@echo off
start "" explorer.exe "N:\Packaging\Compartilhado\Retornável\Usuarios\PIVA\2025\Planos Manutenção L504"
exit /b
