"use strict";
const http=require("http"),fs=require("fs"),path=require("path"),{spawn,execFile}=require("child_process");
const ROOT=__dirname,CFG=JSON.parse(fs.readFileSync(path.join(ROOT,"config_central_504.json"),"utf8")),STATUS_FILE=path.join(ROOT,"status_central_504.json"),LOG_DIR=path.join(ROOT,"logs");fs.mkdirSync(LOG_DIR,{recursive:true});
let running=null;let db={history:[]};try{db=JSON.parse(fs.readFileSync(STATUS_FILE,"utf8"))}catch(_){}if(!Array.isArray(db.history))db.history=[];
function save(){try{fs.writeFileSync(STATUS_FILE,JSON.stringify(db,null,2),"utf8")}catch(e){console.error("Falha salvando status:",e.message)}}
function cors(res){res.setHeader("Access-Control-Allow-Origin","*");res.setHeader("Access-Control-Allow-Methods","GET,POST,OPTIONS");res.setHeader("Access-Control-Allow-Headers","Content-Type");res.setHeader("Cache-Control","no-store")}
function json(res,code,data){cors(res);res.writeHead(code,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify(data))}
function fileDate(file){try{return fs.statSync(file).mtime.toISOString()}catch(_){return null}}
function commandExists(command){return new Promise(resolve=>{const cmd=process.platform==="win32"?"where":"which";execFile(cmd,[command],{windowsHide:true},e=>resolve(!e))})}

function findNamedFile(root,fileName,maxDepth=3,depth=0){
  if(depth>maxDepth)return null;
  let entries;
  try{entries=fs.readdirSync(root,{withFileTypes:true})}catch(_){return null}
  for(const e of entries){
    if(e.isFile()&&e.name.toLowerCase()===fileName.toLowerCase())return path.join(root,e.name);
  }
  const skip=new Set(["node_modules","perfil_chrome",".git","downloads"]);
  for(const e of entries){
    if(!e.isDirectory()||skip.has(e.name.toLowerCase()))continue;
    const found=findNamedFile(path.join(root,e.name),fileName,maxDepth,depth+1);
    if(found)return found;
  }
  return null;
}

function resolveAutomation(id,source){
  const a={...source,args:[...(source.args||[])]};
  if(id==="seguranca"&&a.kind==="node"&&fs.existsSync(a.cwd)){
    const wanted=a.args[0];
    const direct=path.join(a.cwd,wanted);
    if(!fs.existsSync(direct)){
      const found=findNamedFile(a.cwd,wanted,3,0);
      if(found){
        a.cwd=path.dirname(found);
        a.args[0]=path.basename(found);
      }
    }
  }
  return a;
}

async function availability(){
  const nodeOk=await commandExists("node");
  const out={};
  for(const [id,source] of Object.entries(CFG.automations)){
    const a=resolveAutomation(id,source);
    let reason="",available=true;
    if(!fs.existsSync(source.cwd)){available=false;reason="Pasta da automação não localizada"}
    else if(a.kind==="node"&&!nodeOk){available=false;reason="Node.js não encontrado"}
    else if(a.kind==="node"&&!fs.existsSync(path.join(a.cwd,a.args[0]))){available=false;reason="Script Node não localizado"}
    else if(a.kind==="powershell"&&!fs.existsSync(path.join(a.cwd,a.args[a.args.length-1]))){available=false;reason="Script PowerShell não localizado"}
    out[id]={name:a.name,available,reason,fileUpdatedAt:fileDate(a.watchFile)};
  }
  return out;
}

function stamp(){const d=new Date(),p=n=>String(n).padStart(2,"0");return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`}
async function getStatus(){return {agent:{online:true,version:"1.1-seguranca",port:CFG.port},automations:await availability(),running,history:db.history.slice(0,30)}}

function psQuote(value){return "'"+String(value).replace(/'/g,"''")+"'"}

async function run(id){
  if(running)throw Object.assign(new Error("Outra automação está em execução"),{code:409});
  const source=CFG.automations[id];
  if(!source)throw Object.assign(new Error("Automação desconhecida"),{code:404});
  const av=(await availability())[id];
  if(!av.available)throw Object.assign(new Error(av.reason),{code:400});

  const a=resolveAutomation(id,source);
  const startedAt=new Date(),logPath=path.join(LOG_DIR,`${stamp()}_${id}.log`),log=fs.createWriteStream(logPath,{flags:"a"});
  running={id,name:a.name,startedAt:startedAt.toISOString(),log:logPath};
  console.log(`[CENTRAL] Iniciando ${a.name}`);

  const env={...process.env,...(a.env||{}),PORTAL504_CENTRAL:"1"};
  let command=a.command,args=a.args,cwd=a.cwd;

  if(id==="seguranca"){
    const profileDir=path.join(source.cwd,"Perfil_Chrome");
    const ps=[
      '$ErrorActionPreference="Continue"',
      'Start-Sleep -Seconds 2',
      'Write-Host "[CENTRAL] Fechando Chrome para liberar o Guardian..."',
      'Get-Process chrome -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue',
      '$limite=(Get-Date).AddSeconds(15)',
      'do { Start-Sleep -Milliseconds 500; $c=Get-Process chrome -ErrorAction SilentlyContinue } while($c -and (Get-Date) -lt $limite)',
      `if(Test-Path -LiteralPath ${psQuote(profileDir)}) { Get-ChildItem -LiteralPath ${psQuote(profileDir)} -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "Singleton*" } | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue }`,
      'Start-Sleep -Seconds 2',
      `Set-Location -LiteralPath ${psQuote(a.cwd)}`,
      `& node ${psQuote(a.args[0])}`,
      'exit $LASTEXITCODE'
    ].join("; ");
    command="powershell.exe";
    args=["-NoLogo","-NoProfile","-ExecutionPolicy","Bypass","-Command",ps];
  }

  const child=spawn(command,args,{cwd,env,windowsHide:false,shell:false});
  child.stdout.on("data",d=>{process.stdout.write(d);log.write(d)});
  child.stderr.on("data",d=>{process.stderr.write(d);log.write(d)});
  child.on("error",err=>{log.write(`\nERRO DE PROCESSO: ${err.message}\n`)});
  child.on("close",code=>{
    const endedAt=new Date(),rec={id,name:a.name,startedAt:startedAt.toISOString(),endedAt:endedAt.toISOString(),durationMs:endedAt-startedAt,result:code===0?"success":"error",exitCode:code,log:logPath};
    db.history.unshift(rec);db.history=db.history.slice(0,100);save();running=null;log.end();
    console.log(`[CENTRAL] ${a.name}: ${rec.result}`);
  });
  return running;
}

const server=http.createServer(async(req,res)=>{
  if(req.method==="OPTIONS"){cors(res);res.writeHead(204);return res.end()}
  const u=new URL(req.url,`http://127.0.0.1:${CFG.port}`);
  try{
    if(req.method==="GET"&&u.pathname==="/health")return json(res,200,{ok:true});
    if(req.method==="GET"&&u.pathname==="/status")return json(res,200,await getStatus());
    const m=u.pathname.match(/^\/run\/([a-z0-9_-]+)$/i);
    if(req.method==="POST"&&m){const data=await run(m[1]);return json(res,202,{ok:true,running:data})}
    return json(res,404,{error:"not_found"})
  }catch(e){return json(res,e.code||500,{error:e.message})}
});

server.on("error",e=>{
  if(e.code==="EADDRINUSE"){console.log("Central 504 já está em execução neste VD.");process.exit(0)}
  console.error(e);process.exit(1)
});
server.listen(CFG.port,"127.0.0.1",()=>{
  console.log("============================================================");
  console.log(" CENTRAL DE ATUALIZACOES 504 - AGENTE LOCAL");
  console.log(` http://127.0.0.1:${CFG.port}`);
  console.log(" Apenas este VD pode acessar o agente (127.0.0.1).");
  console.log("============================================================")
});
