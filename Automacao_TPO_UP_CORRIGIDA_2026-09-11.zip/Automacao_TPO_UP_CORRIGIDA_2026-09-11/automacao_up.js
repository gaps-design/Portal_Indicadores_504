'use strict';
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const os = require('os');
const v8 = require('v8');
const { execFileSync } = require('child_process');
const { pathToFileURL } = require('url');

const ROOT = __dirname;
const config = JSON.parse(fs.readFileSync(path.join(ROOT,'config.json'),'utf8'));
const MODE = (process.argv[2] || 'full').toLowerCase();
const LOG_DIR = path.join(ROOT,'logs');
const AUTOMATION_LOCAL_DIR = path.join(process.env.LOCALAPPDATA || os.tmpdir(),'Portal504_Automacao');
const AUTH_STATE = path.join(AUTOMATION_LOCAL_DIR,'athena_storage_up.json');
fs.mkdirSync(LOG_DIR,{recursive:true}); fs.mkdirSync(AUTOMATION_LOCAL_DIR,{recursive:true});
const TIMEOUT = Number(config.tempoMaximoPassoMs||30000);
const LOGIN_TIMEOUT = Number(config.tempoMaximoLoginMs||180000);
const downloadsDir = path.join(os.homedir(),'Downloads');
const UP_REPORT_DIR = config.relatorioSaidaDir || 'N:\\Packaging\\Compartilhado\\Retornável\\Usuarios\\Guilherme A\\Relatórios UP';
fs.mkdirSync(UP_REPORT_DIR,{recursive:true});

const sleep = ms => new Promise(r=>setTimeout(r,ms));
function log(m){console.log(`[UP] ${m}`)}
function step(n,t,m){console.log(`\n[${n}/${t}] ${m}`)}
function p2(n){return String(n).padStart(2,'0')}
function nowStamp(){const d=new Date(); return `${d.getFullYear()}${p2(d.getMonth()+1)}${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}${p2(d.getSeconds())}`}
function ymd(d){return `${d.getFullYear()}-${p2(d.getMonth()+1)}-${p2(d.getDate())}`}
function dmy(d){return `${p2(d.getDate())}/${p2(d.getMonth()+1)}/${d.getFullYear()}`}
function currentMonthLong(){return ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'][new Date().getMonth()]}
function currentMonthYearLabel(){return `${currentMonthLong()}/${new Date().getFullYear()}`}
function expectedRange(){const today=new Date(); return {first:new Date(today.getFullYear(),today.getMonth(),1),today}}
function newestGenericExcel(){
  const buscar=(dir)=>{
    if(!fs.existsSync(dir))return null;
    return fs.readdirSync(dir)
      .filter(n=>/^relatorio-generico_.*\.xlsx?$/i.test(n))
      .map(n=>({n,p:path.join(dir,n),s:fs.statSync(path.join(dir,n))}))
      .sort((a,b)=>b.s.mtimeMs-a.s.mtimeMs)[0]?.p||null;
  };
  return buscar(UP_REPORT_DIR) || buscar(downloadsDir);
}
function validateFilename(file,range){const n=path.basename(file); const m=n.match(/^relatorio-generico_(\d{2})_(\d{2})_(\d{4})_(\d{2})_(\d{2})_(\d{4})(?: \(\d+\))?\.xlsx?$/i); if(!m){log(`AVISO: período não pôde ser confirmado pelo nome ${n}`);return} const f=`${m[1]}/${m[2]}/${m[3]}`,t=`${m[4]}/${m[5]}/${m[6]}`; if(f!==dmy(range.first)||t!==dmy(range.today)) throw new Error(`Período divergente. Esperado ${dmy(range.first)} a ${dmy(range.today)}, arquivo indica ${f} a ${t}.`); log(`Período confirmado pelo arquivo baixado: ${f} a ${t}.`)}

function portal504HashCredential(value) {
  let h1 = 0xdeadbeef ^ value.length;
  let h2 = 0x41c6ce57 ^ value.length;
  for (let i = 0, ch; i < value.length; i++) {
    ch = value.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}

async function autorizarPortal504(page) {
  // Usa o mesmo token da autenticação local do Portal 504, sem gravar a senha em texto puro.
  // window.name sobrevive à navegação Athena -> file:// e é reconhecido pelos guards dos portais.
  const usuario = 'acesso';
  const senhaHash = '1j78k6ardjv';
  const token = portal504HashCredential(`portal504|${usuario}|${senhaHash}|autorizado`);
  const sessao = { token, expiraEm: Date.now() + 12 * 60 * 60 * 1000 };
  await page.evaluate((s) => {
    window.name = `PORTAL504_AUTH:${encodeURIComponent(JSON.stringify(s))}`;
    try { localStorage.setItem('portal504_auth_v1', JSON.stringify(s)); } catch (_) {}
  }, sessao).catch(()=>{});
}

async function tratarConfirmacaoEntradaAthena(page, esperaMs=4500) {
  const fim = Date.now() + esperaMs;
  const modalRe = /^(Entrar|Entrar no mês|Entrar no mes|Confirmar|Continuar|Acessar|Prosseguir|Sim|OK)$/i;
  const globalRe = /^(Entrar|Entrar no mês|Entrar no mes|Confirmar|Continuar|Acessar|Prosseguir)$/i;
  let total = 0;
  let ultimaConfirmacao = 0;

  while (Date.now() < fim) {
    let clicou = false;

    // Procura primeiro dentro de modal/dialog. Aqui aceitamos também Sim/OK,
    // porque são respostas seguras apenas quando o botão está dentro do modal.
    const modais = page.locator('[role="dialog"]:visible, .ant-modal:visible, .modal:visible, mat-dialog-container:visible');
    const n = await modais.count().catch(()=>0);
    for (let i=0;i<n;i++) {
      const botao = modais.nth(i).getByRole('button',{name:modalRe}).first();
      if (await botao.count() && await botao.isVisible().catch(()=>false)) {
        const txt = ((await botao.innerText().catch(()=>'')) || 'Entrar').trim();
        log(`Athena pediu confirmação de entrada. Clicando em "${txt}"...`);
        await botao.click({timeout:8000});
        total++;
        ultimaConfirmacao = Date.now();
        clicou = true;
        await sleep(850);
        break;
      }
    }

    if (clicou) continue;

    // Fallback global fica restrito aos nomes conhecidos para não clicar em OK/Sim fora de um modal.
    const global = page.getByRole('button',{name:globalRe}).filter({visible:true}).first();
    if (await global.count() && await global.isVisible().catch(()=>false)) {
      const txt=(await global.innerText().catch(()=>'' )).trim();
      log(`Confirmação condicional do Athena detectada: "${txt || 'Entrar'}".`);
      await global.click({timeout:8000});
      total++;
      ultimaConfirmacao = Date.now();
      await sleep(850);
      continue;
    }

    // Depois de clicar em uma confirmação, espera uma janela curta sem novos diálogos.
    // Isso cobre o caso real do Athena pedir duas confirmações seguidas.
    if (total > 0 && Date.now() - ultimaConfirmacao >= 1200) break;
    await sleep(250);
  }

  if (total > 1) log(`Athena exigiu ${total} confirmações sequenciais; todas foram tratadas.`);
  return total;
}

async function saveDebug(page,label){try{const f=path.join(LOG_DIR,`${nowStamp()}_${label}.png`); await page.screenshot({path:f,fullPage:true}); log(`Imagem de diagnóstico: ${f}`)}catch(_){}}
async function launch(){
  log('Abrindo navegador isolado do Playwright (sem perfil persistente do Chrome).');
  let browser;
  try {
    browser=await chromium.launch({headless:false,args:['--start-maximized','--disable-gpu','--no-first-run','--no-default-browser-check']});
  }catch(e){
    const msg=String(e&&e.message?e.message:e||'');
    if(/Executable doesn't exist|browserType\.launch: Executable/i.test(msg)) throw new Error('O Chromium do Playwright não está instalado neste VD. Rode uma vez: npx playwright install chromium');
    throw e;
  }
  const opts={acceptDownloads:true,viewport:null,permissions:['geolocation']};
  if(fs.existsSync(AUTH_STATE)){opts.storageState=AUTH_STATE;log(`Sessão Athena carregada de: ${AUTH_STATE}`)}else{log('Primeiro uso deste navegador isolado: o Athena poderá pedir login/MFA uma vez.')}
  const context=await browser.newContext(opts);
  try { await context.grantPermissions(['geolocation'], { origin: new URL(config.athenaUrl).origin }); log('Permissão de localização do Athena liberada automaticamente.'); } catch(e) { log('Aviso: não foi possível pré-liberar localização: '+e.message); }
  const page=await context.newPage();
  page.setDefaultTimeout(TIMEOUT);
  page.on('dialog',async dialog=>{
    try{
      const msg=dialog.message()||'';
      if(/athena/i.test(page.url()) && /entrar|confirm|continuar|m[eê]s/i.test(msg)){
        log(`Confirmação nativa do Athena: ${msg}`);
        await dialog.accept();
      }
    }catch(_){}
  });
  return {browser,context,page};
}
async function saveAuthState(page){try{await page.context().storageState({path:AUTH_STATE});log('Sessão Athena salva para as próximas execuções.')}catch(_){}}
async function ensureLogin(page){if(await page.getByText('Relatórios',{exact:true}).count())return; const sso=page.locator('#btn-sso').first(); if(await sso.count()){log('Botão SSO encontrado. Clicando em "Acesse Aqui"...'); await sso.click()} else {const b=page.getByRole('button',{name:/Acesse Aqui/i}).first(); if(await b.count())await b.click()} log('Aguardando autenticação corporativa. Se aparecer MFA/login, conclua manualmente.'); const end=Date.now()+LOGIN_TIMEOUT; while(Date.now()<end){if(await page.getByText('Relatórios',{exact:true}).count()||/relatorios/i.test(page.url()))return; await sleep(1000)} throw new Error('Tempo excedido aguardando login Athena.')}
async function openAthena(browser,page){try{await page.goto(config.athenaUrl,{waitUntil:'domcontentloaded',timeout:LOGIN_TIMEOUT}); await ensureLogin(page); await tratarConfirmacaoEntradaAthena(page,1500).catch(()=>false); await saveAuthState(page); return {browser,page}}catch(e){if(!/crash|browser has been closed|page has been closed|Target page/i.test(String(e.message)))throw e; log('Navegador isolado caiu; reiniciando uma vez...'); try{await browser.close()}catch(_){} await sleep(3000); const r=await launch(); await r.page.goto(config.athenaUrl,{waitUntil:'domcontentloaded',timeout:LOGIN_TIMEOUT}); await ensureLogin(r.page); await tratarConfirmacaoEntradaAthena(r.page,1500).catch(()=>false); await saveAuthState(r.page); return r}}
async function telaRelatoriosPronta(page){
  const busca=page.locator('input[placeholder*="Buscar" i]:visible').first();
  if(await busca.count()&&await busca.isVisible().catch(()=>false))return true;
  const cards=page.locator('chb-relatorio-favorito-title:visible');
  return (await cards.count().catch(()=>0))>0;
}
async function aguardarTelaRelatorios(page,timeout=TIMEOUT){
  const fim=Date.now()+timeout;
  while(Date.now()<fim){
    await tratarConfirmacaoEntradaAthena(page,700).catch(()=>0);
    if(await telaRelatoriosPronta(page))return true;
    await sleep(300);
  }
  return false;
}
async function openReports(page){
  let ultimoErro=null;
  for(let tentativa=1;tentativa<=3;tentativa++){
    try{
      await tratarConfirmacaoEntradaAthena(page,1200).catch(()=>0);
      if(await aguardarTelaRelatorios(page,1800)){await saveAuthState(page);return;}
      const m=page.getByText('Relatórios',{exact:true}).filter({visible:true}).first();
      if(await m.count()&&await m.isVisible().catch(()=>false)){
        log(`Abrindo Relatórios (tentativa ${tentativa}/3)...`);
        await m.click({timeout:TIMEOUT});
      }else{
        log(`Menu Relatórios ainda não está disponível; recarregando a entrada do Athena (tentativa ${tentativa}/3)...`);
        await page.goto(config.athenaUrl,{waitUntil:'domcontentloaded',timeout:LOGIN_TIMEOUT});
        await ensureLogin(page);
        const m2=page.getByText('Relatórios',{exact:true}).filter({visible:true}).first();
        if(await m2.count()&&await m2.isVisible().catch(()=>false))await m2.click({timeout:TIMEOUT});
      }
      await tratarConfirmacaoEntradaAthena(page,5500).catch(()=>0);
      if(await aguardarTelaRelatorios(page,Math.min(TIMEOUT,15000))){log('Tela de Relatórios carregada e pronta para busca.');await saveAuthState(page);return;}
      throw new Error('A URL abriu, mas a lista/busca de Relatórios não ficou pronta.');
    }catch(e){
      ultimoErro=e;
      log(`Falha ao preparar Relatórios na tentativa ${tentativa}/3: ${e.message}`);
      await saveDebug(page,`relatorios_tentativa_${tentativa}`);
      if(tentativa<3){await page.goto(config.athenaUrl,{waitUntil:'domcontentloaded',timeout:LOGIN_TIMEOUT}).catch(()=>{});await ensureLogin(page).catch(()=>{});await tratarConfirmacaoEntradaAthena(page,3500).catch(()=>0);}
    }
  }
  throw new Error(`Não consegui deixar a tela de Relatórios pronta após 3 tentativas. ${ultimoErro?.message||''}`.trim());
}
async function openReport(page){
  const name=config.relatorioNome,code=name.split(' ')[0];
  if(!(await aguardarTelaRelatorios(page,TIMEOUT)))throw new Error('A tela de Relatórios não está pronta para iniciar a busca.');
  const search=page.locator('input[placeholder*="Buscar" i]').first();
  if(await search.count()){
    await search.fill(code);
    await search.press('Enter').catch(()=>{});
    await page.locator('chb-relatorio-favorito-title').filter({hasText:code}).first().waitFor({state:'visible',timeout:TIMEOUT}).catch(()=>{});
  }

  let clicked=false;
  const comp=page.locator('chb-relatorio-favorito-title').filter({hasText:code}).first();
  if(await comp.count()){
    const title=comp.locator('div.mt-1.ml-2').first();
    if(await title.count()){
      log('Clicando diretamente no título do relatório UP.');
      await title.click();
      clicked=true;
    }
  }

  if(!clicked){
    let txt=page.getByText(name,{exact:false}).first();
    if(!(await txt.count())) txt=page.getByText(new RegExp(code+'.*GAPS.*UP','i')).first();
    await txt.waitFor({state:'visible',timeout:TIMEOUT});
    await txt.click();
    clicked=true;
  }

  if(!clicked) throw new Error(`Não consegui abrir o relatório UP ${name}.`);

  // O Athena às vezes pede uma confirmação intermediária para entrar no relatório/mês.
  await tratarConfirmacaoEntradaAthena(page,8000).catch(()=>0);

  const ex=page.getByRole('button',{name:/^Exportar$/i}).last();
  const fimExport=Date.now()+TIMEOUT;
  while(Date.now()<fimExport){
    if(await ex.count()&&await ex.isVisible().catch(()=>false))break;
    await tratarConfirmacaoEntradaAthena(page,650).catch(()=>0);
    await sleep(250);
  }
  if(!(await ex.count())||!(await ex.isVisible().catch(()=>false)))throw new Error('Cliquei no relatório UP, mas a janela de Exportar não abriu.');
  log('Janela correta de exportação aberta.');
  await saveAuthState(page);
}
async function abrirRelatorioComRecuperacao(page){
  let ultimoErro=null;
  for(let tentativa=1;tentativa<=3;tentativa++){
    try{await openReports(page);await openReport(page);return;}
    catch(e){ultimoErro=e;log(`Falha ao abrir o relatório na tentativa ${tentativa}/3: ${e.message}`);await saveDebug(page,`abrir_relatorio_tentativa_${tentativa}`);if(tentativa<3){log('Reiniciando a etapa Athena -> Relatórios -> busca, sem continuar do ponto quebrado...');await page.goto(config.athenaUrl,{waitUntil:'domcontentloaded',timeout:LOGIN_TIMEOUT}).catch(()=>{});await ensureLogin(page).catch(()=>{});await tratarConfirmacaoEntradaAthena(page,4500).catch(()=>0);}}
  }
  throw new Error(`Não consegui abrir ${config.relatorioNome} após 3 tentativas completas. ${ultimoErro?.message||''}`.trim());
}
async function setDate(inp,val){await inp.click(); await inp.fill(val); await inp.dispatchEvent('input').catch(()=>{}); await inp.dispatchEvent('change').catch(()=>{}); await inp.press('Tab').catch(()=>{}); await sleep(300); if(await inp.inputValue()!==val)throw new Error(`Falha ao preencher data ${val}.`)}
async function chooseAutocomplete(page,labelText,value){const lab=page.getByText(new RegExp(labelText,'i')).first(); let inp=null; if(await lab.count()){const c=lab.locator('xpath=ancestor::*[self::div or self::label][1]//input[not(@type="date")]').first(); if(await c.count())inp=c} if(!inp){const inputs=page.locator('input:not([type="date"]):visible'); inp=inputs.nth(labelText.toLowerCase().includes('linha')?1:0)} await inp.click(); await inp.fill(value).catch(()=>{}); await sleep(500); let opt=page.getByText(new RegExp(`^${value.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}$`,'i')).last(); if(await opt.count()) await opt.click(); else {await inp.press('ArrowDown').catch(()=>{}); await inp.press('Enter').catch(()=>{})} await sleep(400)}
async function configure(page){await tratarConfirmacaoEntradaAthena(page,1200).catch(()=>false); const r=expectedRange(); const ds=page.getByText('Data Início',{exact:false}).first(); if(await ds.count())await ds.click().catch(()=>{}); const ins=page.locator('input[type="date"]:visible'); if(await ins.count()<2)throw new Error('Não encontrei os dois campos de data.'); await setDate(ins.nth(0),ymd(r.first)); await setDate(ins.nth(1),ymd(r.today)); log(`Período confirmado na tela: ${dmy(r.first)} até ${dmy(r.today)}.`); await chooseAutocomplete(page,'Área Funcional',config.areaFuncional); log('Área Funcional = Packaging.'); await chooseAutocomplete(page,'Linha',config.linhaAthena); log(`Linha = ${config.linhaAthena}.`); return r}
async function exportAthena(page,r){
  const b=page.getByRole('button',{name:/^Exportar$/i}).last();
  const [dl]=await Promise.all([
    page.waitForEvent('download',{timeout:120000}),
    b.click()
  ]);

  let fn=dl.suggestedFilename()||'relatorio-generico.xlsx';
  if(!/\.xlsx?$/i.test(fn))fn+='.xlsx';

  // Valida o período pelo nome sugerido ANTES de arquivar.
  const tempName=path.join(downloadsDir,fn);
  validateFilename(tempName,r);

  fs.mkdirSync(UP_REPORT_DIR,{recursive:true});
  const target=path.join(UP_REPORT_DIR,fn);

  if(fs.existsSync(target)){
    const hist=path.join(UP_REPORT_DIR,'Historico');
    fs.mkdirSync(hist,{recursive:true});
    const ext=path.extname(fn), base=path.basename(fn,ext);
    const backup=path.join(hist,`${base}_${nowStamp()}${ext}`);
    fs.copyFileSync(target,backup);
    log(`Relatório UP anterior preservado em: ${backup}`);
  }

  await dl.saveAs(target);

  if(!fs.existsSync(target)||fs.statSync(target).size<1000){
    throw new Error(`Excel UP não foi salvo corretamente em ${UP_REPORT_DIR}.`);
  }

  validateFilename(target,r);
  log(`Relatório UP salvo em pasta fixa: ${target}`);
  return target;
}

function textoContemData(texto,data){
  const dd=p2(data.getDate()), mm=p2(data.getMonth()+1), yyyy=data.getFullYear(), yy=String(yyyy).slice(-2);
  const candidatos=[
    `${dd}/${mm}/${yyyy}`,
    `${dd}/${mm}/${yy}`,
    `${yyyy}-${mm}-${dd}`,
    `${dd}-${mm}-${yyyy}`
  ];
  return candidatos.some(v=>texto.includes(v));
}

function validarRelatorioTemDiaAtual(texto,range){
  if(config.exigirDadosDoDia===false)return;
  if(!textoContemData(texto,range.today)){
    throw new Error(
      `O relatório UP foi gerado até ${dmy(range.today)}, mas não encontrei nenhuma linha de dados do dia ${dmy(range.today)}. `+
      `A Central NÃO marcará sucesso para evitar atualizar o Portal UP com base incompleta.`
    );
  }
  log(`Dados do dia ${dmy(range.today)} encontrados no relatório UP.`);
}


function normalizarCabecalho(v){
  return String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
}

function parseTSVAutomacao(text){
  const rows=[];let row=[],cell='',q=false;
  for(let i=0;i<text.length;i++){
    const ch=text[i],nx=text[i+1];
    if(ch==='"'){
      if(q&&nx==='"'){cell+='"';i++}else q=!q;
    }else if(ch==='\t'&&!q){
      row.push(cell);cell='';
    }else if((ch==='\n'||ch==='\r')&&!q){
      if(ch==='\r'&&nx==='\n')i++;
      row.push(cell);cell='';
      if(row.some(v=>String(v).trim()!==''))rows.push(row);
      row=[];
    }else cell+=ch;
  }
  row.push(cell);
  if(row.some(v=>String(v).trim()!==''))rows.push(row);
  return rows;
}

function isoDataAutomacao(v){
  const s=String(v??'').trim();
  let m=s.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);
  if(m)return `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`;
  m=s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if(m)return `${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`;
  return '';
}

function horaAutomacao(v){
  const s=String(v??'').trim();
  const m=s.match(/(\d{1,2}):(\d{2})/);
  return m?`${m[1].padStart(2,'0')}:${m[2]}`:'';
}

function resumoRelatorioUP(text,range){
  const matrix=parseTSVAutomacao(text);
  if(matrix.length<2)throw new Error('Não consegui interpretar o relatório UP para validação final.');

  const headers=matrix[0].map(normalizarCabecalho),idx={};
  headers.forEach((h,i)=>{if(h)idx[h]=i});
  const get=(r,n)=>{const i=idx[normalizarCabecalho(n)];return i===undefined?'':(r[i]??'')};

  const period=`${range.today.getFullYear()}-${p2(range.today.getMonth()+1)}`;
  const keys=new Set();

  for(let i=1;i<matrix.length;i++){
    const r=matrix[i];
    const linha=String(get(r,'Linha')||'');
    if(linha&&!/L504/i.test(linha))continue;

    const item=normalizarCabecalho(get(r,'Item de Processo'));
    if(!item.includes('unidade de pasteurizacao termografo'))continue;

    const d=isoDataAutomacao(get(r,'Data coleta'));
    const h=horaAutomacao(get(r,'Hora coleta'));
    if(!d||!h||!d.startsWith(period))continue;

    const lote=String(get(r,'Lote')||'').trim();
    const produto=String(get(r,'Resultante')||'').trim();
    const turno=String(get(r,'Turno')||'').trim();
    keys.add([d,h,lote,produto,turno].join('|'));
  }

  const ordenados=[...keys].map(k=>{
    const [d,h]=k.split('|');
    return `${d}T${h}:00`;
  }).sort();

  if(!ordenados.length)throw new Error(`Relatório UP não possui medições válidas de ${period}.`);

  return {period,n:ordenados.length,lastDt:ordenados[ordenados.length-1]};
}

function lerEmbeddedUP(file){
  const html=fs.readFileSync(file,'utf8');
  const m=html.match(/<script[^>]+id=["']embeddedOverrideData["'][^>]*>([\s\S]*?)<\/script>/i);
  if(!m)throw new Error('Não encontrei embeddedOverrideData no index.html gerado.');

  let store;
  try{store=JSON.parse(m[1])}catch(e){throw new Error('embeddedOverrideData do index.html está inválido.')}
  return store;
}

function validarIndexContraRelatorio(file,text,range){
  const esperado=resumoRelatorioUP(text,range);
  const store=lerEmbeddedUP(file);
  const mes=store?.months?.[esperado.period];
  const recs=Array.isArray(mes?.records)?mes.records:[];

  if(recs.length!==esperado.n){
    throw new Error(
      `Validação UP falhou: relatório possui ${esperado.n} medições do mês, `+
      `mas o index gerado incorporou ${recs.length}.`
    );
  }

  const datas=recs.map(r=>String(r.dt||`${r.d||''}T${r.h||'00:00'}:00`)).filter(Boolean).sort();
  const ultimo=datas[datas.length-1]||'';

  if(ultimo!==esperado.lastDt){
    throw new Error(
      `Validação UP falhou: última medição do relatório é ${esperado.lastDt}, `+
      `mas o index gerado termina em ${ultimo||'sem data'}.`
    );
  }

  log(`Validação estrutural UP OK: ${esperado.n} medições no mês; última = ${esperado.lastDt}.`);
}

function validarIndexTemDiaAtual(file,range){
  if(config.exigirDadosDoDia===false)return;
  const html=fs.readFileSync(file,'utf8');
  if(!textoContemData(html,range.today)){
    throw new Error(
      `O index.html foi gerado, mas o dia ${dmy(range.today)} não aparece na base incorporada. `+
      `O processo será marcado como ERRO.`
    );
  }
  log(`Validação final: o dia ${dmy(range.today)} está presente no Portal UP gerado.`);
}

function copyExcel(file){const out=path.join(os.tmpdir(),`up_${Date.now()}.txt`); execFileSync('powershell.exe',['-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',path.join(ROOT,'copiar_excel.ps1'),'-Arquivo',file,'-Saida',out],{stdio:'inherit',windowsHide:false}); const txt=fs.readFileSync(out,'utf8').replace(/^\uFEFF/,''); try{fs.rmSync(out,{force:true})}catch(_){} if(!txt.trim())throw new Error('Conteúdo copiado do Excel ficou vazio.'); return txt}
async function openPortal(page){if(!fs.existsSync(config.portalUpPath))throw new Error(`Index do Portal UP não encontrado: ${config.portalUpPath}`); await autorizarPortal504(page); await page.goto(pathToFileURL(config.portalUpPath).href,{waitUntil:'domcontentloaded',timeout:LOGIN_TIMEOUT}); const end=Date.now()+LOGIN_TIMEOUT; while(Date.now()<end){if(await page.getByText(/Atualizar Dados/i).count()||await page.locator('button[data-page="atualizar"],button[data-page="update"]').count())return; await sleep(1000)} throw new Error('Não consegui abrir o Portal UP.')}
async function updatePortal(page,text){let nav=page.locator('button[data-page="atualizar"],button[data-page="update"]').first(); if(await nav.count())await nav.click(); else await page.getByRole('button',{name:/Atualizar Dados/i}).click(); await sleep(500); const section=page.locator('#atualizar,#update').filter({visible:true}).first(); if(await section.count())await section.waitFor({state:'visible'});
  const monthLabel=currentMonthYearLabel(); const sel=page.locator('#atualizar select:visible,#update select:visible').first(); if(await sel.count()){await sel.selectOption({label:monthLabel}).catch(async()=>{const opts=await sel.locator('option').allTextContents(); const hit=opts.find(x=>x.toLowerCase().includes(currentMonthLong().toLowerCase())); if(hit)await sel.selectOption({label:hit})}); log(`Mês de destino: ${await sel.locator('option:checked').innerText().catch(()=>monthLabel)}`)}
  const paste=page.locator('#pasteReport').first(); await paste.waitFor({state:'visible'}); await paste.evaluate((el,v)=>{el.value=v; el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true}))},text);
  let btn=page.getByRole('button',{name:/^Atualizar mês$/i}).first(); if(!(await btn.count()))btn=page.locator('#processPaste').first();
  let dialogMessage=''; const dialogP=new Promise(resolve=>page.once('dialog',async d=>{dialogMessage=d.message(); log(`Confirmação Portal UP: ${dialogMessage}`); await d.accept(); resolve()}));
  const clickP=btn.click(); await Promise.race([Promise.all([clickP.catch(()=>{}),dialogP]),sleep(1800)]).catch(()=>{}); await sleep(1200);
  const st=page.locator('#updateStatus').first(); const end=Date.now()+TIMEOUT; let msg=''; while(Date.now()<end){msg=(await st.innerText().catch(()=>''))||''; if(/atualizado|sucesso|medições/i.test(msg))break; if(/erro|falha|inválid/i.test(msg))throw new Error(`Portal UP rejeitou relatório: ${msg}`); await sleep(400)} if(!/atualizado|sucesso|medições/i.test(msg))throw new Error(`Portal UP não confirmou a atualização. Status: ${msg}`); log(msg.replace(/\s+/g,' ').trim())}
function validateIndex(file){if(!fs.existsSync(file))throw new Error(`Arquivo não encontrado: ${file}`); const s=fs.statSync(file); if(s.size<100000)throw new Error(`HTML gerado parece incompleto (${s.size} bytes).`); const t=fs.readFileSync(file,'utf8'); if(!/UP Linha 504|UP 504/i.test(t)||!/embeddedOverrideData/i.test(t))throw new Error('HTML não passou na validação do Portal UP.')}
function backup(){const dest=config.portalUpPath;if(!fs.existsSync(dest))return null; const dir=path.join(path.dirname(dest),'Backups_Automacao_UP'); fs.mkdirSync(dir,{recursive:true}); const b=path.join(dir,`index_${nowStamp()}.html`); fs.copyFileSync(dest,b); validateIndex(b); log(`Backup preservado em: ${b}`); return b}
function replace(newFile){validateIndex(newFile); const dest=config.portalUpPath,dir=path.dirname(dest),tmp=path.join(dir,'index.__novo__.html'),old=path.join(dir,'index.__anterior__.html'); backup(); try{fs.rmSync(tmp,{force:true});fs.rmSync(old,{force:true})}catch(_){} fs.copyFileSync(newFile,tmp);validateIndex(tmp); if(fs.existsSync(dest))fs.renameSync(dest,old); try{fs.renameSync(tmp,dest);validateIndex(dest);if(fs.existsSync(old))fs.rmSync(old,{force:true});fs.rmSync(newFile,{force:true});log('Index oficial substituído e backup mantido.')}catch(e){if(!fs.existsSync(dest)&&fs.existsSync(old))fs.renameSync(old,dest);throw e}}
async function generate(page,test){const target=path.join(downloadsDir,test?`index_UP_TESTE_${nowStamp()}.html`:'index.html'); try{fs.rmSync(target,{force:true})}catch(_){} const button=page.locator('#exportPortal').first(); const [dl]=await Promise.all([page.waitForEvent('download',{timeout:120000}),button.click()]); await dl.saveAs(target); validateIndex(target); if(test){log(`Index de TESTE gerado: ${target}`);return target} replace(target); return config.portalUpPath}
async function main(){
  log(`Limite de memória Node: ${Math.round(v8.getHeapStatistics().heap_size_limit/1024/1024)} MB.`);
  log(`Pasta fixa dos relatórios UP: ${UP_REPORT_DIR}`);
  const total=MODE==='athena'?6:MODE==='portal'?7:11;
  let browser,page,excel;
  let range=expectedRange();
  try{
    step(1,total,'Abrindo Chrome controlado pela automação...');
    ({browser,page}=await launch());

    if(MODE!=='portal'){
      step(2,total,'Abrindo Athena...');
      ({browser,page}=await openAthena(browser,page));

      step(3,total,'Abrindo Relatórios e aguardando a lista ficar pronta...');
      await openReports(page);

      step(4,total,`Localizando ${config.relatorioNome} com recuperação automática...`);
      await abrirRelatorioComRecuperacao(page);

      step(5,total,'Configurando período, Packaging e Linha 504...');
      range=await configure(page);

      step(6,total,`Exportando Excel do UP para ${UP_REPORT_DIR}...`);
      excel=await exportAthena(page,range);
      log(`Excel UP: ${excel}`);

      if(MODE==='athena'){
        const txtTeste=copyExcel(excel);
        validarRelatorioTemDiaAtual(txtTeste,range);
        log('TESTE ATHENA UP concluído. Nenhuma alteração no Portal UP.');
        return;
      }
    }else{
      excel=newestGenericExcel();
      if(!excel)throw new Error(`Nenhum relatorio-generico_*.xlsx encontrado em ${UP_REPORT_DIR} ou Downloads.`);
      validateFilename(excel,range);
      step(2,total,`Usando Excel mais recente: ${excel}`);
    }

    const b=MODE==='portal'?3:7;
    step(b,total,'Abrindo Excel e copiando todos os dados...');
    const text=copyExcel(excel);
    log(`Dados copiados: ${text.length.toLocaleString('pt-BR')} caracteres.`);

    // Evita o falso "SUCESSO" observado quando o arquivo cobria o período,
    // mas a base não continha nenhuma medição do dia atual.
    validarRelatorioTemDiaAtual(text,range);

    step(b+1,total,'Abrindo index.html do Portal UP...');
    await openPortal(page);

    step(b+2,total,`Atualizar Dados -> ${currentMonthYearLabel()} -> colar -> Atualizar mês...`);
    await updatePortal(page,text);

    step(b+3,total,MODE==='portal'?'Gerando HTML de TESTE em Downloads...':'Gerando HTML atualizado, criando backup e substituindo produção...');
    const out=await generate(page,MODE==='portal');
    validateIndex(out);
    validarIndexTemDiaAtual(out,range);
    validarIndexContraRelatorio(out,text,range);

    step(b+4,total,MODE==='portal'?'TESTE DO PORTAL UP CONCLUÍDO COM SUCESSO.':'CONCLUÍDO COM SUCESSO.');
    if(MODE!=='portal')log(`Portal UP atualizado: ${config.portalUpPath}`);
  }catch(e){
    console.error(`\nERRO: ${e.message}`);
    await saveDebug(page,'erro');
    process.exitCode=1;
    if(page){
      log('A janela ficará aberta por 60 segundos para diagnóstico.');
      await sleep(60000);
    }
  }finally{
    if(page&&!config.manterBrowserAbertoAoFinal){try{await page.context().close()}catch(_){}}
    if(browser&&!config.manterBrowserAbertoAoFinal){try{await browser.close()}catch(_){}}
  }
}
main();
