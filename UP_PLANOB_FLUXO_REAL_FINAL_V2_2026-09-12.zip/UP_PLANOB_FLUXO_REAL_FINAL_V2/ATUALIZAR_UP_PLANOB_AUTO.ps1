﻿$ErrorActionPreference = "Stop"

$PortalUp = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal Qualidade\Portal UP\index.html"
$DownloadsPortal = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal manutenção\Downloads"
$RelatoriosUp = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Relatórios UP"

$PortalDir = Split-Path $PortalUp -Parent
$TempHtml = Join-Path $PortalDir "UP_PLANOB_EXECUCAO_AUTO.html"
$BackupDir = Join-Path $PortalDir "Backups_PlanoB_UP"
$LogDir = Join-Path $PortalDir "Logs_PlanoB_UP"
$Timeout = 120

function Log([string]$m,[string]$c="Gray"){
  Write-Host ("[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"),$m) -ForegroundColor $c
}
function Release-Com($o){
  if($null -ne $o){try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($o)}catch{}}
}
function PeriodoAtual(){
  $h=(Get-Date).Date
  @{Periodo=$h.ToString("yyyy-MM"); Hoje=$h.ToString("yyyy-MM-dd"); Inicio=(Get-Date -Year $h.Year -Month $h.Month -Day 1)}
}
function ValidarPeriodoNome($f){
  $m=[regex]::Match($f.Name,'^relatorio-generico_(\d{2})_(\d{2})_(\d{4})_(\d{2})_(\d{2})_(\d{4})(?: \(\d+\))?\.xlsx$')
  if(!$m.Success){throw "Nome do relatório fora do padrão esperado."}
  $de=[datetime]::ParseExact(($m.Groups[1].Value+'/'+$m.Groups[2].Value+'/'+$m.Groups[3].Value),'dd/MM/yyyy',$null)
  $ate=[datetime]::ParseExact(($m.Groups[4].Value+'/'+$m.Groups[5].Value+'/'+$m.Groups[6].Value),'dd/MM/yyyy',$null)
  $p=PeriodoAtual
  if($de.Date -ne $p.Inicio.Date -or $ate.Date -ne (Get-Date).Date){
    throw "Período inválido. Esperado $($p.Inicio.ToString('dd/MM/yyyy')) a $((Get-Date).ToString('dd/MM/yyyy'))."
  }
}
function ValidarPortal([string]$arq){
  if(!(Test-Path $arq)){throw "HTML não encontrado: $arq"}
  $fi=Get-Item $arq
  if($fi.Length -lt 100000){throw "HTML incompleto: $($fi.Length) bytes."}
  $h=[IO.File]::ReadAllText($arq,[Text.Encoding]::UTF8)
  if($h -notmatch 'UP Linha 504|UP 504'){throw "Arquivo não parece ser o Portal UP."}
  if($h -notmatch 'embeddedOverrideData'){throw "Base embeddedOverrideData ausente."}
  return $h
}
function ResumoMes([string]$arq,[string]$periodo,[string]$hoje){
  $h=ValidarPortal $arq
  $m=[regex]::Match($h,'<script[^>]+id=["'']embeddedOverrideData["''][^>]*>([\s\S]*?)</script>',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
  if(!$m.Success){throw "Não consegui ler a base incorporada do UP."}
  try{$s=$m.Groups[1].Value | ConvertFrom-Json}catch{throw "Base incorporada inválida."}
  $prop=$s.months.PSObject.Properties[$periodo]
  if($null -eq $prop){throw "Mês $periodo não encontrado no HTML gerado."}
  $recs=@($prop.Value.records)
  if($recs.Count -lt 1){throw "Mês $periodo sem medições."}
  $temHoje=@($recs | Where-Object {[string]$_.d -eq $hoje}).Count -gt 0
  if(!$temHoje){throw "HTML gerado não contém medição de hoje ($hoje)."}
  return $recs.Count
}

$excel=$null;$wb=$null;$ws=$null;$range=$null;$logFile=$null
try{
  Clear-Host
  Write-Host "====================================================" -ForegroundColor Cyan
  Write-Host "      UP 504 - PLANO B - FLUXO REAL FINAL V2" -ForegroundColor Cyan
  Write-Host "====================================================" -ForegroundColor Cyan
  Write-Host "Atualizar Dados -> mês -> colar Excel -> Atualizar mês -> Gerar HTML -> Backup -> index.html" -ForegroundColor White
  Write-Host ""

  if(!(Test-Path $PortalUp)){throw "index.html do Portal UP não encontrado."}
  New-Item -ItemType Directory -Force -Path $BackupDir,$LogDir | Out-Null
  $logFile=Join-Path $LogDir ("auto_"+(Get-Date -Format "yyyyMMdd_HHmmss")+".log")
  Start-Transcript -Path $logFile -Append | Out-Null

  Log "Localizando relatório UP..." "Cyan"
  $cands=@()
  foreach($d in @($RelatoriosUp,$DownloadsPortal)){
    if(Test-Path $d){$cands += Get-ChildItem $d -Filter "relatorio-generico_*.xlsx" -File -ErrorAction SilentlyContinue}
  }
  $arquivo=$cands | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if(!$arquivo){throw "Nenhum relatorio-generico_*.xlsx encontrado."}
  ValidarPeriodoNome $arquivo
  Log "Relatório: $($arquivo.FullName)" "Green"

  $html=ValidarPortal $PortalUp

  # Validação do HTML real do UP: somente os elementos que o fluxo manual usa.
  foreach($item in @('id="updateMonthTarget"','id="pasteReport"','id="processPaste"','id="updateStatus"','id="exportPortal"')){
    if($html -notlike "*$item*"){throw "Estrutura necessária ausente no Portal UP: $item"}
  }

  Log "Abrindo Excel e copiando a tabela..." "Cyan"
  $excel=New-Object -ComObject Excel.Application
  $excel.Visible=$false
  $excel.DisplayAlerts=$false
  $wb=$excel.Workbooks.Open($arquivo.FullName,0,$true)
  $ws=$wb.Worksheets.Item(1)
  $range=$ws.UsedRange
  $linhas=[int]$range.Rows.Count
  $colunas=[int]$range.Columns.Count
  Log "Planilha: $linhas linhas x $colunas colunas." "Green"

  $dados=$range.Value2
  $sb=New-Object Text.StringBuilder
  for($i=1;$i -le $linhas;$i++){
    $campos=New-Object System.Collections.Generic.List[string]
    for($j=1;$j -le $colunas;$j++){
      $v=$dados[$i,$j];if($null -eq $v){$v=""}
      $campos.Add((([string]$v) -replace "`r`n|`n|`r"," "))
    }
    [void]$sb.AppendLine(($campos -join "`t"))
  }
  $texto=$sb.ToString()

  $wb.Close($false);$excel.Quit()
  Release-Com $range;Release-Com $ws;Release-Com $wb;Release-Com $excel
  $range=$null;$ws=$null;$wb=$null;$excel=$null
  [GC]::Collect();[GC]::WaitForPendingFinalizers()

  $p=PeriodoAtual
  $periodo=$p.Periodo
  $b64=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($texto))
  $inicioGeracao=Get-Date

  $inj=@"
<script id="upPlanoBInjectorAuto">
(function(){
 const B64='$b64', PERIODO='$periodo';
 const wait=ms=>new Promise(r=>setTimeout(r,ms));
 const dec=b=>{const x=atob(b),u=new Uint8Array(x.length);for(let i=0;i<x.length;i++)u[i]=x.charCodeAt(i);return new TextDecoder('utf-8').decode(u)};
 const esc=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
 function toast(t,k){let e=document.getElementById('planob-status');if(!e){e=document.createElement('div');e.id='planob-status';e.style.cssText='position:fixed;right:18px;bottom:18px;z-index:999999;max-width:580px;padding:14px 16px;border-radius:12px;background:#111827;color:white;font:14px Arial;border:2px solid #60a5fa;box-shadow:0 10px 30px #0006';document.body.appendChild(e)}e.style.borderColor=k==='erro'?'#ef4444':k==='ok'?'#22c55e':'#60a5fa';e.innerHTML=t}
 async function run(){
   try{
     document.querySelector('button[data-page="atualizar"]')?.click();
     await wait(400);

     const sel=document.getElementById('updateMonthTarget');
     const paste=document.getElementById('pasteReport');
     const atualizar=document.getElementById('processPaste');
     const status=document.getElementById('updateStatus');
const faltando=[];
     if(!sel)faltando.push('mês');
     if(!paste)faltando.push('campo colar');
     if(!atualizar)faltando.push('Atualizar mês');
     if(!status)faltando.push('status');
     if(typeof exportPortal!=='function')faltando.push('função exportPortal');
     if(faltando.length)throw new Error('Elementos não encontrados: '+faltando.join(', '));

     sel.value=PERIODO;
     sel.dispatchEvent(new Event('change',{bubbles:true}));

     paste.value=dec(B64);
     paste.dispatchEvent(new Event('input',{bubbles:true}));
     paste.dispatchEvent(new Event('change',{bubbles:true}));

     toast('<b>PLANO B UP</b><br>Mês selecionado: '+esc(PERIODO)+'<br>Excel colado. Atualizando mês...','info');
     atualizar.click();

     const limite=Date.now()+30000;
     let msg='';
     while(Date.now()<limite){
       msg=(status.innerText||status.textContent||'').trim();
       if(/substitu[ií]do com sucesso/i.test(msg))break;
       if(/erro|inv[aá]lid|falha|bloque/i.test(msg))throw new Error(msg);
       await wait(250);
     }
     if(!/substitu[ií]do com sucesso/i.test(msg))throw new Error('Portal não confirmou Atualizar mês. Status: '+msg);

     toast('<b>PLANO B UP</b><br>'+esc(msg)+'<br><br>Gerando HTML atualizado para compartilhar...','info');
     exportPortal();
     await wait(1000);
     toast('<b>PLANO B UP</b><br>'+esc(msg)+'<br>HTML gerado. Aguardando PowerShell finalizar backup e troca do index...','ok');
   }catch(e){
     toast('<b>PLANO B UP - BLOQUEADO</b><br>'+esc(e.message||e),'erro');
     console.error(e);
   }
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(run,700));else setTimeout(run,700);
})();
</script>
"@

  if($html -match '</body>'){$html=$html -replace '</body>',($inj+"`r`n</body>")}else{$html+=$inj}
  [IO.File]::WriteAllText($TempHtml,$html,(New-Object Text.UTF8Encoding($false)))
  Log "HTML temporário criado." "Green"

  # Pastas onde o navegador pode colocar o download.
  $pastas=New-Object System.Collections.Generic.List[string]
  foreach($d in @($DownloadsPortal,(Join-Path $env:USERPROFILE "Downloads"),$PortalDir)){
    if($d -and (Test-Path $d) -and !$pastas.Contains($d)){[void]$pastas.Add($d)}
  }
  try{
    $sd=(New-Object -ComObject Shell.Application).Namespace('shell:Downloads').Self.Path
    if($sd -and (Test-Path $sd) -and !$pastas.Contains($sd)){[void]$pastas.Add($sd)}
  }catch{}

  Log "Abrindo Portal UP automático..." "Cyan"
  Start-Process $TempHtml

  Log "Aguardando o HTML nativo do UP aparecer em Downloads (mesmo modelo do TPO)..." "Cyan"
  $gerado=$null
  $limite=(Get-Date).AddSeconds($Timeout)

  while((Get-Date) -lt $limite -and !$gerado){
    $arquivos=Get-ChildItem $DownloadsPortal -Filter "Portal_UP_L504_atualizado_*.html" -File -ErrorAction SilentlyContinue |
      Where-Object {
        $_.LastWriteTime -ge $inicioGeracao.AddSeconds(-3) -and
        $_.Length -gt 100000
      } | Sort-Object LastWriteTime -Descending

    foreach($a in $arquivos){
      try{
        $q=ResumoMes $a.FullName $periodo $p.Hoje
        if($q -gt 0){$gerado=$a;break}
      }catch{}
    }

    if(!$gerado){
      foreach($d in $pastas){
        if($d -eq $DownloadsPortal){continue}
        $arquivos=Get-ChildItem $d -Filter "Portal_UP_L504_atualizado_*.html" -File -ErrorAction SilentlyContinue |
          Where-Object {
            $_.LastWriteTime -ge $inicioGeracao.AddSeconds(-3) -and
            $_.Length -gt 100000 -and
            $_.FullName -ne $PortalUp -and
            $_.FullName -ne $TempHtml
          } | Sort-Object LastWriteTime -Descending
        foreach($a in $arquivos){
          try{
            $q=ResumoMes $a.FullName $periodo $p.Hoje
            if($q -gt 0){$gerado=$a;break}
          }catch{}
        }
        if($gerado){break}
      }
    }

    if(!$gerado){Start-Sleep -Milliseconds 500}
  }

  if(!$gerado){throw "Atualizar mês funcionou, mas o HTML gerado não foi localizado. Produção NÃO foi alterada."}
  Log "HTML gerado encontrado: $($gerado.FullName)" "Green"

  $qNova=ResumoMes $gerado.FullName $periodo $p.Hoje
  Log "HTML validado: $qNova medições no mês." "Green"

  # Remove o injetor temporário antes de entrar em produção.
  $novo=[IO.File]::ReadAllText($gerado.FullName,[Text.Encoding]::UTF8)
  $novo=[regex]::Replace($novo,'<script[^>]+id=["'']upPlanoBInjectorAuto["''][^>]*>[\s\S]*?</script>','',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
  $novo=[regex]::Replace($novo,'<div[^>]+id=["'']planob-status["''][^>]*>[\s\S]*?</div>','',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
  [IO.File]::WriteAllText($gerado.FullName,$novo,(New-Object Text.UTF8Encoding($false)))
  [void](ValidarPortal $gerado.FullName)

  # Backup exatamente como solicitado.
  $backup=Join-Path $BackupDir ("index_backup_"+(Get-Date -Format "yyyyMMdd_HHmmss")+".html")
  Move-Item -LiteralPath $PortalUp -Destination $backup -Force
  Log "Index atual movido para backup: $backup" "Green"

  try{
    Copy-Item -LiteralPath $gerado.FullName -Destination $PortalUp -Force
    [void](ValidarPortal $PortalUp)
    $qProd=ResumoMes $PortalUp $periodo $p.Hoje
    Log "Novo index.html validado na raiz: $qProd medições." "Green"
  }catch{
    if(Test-Path $PortalUp){Remove-Item $PortalUp -Force -ErrorAction SilentlyContinue}
    Copy-Item -LiteralPath $backup -Destination $PortalUp -Force
    throw
  }

  # Limpeza.
  Remove-Item -LiteralPath $gerado.FullName -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $TempHtml -Force -ErrorAction SilentlyContinue

  Get-ChildItem $PortalDir -Filter "index_backup*.html" -File -ErrorAction SilentlyContinue |
    ForEach-Object {
      $dest=Join-Path $BackupDir $_.Name
      if(Test-Path $dest){
        $dest=Join-Path $BackupDir (([IO.Path]::GetFileNameWithoutExtension($_.Name))+"_"+(Get-Date -Format "yyyyMMdd_HHmmss")+".html")
      }
      Move-Item $_.FullName $dest -Force
    }

  Write-Host ""
  Write-Host "====================================================" -ForegroundColor Green
  Write-Host "       UP 504 ATUALIZADO COM SUCESSO - PLANO B" -ForegroundColor Green
  Write-Host "====================================================" -ForegroundColor Green
  Write-Host "Produção: $PortalUp" -ForegroundColor Cyan
  Write-Host "Backup: $backup" -ForegroundColor DarkGray
  Write-Host ""
  Start-Sleep -Seconds 8
}
catch{
  Write-Host ""
  Write-Host "====================================================" -ForegroundColor Red
  Write-Host "       ATUALIZAÇÃO UP BLOQUEADA - PRODUÇÃO SEGURA" -ForegroundColor Red
  Write-Host "====================================================" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  if($logFile){Write-Host "Log: $logFile" -ForegroundColor DarkGray}
  Read-Host "Pressione ENTER para fechar"
  exit 1
}
finally{
  if($wb){try{$wb.Close($false)}catch{}}
  if($excel){try{$excel.Quit()}catch{}}
  Release-Com $range;Release-Com $ws;Release-Com $wb;Release-Com $excel
  try{Stop-Transcript | Out-Null}catch{}
}
