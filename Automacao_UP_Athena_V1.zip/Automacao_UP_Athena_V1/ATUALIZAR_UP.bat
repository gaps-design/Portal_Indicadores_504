@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Atualizar UP 504
set CHROME_ENCONTRADO=
for /f "tokens=1" %%A in ('tasklist /FI "IMAGENAME eq chrome.exe" /NH 2^>nul') do if /I "%%A"=="chrome.exe" set CHROME_ENCONTRADO=1
if defined CHROME_ENCONTRADO (
  echo [UP] Chrome aberto. Fechando antes de iniciar a automacao...
  taskkill /F /IM chrome.exe /T >nul 2>nul
  timeout /t 3 /nobreak >nul
)
if not exist node_modules call npm install
node automacao_up.js full
pause
