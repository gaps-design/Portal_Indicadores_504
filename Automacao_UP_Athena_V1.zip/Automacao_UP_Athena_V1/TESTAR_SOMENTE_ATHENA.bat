@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Teste Athena - UP
if not exist node_modules call npm install
node automacao_up.js athena
pause
