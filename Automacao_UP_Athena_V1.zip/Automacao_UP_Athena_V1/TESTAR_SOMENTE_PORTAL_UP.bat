@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Teste Portal UP
if not exist node_modules call npm install
node automacao_up.js portal
pause
