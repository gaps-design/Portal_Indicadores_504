const PORTAIS={
  gente:"../portal-gente/index.html",
  manutencao:"../portal-manutencao/index.html",
  seguranca:"../portal-seguranca/index.html",
  qualidade:"../portal-qualidade/index.html"
};
document.querySelectorAll("[data-portal]").forEach(card=>{card.href=PORTAIS[card.dataset.portal]||"#"});
function atualizarRelogio(){const d=new Date();document.getElementById("clock").innerHTML=`<strong>${d.toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"})}</strong><br>${d.toLocaleDateString("pt-BR")}`}
atualizarRelogio();setInterval(atualizarRelogio,30000);
