@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

rem Mantém a pasta técnica fora da vista no uso normal do VD.
attrib +h "%~dp0_sistema" >nul 2>&1

where node >nul 2>nul
if errorlevel 1 (
  echo [AVISO] Node.js nao foi encontrado. Abrindo o Portal sem automacao local.
  start "" "%~dp0_sistema\entrada_auto.html"
  exit /b 0
)

rem Inicia o agente minimizado. Se ele ja estiver rodando, o proprio agente evita duplicidade.
start "Central 504" /min /D "%~dp0_sistema\Central Atualizacoes" node "central_504_agent.js"
timeout /t 1 /nobreak >nul

rem Entrada automatica: cria sessao local sem expor a senha em texto puro.
start "" "%~dp0_sistema\entrada_auto.html"
endlocal
