/* =========================================================
   PORTAL DE INDICADORES | LINHA 504
========================================================= */


/* =========================================================
   CAMINHOS REAIS DOS PORTAIS

   Portal Indicadores:
   N:\Packaging\Compartilhado\Retornável\
   Usuarios\Guilherme A\Portal Indicadores\

========================================================= */

const PORTAIS = {

  gente:
    "../../../../01. Escala/504/Portal Gente/login.html",

  manutencao:
    "../../Lobby/Portal manutenção/index_programacao_operacional.html",

  seguranca:
    "../../Lobby/Portal Segurança/index_seguranca_504.html"

};


/* =========================================================
   CARDS PRINCIPAIS
========================================================= */

document
  .querySelectorAll('a[data-portal]')
  .forEach(card => {

    const portal = card.dataset.portal;

    if (PORTAIS[portal]) {
      card.href = PORTAIS[portal];
    }

  });


/* =========================================================
   QUALIDADE
   Os acessos UP, TPO e Mal Cheia ficam sempre visíveis
   no próprio card. Não há mais menu expansível.
========================================================= */


/* =========================================================
   RELÓGIO
========================================================= */

function atualizarRelogio() {

  const clock =
    document.getElementById("clock");

  if (!clock) return;


  const d = new Date();


  const hora =
    d.toLocaleTimeString(
      "pt-BR",
      {
        hour: "2-digit",
        minute: "2-digit"
      }
    );


  const data =
    d.toLocaleDateString("pt-BR");


  clock.innerHTML =
    `<strong>${hora}</strong><br>${data}`;

}


atualizarRelogio();

setInterval(
  atualizarRelogio,
  30000
);