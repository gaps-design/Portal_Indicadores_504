@echo off
setlocal
chcp 65001 >nul
title Central de Atualizações 504
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js nao foi encontrado neste VD.
  echo A Central de Atualizacoes ficara indisponivel; os portais continuam funcionando normalmente.
  pause
  exit /b 1
)
echo Iniciando agente local da Central 504...
node "%~dp0central_504_agent.js"
if errorlevel 1 pause
endlocal
