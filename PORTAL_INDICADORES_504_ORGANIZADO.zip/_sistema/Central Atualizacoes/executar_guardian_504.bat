@echo off
setlocal
chcp 65001 >nul
title Guardian 504 - Atualizacao Automatica

cd /d "%~dp0"

echo.
echo ============================================================
echo   PORTAL SEGURANCA 504 - ATUALIZACAO GUARDIAN
echo ============================================================
echo.

echo [1/3] Liberando o Chrome...
taskkill /F /IM chrome.exe >nul 2>&1
timeout /t 3 /nobreak >nul

echo [2/3] Localizando o script Guardian...

set "SCRIPT="

if exist "Atualizar_Guardian_504.js" set "SCRIPT=Atualizar_Guardian_504.js"
if not defined SCRIPT if exist "automacao_guardian.js" set "SCRIPT=automacao_guardian.js"

if not defined SCRIPT (
    echo.
    echo [ERRO] Script Guardian nao localizado nesta pasta.
    echo Procurados:
    echo   Atualizar_Guardian_504.js
    echo   automacao_guardian.js
    echo.
    exit /b 2
)

echo [OK] Script encontrado: %SCRIPT%
echo.
echo [3/3] Iniciando automacao...
echo.

node "%SCRIPT%"
set "ERRO=%ERRORLEVEL%"

echo.
if "%ERRO%"=="0" (
    echo [OK] Guardian finalizado com sucesso.
) else (
    echo [ERRO] Guardian terminou com codigo %ERRO%.
)

exit /b %ERRO%
