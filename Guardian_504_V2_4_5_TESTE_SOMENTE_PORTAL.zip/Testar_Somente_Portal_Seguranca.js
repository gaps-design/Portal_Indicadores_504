const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');
const { chromium } = require('playwright');

const BASE = __dirname;
const CFG = JSON.parse(fs.readFileSync(path.join(BASE,'config_guardian.json'),'utf8'));
const sleep = ms => new Promise(r=>setTimeout(r,ms));
const log = m => console.log(`[${new Date().toLocaleTimeString('pt-BR')}] ${m}`);
const ensureDir = p => fs.mkdirSync(p,{recursive:true});

function esperarEnter(){
  return new Promise(resolve=>{
    process.stdin.resume();
    process.stdin.once('data',()=>resolve());
  });
}

async function fecharCarrossel(pagina){
  await sleep(1200);

  const overlay = pagina.locator('#matinalOverlay').first();
  if(!(await overlay.count())) return;

  const aberto = async ()=>{
    const visivel = await overlay.isVisible().catch(()=>false);
    const classe = (await overlay.getAttribute('class').catch(()=>'')) || '';
    return visivel || /\bopen\b/i.test(classe);
  };

  if(!(await aberto())){
    await sleep(1200);
    if(!(await aberto())){
      log('Carrossel fechado.');
      return;
    }
  }

  log('Carrossel aberto. Fechando...');

  const entrar = pagina.locator('#matinalEnter').first();
  if(await entrar.count()){
    await entrar.evaluate(el=>el.click()).catch(()=>{});
    await sleep(700);
  }

  if(await aberto()){
    const fechar = pagina.locator('#matinalCloseX').first();
    if(await fechar.count()){
      await fechar.evaluate(el=>el.click()).catch(()=>{});
      await sleep(700);
    }
  }

  if(await aberto()){
    log('Removendo camada do carrossel...');
    await pagina.evaluate(()=>{
      const o=document.getElementById('matinalOverlay');
      if(o){
        o.classList.remove('open');
        o.style.display='none';
        o.style.visibility='hidden';
        o.style.pointerEvents='none';
        o.setAttribute('aria-hidden','true');
      }
      document.documentElement.style.overflow='';
      document.body.style.overflow='';
    });
    await sleep(300);
  }

  if(await aberto()) throw new Error('Carrossel continuou bloqueando o Portal.');
  log('Carrossel fechado.');
}

async function abrirAtualizarDados(pagina){
  const aba=pagina.locator('button.tab[data-view="update"]').first();
  if(!(await aba.count())) throw new Error('Aba "Atualizar dados" não encontrada.');
  await aba.evaluate(el=>el.click());
  await pagina.locator('section#update').first().waitFor({state:'visible',timeout:15000});
  await fecharCarrossel(pagina);
  log('Página "Atualizar dados" aberta.');
}

async function main(){
  console.log('============================================================');
  console.log(' TESTE SOMENTE PORTAL SEGURANÇA - V2.4.5');
  console.log(' Não acessa o Guardian e não baixa relatórios novamente.');
  console.log('============================================================');

  const arquivos = [
    ['#fileAct', path.join(CFG.output_dir,'Guardian_Comportamento_Risco.xlsx'),'Ato inseguro'],
    ['#fileIncident', path.join(CFG.output_dir,'Guardian_Incidente.xlsx'),'Incidente'],
    ['#fileRecognition', path.join(CFG.output_dir,'Guardian_Reconhecimento.xlsx'),'Reconhecimento'],
    ['#fileCondition', path.join(CFG.output_dir,'Guardian_Condicao_Risco.xlsx'),'Condição insegura']
  ];

  for(const [,arquivo,nome] of arquivos){
    if(!fs.existsSync(arquivo)) throw new Error(`Arquivo ausente (${nome}): ${arquivo}`);
  }

  const context=await chromium.launchPersistentContext(CFG.chrome_profile_dir,{
    channel:'chrome',
    headless:false,
    acceptDownloads:true,
    viewport:null,
    args:['--start-maximized']
  });

  try{
    const pagina=context.pages()[0] || await context.newPage();
    await pagina.goto(pathToFileURL(CFG.portal_index_path).href,{
      waitUntil:'domcontentloaded',
      timeout:60000
    });

    await fecharCarrossel(pagina);
    await abrirAtualizarDados(pagina);

    for(const [sel,arquivo,nome] of arquivos){
      await pagina.locator(sel).first().setInputFiles(arquivo);
      log(`Arquivo selecionado: ${nome}`);
    }

    await fecharCarrossel(pagina);

    const processar=pagina.locator('#processUploads').first();
    await processar.waitFor({state:'visible',timeout:15000});
    await processar.evaluate(el=>el.click());
    log('Clique em "Ler relatórios e atualizar" realizado.');

    const status=pagina.locator('#uploadStatus').first();
    if(await status.count()){
      const limite=Date.now()+120000;
      while(Date.now()<limite){
        const texto=(await status.innerText().catch(()=>'' )).replace(/\s+/g,' ').trim();
        if(/conclu[ií]d|sucesso|finaliz/i.test(texto)){
          log(`Processamento concluído: ${texto}`);
          break;
        }
        if(/erro|falha/i.test(texto)) throw new Error(`Portal informou erro: ${texto}`);
        await sleep(1000);
      }
    }else{
      await sleep(8000);
    }

    await fecharCarrossel(pagina);
    await abrirAtualizarDados(pagina);

    const gerar=pagina.locator('#generateIndex').first();
    await gerar.waitFor({state:'visible',timeout:15000});

    ensureDir(CFG.portal_backup_dir);

    log('Gerando novo Index...');
    const evento=pagina.waitForEvent('download',{timeout:60000});
    await gerar.evaluate(el=>el.click());
    const download=await evento;

    const temp=path.join(path.dirname(CFG.portal_index_path),`__index_novo_${Date.now()}.html`);
    await download.saveAs(temp);

    if(!fs.existsSync(temp) || fs.statSync(temp).size<10000){
      throw new Error('Novo Index parece inválido.');
    }

    const d=new Date();
    const carimbo=
      d.getFullYear()+
      String(d.getMonth()+1).padStart(2,'0')+
      String(d.getDate()).padStart(2,'0')+'_'+
      String(d.getHours()).padStart(2,'0')+
      String(d.getMinutes()).padStart(2,'0')+
      String(d.getSeconds()).padStart(2,'0');

    const backup=path.join(
      CFG.portal_backup_dir,
      `index_seguranca_504_BACKUP_${carimbo}.html`
    );

    fs.copyFileSync(CFG.portal_index_path,backup);
    fs.copyFileSync(temp,CFG.portal_index_path);
    fs.unlinkSync(temp);

    log(`Backup criado: ${backup}`);
    log('Novo Index aplicado mantendo o nome index_seguranca_504.html');
    log('=== TESTE DO PORTAL CONCLUÍDO COM SUCESSO ===');

    console.log('');
    console.log('Pressione ENTER para fechar.');
    await esperarEnter();

  }catch(e){
    console.error('');
    console.error('=== FALHA ===');
    console.error(e && e.stack ? e.stack : e);
    console.error('');
    console.error('Pressione ENTER para encerrar.');
    await esperarEnter();
  }finally{
    await context.close().catch(()=>{});
  }
}

main();
