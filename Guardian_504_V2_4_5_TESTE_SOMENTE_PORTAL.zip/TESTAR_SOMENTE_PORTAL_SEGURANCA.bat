@echo off
chcp 65001 >nul
title Teste somente Portal Seguranca
cd /d "%~dp0"

echo ============================================================
echo  TESTE SOMENTE PORTAL SEGURANCA
echo  Usa os 4 relatorios que ja estao na pasta Relatorios
echo ============================================================
echo.
node Testar_Somente_Portal_Seguranca.js
pause
