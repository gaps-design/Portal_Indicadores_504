﻿$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "============================================================"
Write-Host " SEGURANCA 504 - GUARDIAN / CENTRAL DE ATUALIZACOES"
Write-Host "============================================================"
Write-Host ""

$guardianRoot = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal Segurança\Atualizar Guardian"
$preferredScript = Join-Path $guardianRoot "Guardian_504_V2_4_1_CAMINHO_CORRIGIDO\Atualizar_Guardian_504.js"
$profileDir = Join-Path $guardianRoot "Perfil_Chrome"

function Find-GuardianScript {
    param([string]$Root, [string]$Preferred)

    if (Test-Path -LiteralPath $Preferred) {
        return (Get-Item -LiteralPath $Preferred).FullName
    }

    if (-not (Test-Path -LiteralPath $Root)) {
        throw "Pasta Guardian não localizada: $Root"
    }

    # Primeiro tenta o nome exato em qualquer subpasta.
    $exact = Get-ChildItem -LiteralPath $Root -Recurse -File -Filter "Atualizar_Guardian_504.js" -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -notmatch "\\node_modules\\" } |
        Select-Object -First 1

    if ($exact) {
        return $exact.FullName
    }

    # Fallback: qualquer JS com Guardian no nome, fora de node_modules.
    $fallback = Get-ChildItem -LiteralPath $Root -Recurse -File -Filter "*.js" -ErrorAction SilentlyContinue |
        Where-Object {
            $_.FullName -notmatch "\\node_modules\\" -and
            $_.Name -match "(?i)guardian"
        } |
        Select-Object -First 1

    if ($fallback) {
        return $fallback.FullName
    }

    throw "Script do Guardian não localizado em: $Root"
}

try {
    $script = Find-GuardianScript -Root $guardianRoot -Preferred $preferredScript

    Write-Host "[OK] Script Guardian localizado:"
    Write-Host "     $script"
    Write-Host ""

    # O erro anterior era o Chrome reutilizando uma sessão já aberta.
    Write-Host "[1/4] Fechando todas as instâncias do Chrome..."
    & taskkill.exe /F /T /IM chrome.exe *> $null

    # Aguarda de verdade até o processo sair.
    $limit = (Get-Date).AddSeconds(12)
    do {
        Start-Sleep -Milliseconds 500
        $chrome = Get-Process chrome -ErrorAction SilentlyContinue
    } while ($chrome -and (Get-Date) -lt $limit)

    if ($chrome) {
        throw "Ainda existem processos chrome.exe após a tentativa de encerramento."
    }

    Write-Host "[OK] Chrome encerrado."
    Write-Host ""

    # Limpa travas do perfil persistente usado pelo Playwright.
    Write-Host "[2/4] Limpando travas do perfil do Guardian..."
    if (Test-Path -LiteralPath $profileDir) {
        Get-ChildItem -LiteralPath $profileDir -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like "Singleton*" } |
            Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
    }
    Write-Host "[OK] Perfil liberado."
    Write-Host ""

    # Pequena folga antes do launchPersistentContext.
    Start-Sleep -Seconds 3

    Write-Host "[3/4] Iniciando automação Guardian..."
    Write-Host ""

    $scriptDir = Split-Path -Parent $script
    $scriptName = Split-Path -Leaf $script

    Push-Location $scriptDir
    try {
        & node $scriptName
        $exitCode = $LASTEXITCODE
    }
    finally {
        Pop-Location
    }

    if ($null -eq $exitCode) {
        $exitCode = 0
    }

    Write-Host ""
    Write-Host "[4/4] Finalização."

    if ($exitCode -eq 0) {
        Write-Host "[OK] Segurança/Guardian finalizado com sucesso."
        exit 0
    }
    else {
        Write-Host "[ERRO] Guardian terminou com código $exitCode."
        exit $exitCode
    }
}
catch {
    Write-Host ""
    Write-Host "[ERRO] $($_.Exception.Message)"
    exit 1
}
