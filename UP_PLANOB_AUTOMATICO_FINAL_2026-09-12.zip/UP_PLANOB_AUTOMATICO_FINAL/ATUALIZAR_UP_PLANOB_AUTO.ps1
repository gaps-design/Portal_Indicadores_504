﻿$ErrorActionPreference = "Stop"

# ============================================================
# UP 504 - PLANO B AUTOMATICO FINAL
# Modelo: mesmo fluxo aprovado no TPO.
# Athena manual; do Excel em diante, automatico.
# Sem Node / Sem Playwright.
# ============================================================

$PortalUp = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal Qualidade\Portal UP\index.html"
$Downloads = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal manutenção\Downloads"
$RelatoriosUp = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Relatórios UP"
$PortalDir = Split-Path $PortalUp -Parent
$TempHtml = Join-Path $PortalDir "UP_PLANOB_EXECUCAO_AUTO.html"
$BackupDir = Join-Path $PortalDir "Backups_PlanoB_UP"
$LogDir = Join-Path $PortalDir "Logs_PlanoB_UP"
$TimeoutDownloadSeg = 120

function Log([string]$Mensagem,[string]$Cor="Gray"){
    $hora=Get-Date -Format "HH:mm:ss"
    Write-Host "[$hora] $Mensagem" -ForegroundColor $Cor
}
function Liberar-ComObject($obj){
    if($null -ne $obj){try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($obj)}catch{}}
}
function Normalizar([object]$v){
    $s=[string]$v
    if([string]::IsNullOrWhiteSpace($s)){return ""}
    $formD=$s.Normalize([Text.NormalizationForm]::FormD)
    $sb=New-Object Text.StringBuilder
    foreach($c in $formD.ToCharArray()){
        if([Globalization.CharUnicodeInfo]::GetUnicodeCategory($c) -ne [Globalization.UnicodeCategory]::NonSpacingMark){
            [void]$sb.Append($c)
        }
    }
    return ($sb.ToString().Normalize([Text.NormalizationForm]::FormC).ToLowerInvariant().Trim())
}
function Periodo-Esperado{
    $hoje=(Get-Date).Date
    $inicio=Get-Date -Year $hoje.Year -Month $hoje.Month -Day 1
    return @{Inicio=$inicio;Hoje=$hoje;Periodo=$hoje.ToString("yyyy-MM")}
}
function Validar-PeriodoNome($arquivo){
    $m=[regex]::Match($arquivo.Name,'^relatorio-generico_(\d{2})_(\d{2})_(\d{4})_(\d{2})_(\d{2})_(\d{4})(?: \(\d+\))?\.xlsx$')
    if(!$m.Success){throw "Nome do relatório fora do padrão esperado: $($arquivo.Name)"}
    $de=[datetime]::ParseExact(($m.Groups[1].Value+'/'+$m.Groups[2].Value+'/'+$m.Groups[3].Value),'dd/MM/yyyy',$null)
    $ate=[datetime]::ParseExact(($m.Groups[4].Value+'/'+$m.Groups[5].Value+'/'+$m.Groups[6].Value),'dd/MM/yyyy',$null)
    $p=Periodo-Esperado
    if($de.Date -ne $p.Inicio.Date -or $ate.Date -ne $p.Hoje.Date){
        throw "PERÍODO BLOQUEADO. Esperado $($p.Inicio.ToString('dd/MM/yyyy')) a $($p.Hoje.ToString('dd/MM/yyyy')); arquivo indica $($de.ToString('dd/MM/yyyy')) a $($ate.ToString('dd/MM/yyyy'))."
    }
    Log "Período validado: $($de.ToString('dd/MM/yyyy')) a $($ate.ToString('dd/MM/yyyy'))." "Green"
}
function Validar-Index([string]$Arquivo){
    if(!(Test-Path $Arquivo)){throw "Index não encontrado: $Arquivo"}
    $fi=Get-Item $Arquivo
    if($fi.Length -lt 100000){throw "O HTML parece incompleto ($($fi.Length) bytes)."}
    $html=[IO.File]::ReadAllText($Arquivo,[Text.Encoding]::UTF8)
    if($html -notmatch 'UP Linha 504|UP 504'){throw "O arquivo não parece ser o Portal UP 504."}
    if($html -notmatch 'embeddedOverrideData'){throw "embeddedOverrideData não encontrado no HTML."}
    return $html
}
function Obter-ResumoIndex([string]$Arquivo,[string]$Periodo,[string]$HojeIso){
    $html=Validar-Index $Arquivo
    $m=[regex]::Match($html,'<script[^>]+id=["'']embeddedOverrideData["''][^>]*>([\s\S]*?)</script>',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if(!$m.Success){throw "Base embeddedOverrideData não encontrada no HTML."}
    try{$store=$m.Groups[1].Value | ConvertFrom-Json}catch{throw "Base incorporada do HTML inválida."}
    $prop=$store.months.PSObject.Properties[$Periodo]
    if($null -eq $prop){throw "Mês $Periodo não encontrado na base do HTML."}
    $recs=@($prop.Value.records)
    if($recs.Count -lt 1){throw "Mês $Periodo ficou sem medições."}
    $datas=@($recs | ForEach-Object {
        if($_.dt){[string]$_.dt}else{"$($_.d)T$($_.h):00"}
    } | Sort-Object)
    $ultima=if($datas.Count){$datas[-1]}else{""}
    $temHoje=@($recs | Where-Object {[string]$_.d -eq $HojeIso}).Count -gt 0
    return @{Quantidade=$recs.Count;Ultima=$ultima;TemHoje=$temHoje}
}
function Resumo-Relatorio($matrix){
    if(!$matrix -or $matrix.Count -lt 2){throw "Relatório vazio ou incompleto."}
    $cab=@($matrix[0] | ForEach-Object {Normalizar $_})
    function Idx([string[]]$nomes){
        foreach($n in $nomes){
            $nn=Normalizar $n
            $i=[Array]::IndexOf($cab,$nn)
            if($i -ge 0){return $i}
        }
        return -1
    }
    $iLinha=Idx @("Linha")
    $iItem=Idx @("Item de Processo","Item Processo")
    $iData=Idx @("Data Coleta","Data")
    $iHora=Idx @("Hora Coleta","Hora")
    $iLote=Idx @("Lote")
    $iRes=Idx @("Resultante","Valor")
    $iTurno=Idx @("Turno")
    foreach($x in @($iLinha,$iItem,$iData,$iHora)){
        if($x -lt 0){throw "Cabeçalhos essenciais do relatório UP não foram reconhecidos."}
    }

    $p=Periodo-Esperado
    $keys=New-Object 'System.Collections.Generic.HashSet[string]'
    $ultima=""
    for($r=1;$r -lt $matrix.Count;$r++){
        $row=@($matrix[$r])
        if($row.Count -le [Math]::Max($iHora,[Math]::Max($iLinha,$iItem))){continue}
        $linha=[string]$row[$iLinha]
        if($linha -notmatch 'L504|504'){continue}
        $item=Normalizar $row[$iItem]
        if($item -notlike '*unidade de pasteurizacao termografo*'){continue}
        $data=[string]$row[$iData]; $hora=[string]$row[$iHora]
        $dm=[regex]::Match($data,'^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$')
        $hm=[regex]::Match($hora,'(\d{1,2}):(\d{2})')
        if(!$dm.Success -or !$hm.Success){continue}
        $iso="$($dm.Groups[3].Value)-$($dm.Groups[2].Value.PadLeft(2,'0'))-$($dm.Groups[1].Value.PadLeft(2,'0'))"
        if(!$iso.StartsWith($p.Periodo)){continue}
        $hhmm="$($hm.Groups[1].Value.PadLeft(2,'0')):$($hm.Groups[2].Value)"
        $lote=if($iLote -ge 0 -and $iLote -lt $row.Count){[string]$row[$iLote]}else{""}
        $res=if($iRes -ge 0 -and $iRes -lt $row.Count){[string]$row[$iRes]}else{""}
        $turno=if($iTurno -ge 0 -and $iTurno -lt $row.Count){[string]$row[$iTurno]}else{""}
        [void]$keys.Add("$iso|$hhmm|$lote|$res|$turno")
        $dt="$iso"+"T"+"$hhmm"+":00"
        if($dt -gt $ultima){$ultima=$dt}
    }
    if($keys.Count -lt 1){throw "O arquivo não contém medições UP Linha 504 válidas no mês atual."}
    return @{QuantidadeBruta=$keys.Count;Ultima=$ultima;Periodo=$p.Periodo;Hoje=$p.Hoje.ToString("yyyy-MM-dd")}
}

$excel=$null;$wb=$null;$ws=$null;$range=$null;$logFile=$null
try{
    Clear-Host
    Write-Host "====================================================" -ForegroundColor Cyan
    Write-Host "       UP 504 - PLANO B AUTOMATICO FINAL" -ForegroundColor Cyan
    Write-Host "====================================================" -ForegroundColor Cyan
    Write-Host "Athena: manual | Excel -> Portal -> Backup -> Producao: automatico" -ForegroundColor White
    Write-Host ""

    if(!(Test-Path $PortalUp)){throw "Portal UP não encontrado: $PortalUp"}
    if(!(Test-Path $Downloads)){throw "Pasta de Downloads não encontrada: $Downloads"}
    New-Item -ItemType Directory -Force -Path $BackupDir,$LogDir | Out-Null

    $logFile=Join-Path $LogDir ("auto_"+(Get-Date -Format "yyyyMMdd_HHmmss")+".log")
    Start-Transcript -Path $logFile -Append | Out-Null

    Log "Localizando o relatório UP correto..." "Cyan"
    $candidatos=@()
    foreach($dir in @($RelatoriosUp,$Downloads)){
        if(Test-Path $dir){
            $candidatos += Get-ChildItem -Path $dir -Filter "relatorio-generico_*.xlsx" -File -ErrorAction SilentlyContinue
        }
    }
    $arquivo=$candidatos | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if(!$arquivo){throw "Nenhum relatorio-generico_*.xlsx encontrado."}
    Log "Relatório encontrado: $($arquivo.FullName)" "Green"
    Validar-PeriodoNome $arquivo

    Log "Validando Portal UP atual..." "Cyan"
    $html=Validar-Index $PortalUp
    foreach($item in @('id="pasteReport"','id="processPaste"','id="updateMonthTarget"','id="updateStatus"','id="exportPortal"','function exportPortal()')){
        if($html -notlike "*$item*"){throw "Estrutura necessária não encontrada no Portal UP: $item"}
    }

    Log "Abrindo Excel de forma invisível..." "Cyan"
    $excel=New-Object -ComObject Excel.Application
    $excel.Visible=$false;$excel.DisplayAlerts=$false
    $wb=$excel.Workbooks.Open($arquivo.FullName,0,$true)
    $ws=$wb.Worksheets.Item(1)
    $range=$ws.UsedRange
    $linhas=[int]$range.Rows.Count;$colunas=[int]$range.Columns.Count
    Log "Planilha: $linhas linhas x $colunas colunas." "Green"
    if($linhas -lt 20 -or $colunas -lt 10){throw "Planilha parece incompleta ($linhas x $colunas)."}

    $dados=$range.Value2
    $matrix=New-Object System.Collections.Generic.List[object]
    $sb=New-Object Text.StringBuilder
    for($i=1;$i -le $linhas;$i++){
        $campos=New-Object System.Collections.Generic.List[string]
        $row=New-Object System.Collections.Generic.List[object]
        for($j=1;$j -le $colunas;$j++){
            $v=$dados[$i,$j];if($null -eq $v){$v=""}
            $row.Add($v)
            $s=([string]$v) -replace "`r`n|`n|`r"," "
            $campos.Add($s)
        }
        $matrix.Add($row.ToArray())
        [void]$sb.AppendLine(($campos -join "`t"))
    }
    $texto=$sb.ToString()
    $resumoRel=Resumo-Relatorio $matrix
    Log "Relatório confirmado como UP Linha 504: bruto=$($resumoRel.QuantidadeBruta); última=$($resumoRel.Ultima)." "Green"

    $wb.Close($false);$excel.Quit()
    Liberar-ComObject $range;Liberar-ComObject $ws;Liberar-ComObject $wb;Liberar-ComObject $excel
    $range=$null;$ws=$null;$wb=$null;$excel=$null
    [GC]::Collect();[GC]::WaitForPendingFinalizers()

    $resumoAntes=Obter-ResumoIndex $PortalUp $resumoRel.Periodo $resumoRel.Hoje
    Log "Base atual: $($resumoAntes.Quantidade) medições no mês." "DarkGray"

    Log "Preparando execução automática no motor do próprio Portal UP..." "Cyan"
    $b64=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($texto))
    $periodo=$resumoRel.Periodo
    $relNomeJs=($arquivo.Name -replace '\\','\\\\' -replace "'","\\'")
    $inicioGeracao=Get-Date

    $injecao=@"
<script id="upPlanoBInjectorAuto">
(function(){
 const B64='$b64', PERIODO='$periodo', RELATORIO='$relNomeJs';
 function wait(ms){return new Promise(r=>setTimeout(r,ms))}
 function dec(b){const x=atob(b),u=new Uint8Array(x.length);for(let i=0;i<x.length;i++)u[i]=x.charCodeAt(i);return new TextDecoder('utf-8').decode(u)}
 function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
 function st(t,k){let e=document.getElementById('planob-status');if(!e){e=document.createElement('div');e.id='planob-status';e.style.cssText='position:fixed;right:18px;bottom:18px;z-index:999999;max-width:560px;padding:14px 16px;border-radius:12px;background:#111827;color:white;font:14px Arial;box-shadow:0 10px 30px #0006;border:2px solid #60a5fa';document.body.appendChild(e)}e.style.borderColor=k==='erro'?'#ef4444':k==='ok'?'#22c55e':'#60a5fa';e.innerHTML=t}
 async function run(){
  try{
   const paste=document.getElementById('pasteReport');
   const btn=document.getElementById('processPaste');
   const sel=document.getElementById('updateMonthTarget');
   const status=document.getElementById('updateStatus');
   if(!paste||!btn||!sel||!status||typeof exportPortal!=='function')throw new Error('Estrutura de atualização do UP incompatível.');
   sel.value=PERIODO;sel.dispatchEvent(new Event('change',{bubbles:true}));
   paste.value=dec(B64);paste.dispatchEvent(new Event('input',{bubbles:true}));
   st('<b>PLANO B UP</b><br>Relatório '+esc(RELATORIO)+' carregado.<br>Atualizando '+esc(PERIODO)+'...','info');

   btn.click();

   let ok='',deadline=Date.now()+25000;
   while(Date.now()<deadline){
     ok=(status.innerText||'').trim();
     if(/substitu[ií]do com sucesso/i.test(ok))break;
     if(/erro|inv[aá]lid|falha|bloque/i.test(ok))throw new Error(ok);
     await wait(250);
   }
   if(!/substitu[ií]do com sucesso/i.test(ok))throw new Error('O Portal UP não confirmou a atualização do mês. Mensagem: '+ok);
   if(sel.value!==PERIODO)throw new Error('O mês de destino mudou durante a atualização.');

   st('<b>PLANO B UP</b><br>'+esc(ok)+'<br><br>Gerando HTML atualizado...','info');
   exportPortal();
   await wait(900);
   st('<b>PLANO B UP</b><br>'+esc(ok)+'<br>HTML enviado para o diretório de downloads.<br><br>Aguardando validação pelo PowerShell...','ok');
  }catch(e){st('<b>PLANO B UP - BLOQUEADO</b><br>'+esc(e.message||e),'erro');console.error(e)}
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(run,700));else setTimeout(run,700);
})();
</script>
"@

    if($html -match '</body>'){$html=$html -replace '</body>',($injecao+"`r`n</body>")}else{$html+=$injecao}
    [IO.File]::WriteAllText($TempHtml,$html,(New-Object Text.UTF8Encoding($false)))
    Log "HTML temporário pronto." "Green"

    # Remove somente exports antigos recentes que poderiam confundir esta execução.
    $pastasBusca=New-Object System.Collections.Generic.List[string]
    foreach($p in @($Downloads,$PortalDir,(Join-Path $env:USERPROFILE "Downloads"))){
        if($p -and (Test-Path $p) -and !$pastasBusca.Contains($p)){[void]$pastasBusca.Add($p)}
    }
    try{
        $shellDownloads=(New-Object -ComObject Shell.Application).Namespace('shell:Downloads').Self.Path
        if($shellDownloads -and (Test-Path $shellDownloads) -and !$pastasBusca.Contains($shellDownloads)){[void]$pastasBusca.Add($shellDownloads)}
    }catch{}

    Log "Abrindo Portal UP automático..." "Cyan"
    Start-Process $TempHtml

    Log "Aguardando o HTML novo aparecer (mesmo modelo do TPO; até $TimeoutDownloadSeg s)..." "Cyan"
    $gerado=$null;$resumoNovo=$null
    $limite=(Get-Date).AddSeconds($TimeoutDownloadSeg)

    while((Get-Date) -lt $limite -and !$gerado){
        foreach($dir in $pastasBusca){
            $cands=Get-ChildItem -Path $dir -Filter "*.html" -File -ErrorAction SilentlyContinue |
                Where-Object {
                    $_.LastWriteTime -ge $inicioGeracao.AddSeconds(-3) -and
                    $_.Length -gt 100000 -and
                    $_.FullName -ne $PortalUp -and
                    $_.FullName -ne $TempHtml -and
                    $_.Name -notlike "index_backup*.html"
                } |
                Sort-Object LastWriteTime -Descending
            foreach($cand in $cands){
                try{
                    $r=Obter-ResumoIndex $cand.FullName $resumoRel.Periodo $resumoRel.Hoje
                    if($r.TemHoje -and $r.Quantidade -gt 0){
                        $gerado=$cand;$resumoNovo=$r;break
                    }
                }catch{}
            }
            if($gerado){break}
        }
        if(!$gerado){Start-Sleep -Milliseconds 500}
    }

    if(!$gerado){
        throw "O Portal UP atualizou o mês, mas nenhum HTML UP novo e válido foi encontrado em até $TimeoutDownloadSeg segundos. Produção NÃO foi alterada."
    }

    Log "HTML novo encontrado: $($gerado.FullName)" "Green"
    Log "Base nova validada: $($resumoNovo.Quantidade) medições; última=$($resumoNovo.Ultima)." "Green"

    # A última medição aceita não pode ser anterior à última medição válida do relatório.
    if($resumoNovo.Ultima -lt $resumoRel.Ultima){
        throw "O HTML gerado parece incompleto: última medição no portal=$($resumoNovo.Ultima), relatório=$($resumoRel.Ultima). Produção NÃO foi alterada."
    }

    # Limpa o injetor temporário do Plano B do arquivo que irá para produção.
    $novoHtml=[IO.File]::ReadAllText($gerado.FullName,[Text.Encoding]::UTF8)
    $novoHtml=[regex]::Replace($novoHtml,'<script[^>]+id=["'']upPlanoBInjectorAuto["''][^>]*>[\s\S]*?</script>','',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
    $novoHtml=[regex]::Replace($novoHtml,'<div[^>]+id=["'']planob-status["''][^>]*>[\s\S]*?</div>','',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
    [IO.File]::WriteAllText($gerado.FullName,$novoHtml,(New-Object Text.UTF8Encoding($false)))
    [void](Validar-Index $gerado.FullName)
    $resumoNovo=Obter-ResumoIndex $gerado.FullName $resumoRel.Periodo $resumoRel.Hoje

    # Backup da produção atual.
    $backup=Join-Path $BackupDir ("index_backup_"+(Get-Date -Format "yyyyMMdd_HHmmss")+".html")
    Copy-Item -LiteralPath $PortalUp -Destination $backup -Force
    [void](Validar-Index $backup)
    Log "Backup criado: $backup" "Green"

    # Troca segura com rollback.
    $tempDestino=Join-Path $PortalDir "index.__novo__.html"
    $oldTemp=Join-Path $PortalDir "index.__anterior__.html"
    Remove-Item $tempDestino,$oldTemp -Force -ErrorAction SilentlyContinue
    Copy-Item -LiteralPath $gerado.FullName -Destination $tempDestino -Force
    [void](Validar-Index $tempDestino)

    if(Test-Path $PortalUp){Move-Item -LiteralPath $PortalUp -Destination $oldTemp -Force}
    try{
        Move-Item -LiteralPath $tempDestino -Destination $PortalUp -Force
        [void](Validar-Index $PortalUp)
        $resumoProd=Obter-ResumoIndex $PortalUp $resumoRel.Periodo $resumoRel.Hoje
        if($resumoProd.Ultima -lt $resumoRel.Ultima){throw "Validação final da produção falhou."}
        Remove-Item $oldTemp -Force -ErrorAction SilentlyContinue
    }catch{
        if(Test-Path $PortalUp){Remove-Item $PortalUp -Force -ErrorAction SilentlyContinue}
        if(Test-Path $oldTemp){Move-Item $oldTemp $PortalUp -Force}
        throw
    }

    # Limpeza final
    Remove-Item -LiteralPath $gerado.FullName -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $TempHtml -Force -ErrorAction SilentlyContinue

    # Organiza backups antigos soltos da raiz.
    Get-ChildItem -Path $PortalDir -Filter "index_backup*.html" -File -ErrorAction SilentlyContinue |
      ForEach-Object {
        $dest=Join-Path $BackupDir $_.Name
        if(Test-Path $dest){
            $base=[IO.Path]::GetFileNameWithoutExtension($_.Name)
            $dest=Join-Path $BackupDir ($base+"_"+(Get-Date -Format "yyyyMMdd_HHmmss")+".html")
        }
        Move-Item -LiteralPath $_.FullName -Destination $dest -Force
    }

    Write-Host ""
    Write-Host "====================================================" -ForegroundColor Green
    Write-Host "       UP 504 ATUALIZADO COM SUCESSO - PLANO B" -ForegroundColor Green
    Write-Host "====================================================" -ForegroundColor Green
    Write-Host "Relatório: $($arquivo.Name)" -ForegroundColor White
    Write-Host "Mês atualizado: $($resumoRel.Periodo)" -ForegroundColor White
    Write-Host "Medições aceitas pelo Portal UP: $($resumoProd.Quantidade)" -ForegroundColor White
    Write-Host "Última medição: $($resumoProd.Ultima)" -ForegroundColor White
    Write-Host "Backup: $backup" -ForegroundColor DarkGray
    Write-Host "Produção: $PortalUp" -ForegroundColor Cyan
    Write-Host ""
    Log "Processo concluído. A janela será fechada em 8 segundos." "Green"
    Start-Sleep -Seconds 8
}
catch{
    Write-Host ""
    Write-Host "====================================================" -ForegroundColor Red
    Write-Host "        ATUALIZAÇÃO UP BLOQUEADA - PRODUÇÃO SEGURA" -ForegroundColor Red
    Write-Host "====================================================" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Remove-Item -LiteralPath $TempHtml -Force -ErrorAction SilentlyContinue
    Write-Host "O index de produção NÃO foi substituído." -ForegroundColor Yellow
    if($logFile){Write-Host "Log: $logFile" -ForegroundColor DarkGray}
    Read-Host "Pressione ENTER para fechar"
    exit 1
}
finally{
    if($wb){try{$wb.Close($false)}catch{}}
    if($excel){try{$excel.Quit()}catch{}}
    Liberar-ComObject $range;Liberar-ComObject $ws;Liberar-ComObject $wb;Liberar-ComObject $excel
    try{Stop-Transcript | Out-Null}catch{}
}
