﻿$ErrorActionPreference = "Stop"

# ============================================================
# PORTAL UP 504 - PLANO B AUTOMATICO
# Sem Node / Sem Playwright
# Athena continua manual; do Excel em diante, automatico.
# ============================================================

$PortalUp = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal Qualidade\Portal UP\index.html"
$Downloads = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal manutenção\Downloads"
$RelatoriosUp = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Relatórios UP"
$PortalDir = Split-Path $PortalUp -Parent
$TempHtml = Join-Path $PortalDir "UP_PLANOB_EXECUCAO_AUTO.html"
$BackupDir = Join-Path $PortalDir "Backups_PlanoB_UP"
$LogDir = Join-Path $PortalDir "Logs_PlanoB_UP"
$TimeoutDownloadSeg = 120

# Possíveis pastas onde o Chrome pode gravar o HTML.
$PastasSaida = New-Object System.Collections.Generic.List[string]
foreach($p in @(
    $Downloads,
    (Join-Path $env:USERPROFILE "Downloads"),
    (Join-Path $env:LOCALAPPDATA "Temp")
)) {
    if($p -and (Test-Path $p) -and !$PastasSaida.Contains($p)) { [void]$PastasSaida.Add($p) }
}
try {
    $shellDownloads = (New-Object -ComObject Shell.Application).Namespace('shell:Downloads').Self.Path
    if($shellDownloads -and (Test-Path $shellDownloads) -and !$PastasSaida.Contains($shellDownloads)) {
        [void]$PastasSaida.Add($shellDownloads)
    }
} catch {}


function Log([string]$Mensagem, [string]$Cor = "Gray") {
    $hora = Get-Date -Format "HH:mm:ss"
    Write-Host "[$hora] $Mensagem" -ForegroundColor $Cor
}
function Liberar-ComObject($obj) {
    if ($null -ne $obj) { try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($obj) } catch {} }
}
function Periodo-Esperado {
    $hoje = (Get-Date).Date
    $inicio = Get-Date -Year $hoje.Year -Month $hoje.Month -Day 1
    return @{ Inicio=$inicio; Hoje=$hoje; Periodo=$hoje.ToString('yyyy-MM') }
}
function Testar-PeriodoNome($arquivo) {
    $m = [regex]::Match($arquivo.Name, '^relatorio-generico_(\d{2})_(\d{2})_(\d{4})_(\d{2})_(\d{2})_(\d{4})(?: \(\d+\))?\.xlsx$')
    if (!$m.Success) { return $false }
    $de = [datetime]::ParseExact(($m.Groups[1].Value + '/' + $m.Groups[2].Value + '/' + $m.Groups[3].Value),'dd/MM/yyyy',$null)
    $ate = [datetime]::ParseExact(($m.Groups[4].Value + '/' + $m.Groups[5].Value + '/' + $m.Groups[6].Value),'dd/MM/yyyy',$null)
    $p = Periodo-Esperado
    return ($de.Date -eq $p.Inicio.Date -and $ate.Date -eq $p.Hoje.Date)
}
function Validar-PeriodoNome($arquivo) {
    if (!(Testar-PeriodoNome $arquivo)) {
        $p = Periodo-Esperado
        throw "PERÍODO BLOQUEADO. O UP exige relatório de $($p.Inicio.ToString('dd/MM/yyyy')) a $($p.Hoje.ToString('dd/MM/yyyy')). Produção NÃO foi alterada."
    }
    $m = [regex]::Match($arquivo.Name, '^relatorio-generico_(\d{2})_(\d{2})_(\d{4})_(\d{2})_(\d{2})_(\d{4})')
    Log "Período validado: $($m.Groups[1].Value)/$($m.Groups[2].Value)/$($m.Groups[3].Value) a $($m.Groups[4].Value)/$($m.Groups[5].Value)/$($m.Groups[6].Value)." "Green"
}
function Normalizar([object]$v) {
    $s = [string]$v
    if ([string]::IsNullOrEmpty($s)) { return "" }
    $formD = $s.Normalize([Text.NormalizationForm]::FormD)
    $sb = New-Object Text.StringBuilder
    foreach($ch in $formD.ToCharArray()) {
        if ([Globalization.CharUnicodeInfo]::GetUnicodeCategory($ch) -ne [Globalization.UnicodeCategory]::NonSpacingMark) { [void]$sb.Append($ch) }
    }
    return (($sb.ToString().ToLowerInvariant()) -replace '\s+',' ').Trim()
}
function Resumo-RelatorioUP([string]$Texto) {
    $linhas = $Texto -split "`r?`n" | Where-Object { $_.Trim().Length -gt 0 }
    if ($linhas.Count -lt 2) { throw "Relatório UP vazio ou inválido." }
    $headers = $linhas[0] -split "`t", -1
    $idx = @{}
    for($i=0; $i -lt $headers.Count; $i++) { $idx[(Normalizar $headers[$i])] = $i }
    foreach($obrig in @('linha','lote','resultante','data coleta','hora coleta','item de processo','turno')) {
        if (!$idx.ContainsKey($obrig)) { throw "Cabeçalho obrigatório ausente no relatório UP: $obrig" }
    }
    $p = Periodo-Esperado
    $periodo = $p.Periodo
    $hoje = $p.Hoje.ToString('dd/MM/yyyy')
    $keys = New-Object 'System.Collections.Generic.HashSet[string]'
    $temHoje = $false
    for($i=1; $i -lt $linhas.Count; $i++) {
        $r = $linhas[$i] -split "`t", -1
        function GetCampo([string]$nome) {
            $pos = $idx[$nome]
            if ($pos -ge 0 -and $pos -lt $r.Count) { return [string]$r[$pos] }
            return ""
        }
        $linha = GetCampo 'linha'
        if ($linha -notmatch 'L504') { continue }
        $item = Normalizar (GetCampo 'item de processo')
        if ($item -notlike '*unidade de pasteurizacao termografo*') { continue }
        $data = (GetCampo 'data coleta').Trim()
        $hora = (GetCampo 'hora coleta').Trim()
        if ($data -eq $hoje) { $temHoje = $true }
        $dm = [regex]::Match($data,'^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$')
        if (!$dm.Success) { continue }
        $iso = "$($dm.Groups[3].Value)-$($dm.Groups[2].Value.PadLeft(2,'0'))-$($dm.Groups[1].Value.PadLeft(2,'0'))"
        if (!$iso.StartsWith($periodo)) { continue }
        $hm = [regex]::Match($hora,'(\d{1,2}):(\d{2})')
        if (!$hm.Success) { continue }
        $hhmm = "$($hm.Groups[1].Value.PadLeft(2,'0')):$($hm.Groups[2].Value)"
        $key = "$iso|$hhmm|$((GetCampo 'lote').Trim())|$((GetCampo 'resultante').Trim())|$((GetCampo 'turno').Trim())"
        [void]$keys.Add($key)
    }
    if ($keys.Count -eq 0) { throw "O arquivo não contém medições válidas de 'Unidade de Pasteurização Termógrafo' para Linha 504 no mês atual. Pode ser o relatório errado." }
    if (!$temHoje) { throw "O relatório cobre o período até hoje, mas não contém medição UP do dia $hoje. Atualização bloqueada para evitar base incompleta." }
    $datas = @($keys | ForEach-Object { $p2 = $_ -split '\|'; "$($p2[0])T$($p2[1]):00" } | Sort-Object)
    return @{ Quantidade=$keys.Count; Ultima=$datas[-1]; Periodo=$periodo; Hoje=$hoje }
}
function Validar-Index([string]$Arquivo) {
    if (!(Test-Path $Arquivo)) { throw "Index não encontrado: $Arquivo" }
    $fi = Get-Item $Arquivo
    if ($fi.Length -lt 100000) { throw "O HTML gerado parece incompleto ($($fi.Length) bytes)." }
    $conteudo = [System.IO.File]::ReadAllText($Arquivo, [System.Text.Encoding]::UTF8)
    if ($conteudo -notmatch 'UP Linha 504|UP 504') { throw "O arquivo gerado não parece ser o Portal UP 504." }
    if ($conteudo -notmatch 'embeddedOverrideData') { throw "embeddedOverrideData não encontrado no Portal UP gerado." }
    return $conteudo
}
function Validar-IndexContraRelatorio([string]$Arquivo, $Resumo) {
    $html = Validar-Index $Arquivo
    $m = [regex]::Match($html, '<script[^>]+id=["'']embeddedOverrideData["''][^>]*>([\s\S]*?)</script>', [Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if (!$m.Success) { throw "Não foi possível localizar a base incorporada embeddedOverrideData no HTML gerado." }
    try { $store = $m.Groups[1].Value | ConvertFrom-Json } catch { throw "A base incorporada do HTML gerado está inválida." }

    $mesProp = $store.months.PSObject.Properties[$Resumo.Periodo]
    if($null -eq $mesProp) { throw "O HTML gerado não possui o mês $($Resumo.Periodo) na base incorporada." }

    $recs = @($mesProp.Value.records)
    if($recs.Count -lt 1) { throw "O HTML gerado ficou sem medições para $($Resumo.Periodo)." }

    $datas = @($recs | ForEach-Object {
        if ($_.dt) { [string]$_.dt } else { "$($_.d)T$($_.h):00" }
    } | Sort-Object)
    $ultima = if($datas.Count){$datas[-1]}else{""}

    $temHoje = @($recs | Where-Object { [string]$_.d -eq $Resumo.Hoje }).Count -gt 0
    if(!$temHoje) { throw "O index gerado não contém nenhuma medição UP do dia $($Resumo.Hoje)." }

    if($recs.Count -ne $Resumo.Quantidade) {
        Log "Consolidação do Portal UP: Excel bruto=$($Resumo.Quantidade); aceito pelo motor=$($recs.Count)." "Yellow"
    }

    Log "Validação estrutural UP OK: $($recs.Count) medições aceitas pelo motor do portal; última = $ultima." "Green"
    return @{ QuantidadeAceita=$recs.Count; UltimaAceita=$ultima }
}

$excel=$null; $wb=$null; $ws=$null; $range=$null; $logFile=$null
try {
    Clear-Host
    Write-Host "====================================================" -ForegroundColor Cyan
    Write-Host "       UP 504 - PLANO B AUTOMÁTICO V4 (SEM NODE)" -ForegroundColor Cyan
    Write-Host "====================================================" -ForegroundColor Cyan
    Write-Host "Athena: manual | Excel -> Portal -> Backup -> Produção: automático" -ForegroundColor White
    Write-Host ""

    if (!(Test-Path $PortalUp)) { throw "Portal UP não encontrado: $PortalUp" }
    if (!(Test-Path $Downloads)) { throw "Pasta de Downloads não encontrada: $Downloads" }
    New-Item -ItemType Directory -Force -Path $BackupDir,$LogDir | Out-Null

    $logFile = Join-Path $LogDir ("auto_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".log")
    Start-Transcript -Path $logFile -Append | Out-Null

    Log "Localizando o relatório UP correto..." "Cyan"
    $candidatos = @()
    foreach($dir in @($RelatoriosUp,$Downloads)) {
        if(Test-Path $dir) {
            $candidatos += Get-ChildItem -Path $dir -Filter "relatorio-generico_*.xlsx" -File -ErrorAction SilentlyContinue
        }
    }
    $arquivo = $candidatos | Where-Object { Testar-PeriodoNome $_ } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (!$arquivo) {
        $p=Periodo-Esperado
        throw "Nenhum relatório UP do período $($p.Inicio.ToString('dd/MM/yyyy')) a $($p.Hoje.ToString('dd/MM/yyyy')) foi encontrado em Relatórios UP ou Downloads."
    }
    Log "Relatório encontrado: $($arquivo.FullName)" "Green"
    Validar-PeriodoNome $arquivo

    Log "Validando Portal UP atual..." "Cyan"
    $html = Validar-Index $PortalUp
    foreach($item in @('function parseTSV','function processMatrix','function exportPortal','id="pasteReport"','id="updateMonthTarget"')) {
        if ($html -notlike "*$item*") { throw "Estrutura necessária não encontrada no Portal UP: $item" }
    }

    Log "Abrindo Excel de forma invisível..." "Cyan"
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $wb = $excel.Workbooks.Open($arquivo.FullName, 0, $true)
    $ws = $wb.Worksheets.Item(1)
    $range = $ws.UsedRange
    $linhas=[int]$range.Rows.Count; $colunas=[int]$range.Columns.Count
    Log "Planilha: $linhas linhas x $colunas colunas." "Green"
    if ($linhas -lt 10 -or $colunas -lt 20) { throw "Planilha parece incompleta ($linhas x $colunas)." }

    $dados=$range.Value2
    $sb=New-Object System.Text.StringBuilder
    for($i=1;$i -le $linhas;$i++){
        $campos=New-Object System.Collections.Generic.List[string]
        for($j=1;$j -le $colunas;$j++){
            $v=$dados[$i,$j]; if($null -eq $v){$v=""}
            $s=([string]$v) -replace "`r`n|`n|`r"," "
            $campos.Add($s)
        }
        [void]$sb.AppendLine(($campos -join "`t"))
    }
    $texto=$sb.ToString()
    if ([string]::IsNullOrWhiteSpace($texto)) { throw "Conteúdo extraído do Excel ficou vazio." }

    $wb.Close($false); $excel.Quit()
    Liberar-ComObject $range; Liberar-ComObject $ws; Liberar-ComObject $wb; Liberar-ComObject $excel
    $range=$null;$ws=$null;$wb=$null;$excel=$null
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()

    $resumo = Resumo-RelatorioUP $texto
    Log "Relatório confirmado como UP Linha 504: $($resumo.Quantidade) medições no mês; última = $($resumo.Ultima)." "Green"

    foreach($dir in $PastasSaida){
        Get-ChildItem -Path $dir -Filter "UP_PLANOB_GERADO*.html" -File -ErrorAction SilentlyContinue |
          Remove-Item -Force -ErrorAction SilentlyContinue
    }

    Log "Preparando execução automática no motor do próprio Portal UP..." "Cyan"
    $b64=[Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($texto))
    $periodo=$resumo.Periodo
    $relatorioNomeJs=($arquivo.Name -replace '\\','\\\\' -replace "'", "\\'")
    $inicioGeracao = Get-Date

    $injecao=@"
<script id="upPlanoBInjectorAuto">
(function(){
 const B64='$b64', PERIODO='$periodo', RELATORIO='$relatorioNomeJs';
 function dec(b){const x=atob(b),u=new Uint8Array(x.length);for(let i=0;i<x.length;i++)u[i]=x.charCodeAt(i);return new TextDecoder('utf-8').decode(u)}
 function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
 function st(t,k){let e=document.getElementById('planob-status');if(!e){e=document.createElement('div');e.id='planob-status';e.style.cssText='position:fixed;right:18px;bottom:18px;z-index:999999;max-width:560px;padding:14px 16px;border-radius:12px;background:#111827;color:white;font:14px Arial;box-shadow:0 8px 30px rgba(0,0,0,.35);border:2px solid #f59e0b';document.body.appendChild(e)}e.style.borderColor=k==='ok'?'#22c55e':k==='erro'?'#ef4444':'#f59e0b';e.innerHTML=t}
 async function wait(ms){return new Promise(r=>setTimeout(r,ms))}
 async function waitFor(fn, timeout=15000, step=150){const end=Date.now()+timeout;while(Date.now()<end){try{const v=fn();if(v)return v}catch(_){ }await wait(step)}return null}
 async function run(){
  try{
   st('<b>PLANO B UP</b><br>Carregando '+esc(RELATORIO),'info');

   // Não depende de funções internas do Portal UP. Usa exatamente os mesmos
   // campos e botões que o operador utiliza manualmente na tela Atualizar Dados.
   const pageBtn=[...document.querySelectorAll('button[data-page]')].find(b=>/atualizar|update/i.test(b.dataset.page||''));
   if(pageBtn) pageBtn.click();

   const area=await waitFor(()=>document.getElementById('pasteReport'));
   const sel=await waitFor(()=>document.getElementById('updateMonthTarget'));
   const processBtn=await waitFor(()=>document.getElementById('processPaste'));
   const status=await waitFor(()=>document.getElementById('updateStatus'));
   const exportBtn=await waitFor(()=>document.getElementById('exportPortal'));
   if(!area||!sel||!processBtn||!status||!exportBtn) throw new Error('Campos/botões da tela Atualizar Dados não foram encontrados.');

   const option=[...sel.options].find(o=>o.value===PERIODO);
   if(!option) throw new Error('O mês '+PERIODO+' não existe no seletor do Portal UP.');
   sel.value=PERIODO;
   sel.dispatchEvent(new Event('change',{bubbles:true}));

   area.value=dec(B64);
   area.dispatchEvent(new Event('input',{bubbles:true}));
   area.dispatchEvent(new Event('change',{bubbles:true}));
   if(!area.value.trim()) throw new Error('Os dados do relatório não foram carregados na caixa de atualização.');

   st('<b>PLANO B UP</b><br>Relatório carregado. Atualizando '+esc(PERIODO)+'...','info');
   processBtn.click();

   const ok=await waitFor(()=>{
      const msg=(status.innerText||status.textContent||'').trim();
      if(/erro|falha|inválid|não possui|nenhuma leitura|bloquead/i.test(msg)) throw new Error(msg);
      if(/substituído com sucesso|substituido com sucesso/i.test(msg)) return msg;
      return null;
   },20000,250);
   if(!ok) throw new Error('O Portal UP não confirmou a substituição do mês dentro do tempo esperado. Mensagem atual: '+(status.innerText||''));

   // Confirma também que o mês selecionado continuou correto após a atualização.
   if(sel.value!==PERIODO) throw new Error('O Portal UP mudou o mês de destino durante a atualização.');
   st('<b>PLANO B UP</b><br>'+esc(ok)+'<br><br>Gerando novo HTML limpo...','info');

   const embedded=document.getElementById('embeddedOverrideData');
   if(!embedded) throw new Error('embeddedOverrideData não encontrado antes da geração.');
   const oldEmbedded=embedded.textContent;
   embedded.textContent=JSON.stringify(STORE).replace(/</g,'\\u003c');

   const clone=document.documentElement.cloneNode(true);
   embedded.textContent=oldEmbedded;

   const inj=clone.querySelector('#upPlanoBInjectorAuto'); if(inj) inj.remove();
   const toast=clone.querySelector('#planob-status'); if(toast) toast.remove();

   clone.querySelectorAll('.nav button').forEach(b=>b.classList.remove('active'));
   clone.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
   const homeBtn=clone.querySelector('.nav button[data-page="executivo"]');
   const homePage=clone.querySelector('#executivo');
   if(homeBtn) homeBtn.classList.add('active');
   if(homePage) homePage.classList.add('active');

   const out='<!doctype html>\\n'+clone.outerHTML;
   const a=document.createElement('a');
   a.href=URL.createObjectURL(new Blob([out],{type:'text/html;charset=utf-8'}));
   a.download='UP_PLANOB_GERADO.html';
   document.body.appendChild(a);
   a.click();
   a.remove();
   setTimeout(()=>URL.revokeObjectURL(a.href),1800);

   await wait(900);
   st('<b>PLANO B UP</b><br>'+esc(ok)+'<br>HTML limpo enviado para Downloads.<br><br>Aguardando validação e substituição pelo PowerShell...','ok');
  }catch(e){st('<b>PLANO B UP - BLOQUEADO</b><br>'+esc(e.message||e),'erro');console.error(e)}
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(run,900));else setTimeout(run,900);
})();
</script>
"@
    if($html -match '</body>'){$html=$html -replace '</body>',($injecao+"`r`n</body>")}else{$html+=$injecao}
    [System.IO.File]::WriteAllText($TempHtml,$html,(New-Object System.Text.UTF8Encoding($false)))
    Log "HTML temporário pronto." "Green"

    Log "Abrindo Portal UP automático..." "Cyan"
    Start-Process $TempHtml

    Log "Aguardando HTML limpo gerado pelo Portal UP (até $TimeoutDownloadSeg s)..." "Cyan"
    $gerado=$null
    $limite=(Get-Date).AddSeconds($TimeoutDownloadSeg)
    while((Get-Date) -lt $limite){
        foreach($dir in $PastasSaida){
            $cand = Get-ChildItem -Path $dir -Filter "UP_PLANOB_GERADO*.html" -File -ErrorAction SilentlyContinue |
              Where-Object { $_.LastWriteTime -ge $inicioGeracao.AddSeconds(-5) -and $_.Length -gt 100000 } |
              Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if($cand){ $gerado=$cand; break }
        }
        if($gerado){break}
        Start-Sleep -Milliseconds 500
    }
    if(!$gerado){
        $locais = ($PastasSaida -join " | ")
        throw "O Portal UP atualizou o mês, mas o PowerShell não encontrou UP_PLANOB_GERADO.html dentro de $TimeoutDownloadSeg segundos. Locais verificados: $locais. Produção NÃO foi alterada."
    }
    Log "HTML gerado encontrado: $($gerado.FullName)" "Green"

    [void](Validar-Index $gerado.FullName)
    $validadoGerado = Validar-IndexContraRelatorio $gerado.FullName $resumo

    $backup=Join-Path $BackupDir ("index_backup_"+(Get-Date -Format "yyyyMMdd_HHmmss")+".html")
    Copy-Item -LiteralPath $PortalUp -Destination $backup -Force
    [void](Validar-Index $backup)
    Log "Backup criado: $backup" "Green"

    $tempDestino=Join-Path $PortalDir "index.__novo__.html"
    $oldTemp=Join-Path $PortalDir "index.__anterior__.html"
    Remove-Item $tempDestino,$oldTemp -Force -ErrorAction SilentlyContinue
    Copy-Item -LiteralPath $gerado.FullName -Destination $tempDestino -Force
    [void](Validar-Index $tempDestino)

    if(Test-Path $PortalUp){Move-Item -LiteralPath $PortalUp -Destination $oldTemp -Force}
    try{
        Move-Item -LiteralPath $tempDestino -Destination $PortalUp -Force
        [void](Validar-Index $PortalUp)
        $validadoProducao = Validar-IndexContraRelatorio $PortalUp $resumo
        Remove-Item $oldTemp -Force -ErrorAction SilentlyContinue
    }catch{
        if(!(Test-Path $PortalUp) -and (Test-Path $oldTemp)){Move-Item $oldTemp $PortalUp -Force}
        throw
    }

    Remove-Item -LiteralPath $gerado.FullName -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $TempHtml -Force -ErrorAction SilentlyContinue

    Write-Host ""
    Write-Host "====================================================" -ForegroundColor Green
    Write-Host "       UP 504 ATUALIZADO COM SUCESSO - PLANO B" -ForegroundColor Green
    Write-Host "====================================================" -ForegroundColor Green
    Write-Host "Relatório: $($arquivo.Name)" -ForegroundColor White
    Write-Host "Mês atualizado: $periodo" -ForegroundColor White
    Write-Host "Medições aceitas pelo Portal UP: $($validadoProducao.QuantidadeAceita)" -ForegroundColor White
    Write-Host "Última medição aceita: $($validadoProducao.UltimaAceita)" -ForegroundColor White
    Write-Host "Backup: $backup" -ForegroundColor DarkGray
    Write-Host "Produção: $PortalUp" -ForegroundColor Cyan
    Write-Host ""
    Log "Processo concluído. A janela será fechada em 8 segundos." "Green"
    Start-Sleep -Seconds 8
}
catch{
    Write-Host ""
    Write-Host "====================================================" -ForegroundColor Red
    Write-Host "        ATUALIZAÇÃO UP BLOQUEADA - PRODUÇÃO SEGURA" -ForegroundColor Red
    Write-Host "====================================================" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Remove-Item -LiteralPath $TempHtml -Force -ErrorAction SilentlyContinue
    Write-Host "O index de produção não deve ser substituído quando esta mensagem aparecer." -ForegroundColor Yellow
    if($logFile){Write-Host "Log: $logFile" -ForegroundColor DarkGray}
    Read-Host "Pressione ENTER para fechar"
    exit 1
}
finally{
    if($wb){try{$wb.Close($false)}catch{}}
    if($excel){try{$excel.Quit()}catch{}}
    Liberar-ComObject $range; Liberar-ComObject $ws; Liberar-ComObject $wb; Liberar-ComObject $excel
    try{Stop-Transcript | Out-Null}catch{}
}
