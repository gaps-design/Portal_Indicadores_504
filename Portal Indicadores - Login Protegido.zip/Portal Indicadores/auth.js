/* =========================================================
   PORTAL DE INDICADORES | LINHA 504
   CAMADA SIMPLES DE AUTENTICAÇÃO LOCAL

   IMPORTANTE:
   Esta proteção foi criada para o uso atual em arquivos locais.
   Ela impede o acesso casual, mas não substitui autenticação de
   servidor/banco de dados. A próxima evolução pode usar Supabase.
========================================================= */

(() => {
  "use strict";

  const AUTH = {
    usuario: "acesso",
    senhaHash: "1j78k6ardjv",
    storageKey: "portal504_auth_v1",
    validadeMs: 8 * 60 * 60 * 1000
  };

  function hashCredential(value) {
    let h1 = 0xdeadbeef ^ value.length;
    let h2 = 0x41c6ce57 ^ value.length;

    for (let i = 0, ch; i < value.length; i++) {
      ch = value.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^
         Math.imul(h2 ^ (h2 >>> 13), 3266489909);

    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^
         Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (
      4294967296 * (2097151 & h2) + (h1 >>> 0)
    ).toString(36);
  }

  const sessionToken = hashCredential(
    `portal504|${AUTH.usuario}|${AUTH.senhaHash}|autorizado`
  );

  function sessaoValida(sessao) {
    return Boolean(
      sessao &&
      sessao.token === sessionToken &&
      Number.isFinite(sessao.expiraEm) &&
      Date.now() < sessao.expiraEm
    );
  }

  function lerSessaoDaJanela() {
    try {
      if (!window.name.startsWith("PORTAL504_AUTH:")) return null;
      const payload = window.name.slice("PORTAL504_AUTH:".length);
      const sessao = JSON.parse(decodeURIComponent(payload));
      return sessaoValida(sessao) ? sessao : null;
    } catch (_) {
      return null;
    }
  }

  function gravarSessaoNaJanela(sessao) {
    try {
      window.name = `PORTAL504_AUTH:${encodeURIComponent(JSON.stringify(sessao))}`;
    } catch (_) {}
  }

  function obterSessao() {
    const sessaoJanela = lerSessaoDaJanela();
    if (sessaoJanela) return sessaoJanela;

    try {
      const raw = localStorage.getItem(AUTH.storageKey);
      if (!raw) return null;

      const sessao = JSON.parse(raw);
      if (!sessaoValida(sessao)) {
        localStorage.removeItem(AUTH.storageKey);
        return null;
      }

      gravarSessaoNaJanela(sessao);
      return sessao;
    } catch (_) {
      return null;
    }
  }

  function salvarSessao() {
    const sessao = {
      token: sessionToken,
      expiraEm: Date.now() + AUTH.validadeMs
    };

    gravarSessaoNaJanela(sessao);

    try {
      localStorage.setItem(AUTH.storageKey, JSON.stringify(sessao));
      return true;
    } catch (_) {
      return true;
    }
  }

  function encerrarSessao() {
    try {
      localStorage.removeItem(AUTH.storageKey);
    } catch (_) {}

    if (window.name.startsWith("PORTAL504_AUTH:")) {
      window.name = "";
    }
  }

  function obterRetornoValido() {
    const params = new URLSearchParams(window.location.search);
    const retorno = params.get("retorno");
    if (!retorno) return null;

    try {
      const destino = new URL(retorno, window.location.href);
      const atual = new URL(window.location.href);

      if (destino.protocol === "file:" && atual.protocol === "file:") {
        return destino.href;
      }

      if (
        ["http:", "https:"].includes(destino.protocol) &&
        destino.origin === atual.origin
      ) {
        return destino.href;
      }
    } catch (_) {}

    return null;
  }

  function exibirPortal() {
    const loginScreen = document.getElementById("loginScreen");
    const portal = document.getElementById("portalApp");

    document.body.classList.remove("auth-pending", "auth-locked");
    document.body.classList.add("auth-ok");

    if (loginScreen) {
      loginScreen.hidden = true;
      loginScreen.setAttribute("aria-hidden", "true");
    }

    if (portal) {
      portal.hidden = false;
      portal.setAttribute("aria-hidden", "false");
    }
  }

  function exibirLogin() {
    const loginScreen = document.getElementById("loginScreen");
    const portal = document.getElementById("portalApp");
    const password = document.getElementById("loginPassword");

    document.body.classList.remove("auth-pending", "auth-ok");
    document.body.classList.add("auth-locked");

    if (portal) {
      portal.hidden = true;
      portal.setAttribute("aria-hidden", "true");
    }

    if (loginScreen) {
      loginScreen.hidden = false;
      loginScreen.setAttribute("aria-hidden", "false");
    }

    if (password) {
      password.value = "";
      setTimeout(() => password.focus(), 50);
    }
  }

  function redirecionarRetornoSeNecessario() {
    const retorno = obterRetornoValido();
    if (!retorno) return false;

    window.location.replace(retorno);
    return true;
  }

  function iniciar() {
    const form = document.getElementById("loginForm");
    const user = document.getElementById("loginUser");
    const password = document.getElementById("loginPassword");
    const error = document.getElementById("loginError");
    const toggle = document.getElementById("togglePassword");
    const logout = document.getElementById("logoutButton");

    if (obterSessao()) {
      if (!redirecionarRetornoSeNecessario()) {
        exibirPortal();
      }
    } else {
      exibirLogin();
    }

    if (form) {
      form.addEventListener("submit", event => {
        event.preventDefault();

        const usuarioInformado = (user?.value || "").trim().toLowerCase();
        const senhaInformada = password?.value || "";

        const usuarioCorreto = usuarioInformado === AUTH.usuario;
        const senhaCorreta = hashCredential(senhaInformada) === AUTH.senhaHash;

        if (!usuarioCorreto || !senhaCorreta) {
          if (error) {
            error.textContent = "Login ou senha incorretos. Verifique os dados e tente novamente.";
          }

          if (password) {
            password.value = "";
            password.focus();
          }
          return;
        }

        if (error) error.textContent = "";
        salvarSessao();

        if (!redirecionarRetornoSeNecessario()) {
          exibirPortal();
        }
      });
    }

    if (toggle && password) {
      toggle.addEventListener("click", () => {
        const mostrando = password.type === "text";
        password.type = mostrando ? "password" : "text";
        toggle.setAttribute("aria-label", mostrando ? "Mostrar senha" : "Ocultar senha");
        toggle.title = mostrando ? "Mostrar senha" : "Ocultar senha";
        password.focus();
      });
    }

    if (logout) {
      logout.addEventListener("click", () => {
        encerrarSessao();
        exibirLogin();
      });
    }
  }

  window.Portal504Auth = {
    isAuthenticated: () => Boolean(obterSessao()),
    logout: () => {
      encerrarSessao();
      exibirLogin();
    },
    storageKey: AUTH.storageKey
  };

  iniciar();
})();
