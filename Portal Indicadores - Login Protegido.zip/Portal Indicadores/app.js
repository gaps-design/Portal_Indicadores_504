/* =========================================================
   PORTAL DE INDICADORES | LINHA 504
========================================================= */


/* =========================================================
   CAMINHOS REAIS DOS PORTAIS

   Portal Indicadores:
   N:\Packaging\Compartilhado\Retornável\
   Usuarios\Guilherme A\Portal Indicadores\

========================================================= */

const PORTAIS = {

  gente:
    "../../../01. Escala/504/Portal Gente/login.html",

  manutencao:
    "../Lobby/Portal manutenção/index_programacao_operacional.html",

  seguranca:
    "../Lobby/Portal Segurança/index_seguranca_504.html"

};


/* =========================================================
   CARDS PRINCIPAIS
========================================================= */

document
  .querySelectorAll('a[data-portal]')
  .forEach(card => {

    const portal = card.dataset.portal;

    if (PORTAIS[portal]) {
      card.href = PORTAIS[portal];
    }

  });


/* =========================================================
   MENU QUALIDADE
========================================================= */

const cardQualidade =
  document.getElementById("cardQualidade");

const qualityMenu =
  document.getElementById("qualityMenu");


if (cardQualidade && qualityMenu) {

  function alternarQualidade() {

    const aberto =
      cardQualidade.classList.toggle("open");

    cardQualidade.setAttribute(
      "aria-expanded",
      aberto ? "true" : "false"
    );

  }


  cardQualidade.addEventListener(
    "click",
    event => {

      if (
        event.target.closest(".quality-option")
      ) {
        return;
      }

      event.preventDefault();

      alternarQualidade();

    }
  );


  cardQualidade.addEventListener(
    "keydown",
    event => {

      if (
        event.key === "Enter" ||
        event.key === " "
      ) {

        event.preventDefault();

        alternarQualidade();

      }

    }
  );


  document.addEventListener(
    "click",
    event => {

      if (
        !cardQualidade.contains(event.target)
      ) {

        cardQualidade.classList.remove("open");

        cardQualidade.setAttribute(
          "aria-expanded",
          "false"
        );

      }

    }
  );


  document.addEventListener(
    "keydown",
    event => {

      if (event.key === "Escape") {

        cardQualidade.classList.remove("open");

        cardQualidade.setAttribute(
          "aria-expanded",
          "false"
        );

      }

    }
  );

}


/* =========================================================
   RELÓGIO
========================================================= */

function atualizarRelogio() {

  const clock =
    document.getElementById("clock");

  if (!clock) return;


  const d = new Date();


  const hora =
    d.toLocaleTimeString(
      "pt-BR",
      {
        hour: "2-digit",
        minute: "2-digit"
      }
    );


  const data =
    d.toLocaleDateString("pt-BR");


  clock.innerHTML =
    `<strong>${hora}</strong><br>${data}`;

}


atualizarRelogio();

setInterval(
  atualizarRelogio,
  30000
);