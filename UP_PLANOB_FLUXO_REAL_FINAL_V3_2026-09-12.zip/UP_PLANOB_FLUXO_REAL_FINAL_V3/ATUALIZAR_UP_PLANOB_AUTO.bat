@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "SRC=%~dp0ATUALIZAR_UP_PLANOB_AUTO.ps1"
set "LOCALDIR=%LOCALAPPDATA%\Portal504_Automacao\UP_PLANOB"
set "LOCALPS1=%LOCALDIR%\ATUALIZAR_UP_PLANOB_AUTO.ps1"
if not exist "%LOCALDIR%" mkdir "%LOCALDIR%" >nul 2>&1
copy /Y "%SRC%" "%LOCALPS1%" >nul
powershell.exe -NoProfile -Command "Unblock-File -LiteralPath '%LOCALPS1%' -ErrorAction SilentlyContinue" >nul 2>&1
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%LOCALPS1%"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" pause
exit /b %RC%
