@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [AVISO] Node.js nao foi encontrado. Abrindo o Portal sem automacao local.
  start "" "%~dp0index.html"
  exit /b 0
)
rem O agente fica minimizado e o Portal permanece aberto durante as automacoes.
start "Central 504" /min /D "%~dp0Central Atualizacoes" node "central_504_agent.js"
timeout /t 1 /nobreak >nul
start "" "%~dp0index.html"
endlocal
