@echo off
chcp 65001 >nul
title Guardian 504 - Node Playwright Chrome Git
cd /d "%~dp0"

echo ============================================
echo  GUARDIAN 504 - AUTOMACAO
echo  Node + Playwright + Chrome + Git
echo ============================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo ERRO: Node.js nao encontrado.
  pause
  exit /b 1
)

node -e "require('playwright'); console.log('Playwright OK')" >nul 2>&1
if errorlevel 1 (
  echo ERRO: Playwright nao encontrado nesta pasta.
  echo Coloque estes arquivos dentro de C:\Guardian504
  echo onde voce executou: npm install playwright
  pause
  exit /b 1
)

node Atualizar_Guardian_504.js
pause
