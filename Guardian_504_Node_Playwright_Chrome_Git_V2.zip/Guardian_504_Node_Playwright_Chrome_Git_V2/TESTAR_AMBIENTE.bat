@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Node:
node --version
echo.
echo NPM:
npm --version
echo.
echo Git:
git --version
echo.
echo Playwright:
node -e "const {chromium}=require('playwright'); console.log('Playwright OK')"
echo.
echo Chrome:
where chrome
echo.
pause
