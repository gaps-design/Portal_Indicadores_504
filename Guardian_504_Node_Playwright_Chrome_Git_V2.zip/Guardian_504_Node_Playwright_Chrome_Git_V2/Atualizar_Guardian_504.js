const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');
const { chromium } = require('playwright');
const { spawnSync } = require('child_process');

const BASE = __dirname;
const CFG = JSON.parse(fs.readFileSync(path.join(BASE, 'config_guardian.json'), 'utf8'));

const TIPOS = [
  { nome: 'Comportamento de Risco', endpoint: 'unsafeact', arquivo: 'Guardian_Comportamento_Risco.xlsx' },
  { nome: 'Condição de Risco', endpoint: 'unsafecondition', arquivo: 'Guardian_Condicao_Risco.xlsx' },
  { nome: 'Incidente', endpoint: 'incident', arquivo: 'Guardian_Incidente.xlsx' },
  { nome: 'Reconhecimento', endpoint: 'acknowledgments', arquivo: 'Guardian_Reconhecimento.xlsx' },
];

const sleep = ms => new Promise(r => setTimeout(r, ms));
const log = m => console.log(`[${new Date().toLocaleTimeString('pt-BR')}] ${m}`);

function pad2(n){ return String(n).padStart(2, '0'); }
function periodoAtual(){
  const d = new Date();
  return {
    inicio: `01/${pad2(d.getMonth()+1)}/${d.getFullYear()}`,
    fim: `${pad2(d.getDate())}/${pad2(d.getMonth()+1)}/${d.getFullYear()}`
  };
}

function ensureDir(p){ fs.mkdirSync(p, { recursive: true }); }

async function esperarLoginOuTela(page){
  try {
    await page.goto(CFG.guardian_url, { waitUntil: 'domcontentloaded', timeout: CFG.timeout_ms });
  } catch {}
  try {
    await page.getByText('Gerenciamento de Registros', { exact: false }).first().waitFor({ timeout: 15000 });
    return;
  } catch {
    console.log('');
    console.log('O Guardian ainda não mostrou "Gerenciamento de Registros".');
    console.log('Faça o login normalmente no Chrome aberto.');
    console.log('Quando a tela do Guardian estiver pronta, volte a este terminal e pressione ENTER.');
    await esperarEnter();
    await page.goto(CFG.guardian_url, { waitUntil: 'domcontentloaded', timeout: CFG.timeout_ms });
    await page.getByText('Gerenciamento de Registros', { exact: false }).first().waitFor({ timeout: CFG.timeout_ms });
  }
}

function esperarEnter(){
  return new Promise(resolve => {
    process.stdin.resume();
    process.stdin.once('data', () => resolve());
  });
}

async function limparFiltros(page){
  const b = page.getByRole('button', { name: 'Limpar filtros' });
  if (await b.count()) {
    try { await b.click({ timeout: 10000 }); await sleep(500); } catch {}
  }
}

async function selecionarPeriodoRequerido(page){
  let sel = page.locator('nz-select[aria-label="Período de tempo requerido"]');
  if (!(await sel.count())) sel = page.locator('[aria-label="Período de tempo requerido"]');
  await sel.first().click({ timeout: 15000 });

  let opt = page.locator('nz-option-item[title="Data em que o fato ocorreu"]');
  if (!(await opt.count())) opt = page.getByText('Data em que o fato ocorreu', { exact: true });
  await opt.last().click({ timeout: 15000 });
}

async function preencherDatas(page, inicio, fim){
  const ini = page.locator('input[placeholder="Data inicial"]').first();
  const fin = page.locator('input[placeholder="Data final"]').first();

  await ini.click();
  await ini.fill(inicio);
  await ini.press('Tab');
  await sleep(300);

  await fin.click();
  await fin.fill(fim);
  await fin.press('Tab');
  await sleep(600);
}

async function selecionarTipo(page, tipo){
  let sel = page.locator('[data-testid="register-type-multi-select-component"]');
  if (!(await sel.count())) sel = page.locator('nz-select[aria-label="Tipo de registro"]');
  await sel.first().click({ timeout: 15000 });

  let opt = page.locator(`nz-option-item[title="${tipo}"]`);
  if (!(await opt.count())) opt = page.getByText(tipo, { exact: true });
  await opt.last().click({ timeout: 15000 });
  await sleep(500);
}

async function solicitarExportacao(page, item, periodo){
  log(`Preparando ${item.nome}`);
  await limparFiltros(page);
  await selecionarPeriodoRequerido(page);
  await preencherDatas(page, periodo.inicio, periodo.fim);
  await selecionarTipo(page, item.nome);

  const buscar = page.getByRole('button', { name: 'Buscar registros' });
  const resposta = page.waitForResponse(
    r => r.url().toLowerCase().includes(item.endpoint.toLowerCase()) && r.request().method() === 'GET',
    { timeout: CFG.timeout_ms }
  ).catch(() => null);

  await buscar.click({ timeout: 15000 });
  const resp = await resposta;
  if (resp) log(`Busca ${item.nome}: HTTP ${resp.status()}`);
  else log(`Busca ${item.nome}: resposta não capturada; seguindo pela interface.`);

  const exportar = page.getByRole('button', { name: 'Exportar relatório' });
  await exportar.waitFor({ state: 'visible', timeout: CFG.timeout_ms });

  const limite = Date.now() + 90000;
  while (Date.now() < limite) {
    if (await exportar.isEnabled().catch(() => false)) break;
    await sleep(1000);
  }
  if (!(await exportar.isEnabled().catch(() => false))) {
    throw new Error(`Botão "Exportar relatório" não habilitou para ${item.nome}.`);
  }

  await sleep(800);
  await exportar.click({ timeout: 15000 });
  log(`Exportação solicitada: ${item.nome}`);
  await sleep(1200);
}

function rowMatching(page, item, periodo){
  return page.locator('tr')
    .filter({ hasText: item.nome })
    .filter({ hasText: periodo.inicio })
    .filter({ hasText: periodo.fim });
}

async function esperarRelatorioPronto(page, item, periodo){
  log(`Aguardando "${item.nome}" ficar pronto...`);
  const fim = Date.now() + CFG.download_wait_ms;

  while (Date.now() < fim) {
    await page.goto(CFG.downloads_url, { waitUntil: 'domcontentloaded', timeout: CFG.timeout_ms }).catch(()=>{});
    await sleep(900);

    const rows = rowMatching(page, item, periodo);
    const count = await rows.count();
    if (count > 0) {
      const row = rows.nth(count - 1);
      const txt = (await row.innerText().catch(()=>'' )).replace(/\s+/g, ' ');
      if (/Pronto para download/i.test(txt)) {
        const icon = row.locator('span.icon-wrapper.icon-clickable').first();
        if (await icon.count()) {
          log(`Pronto: ${item.nome}`);
          return row;
        }
      }
      if (/Falha|Erro/i.test(txt)) throw new Error(`Guardian indicou falha em ${item.nome}: ${txt}`);
    }
    await sleep(5000);
  }
  throw new Error(`Tempo esgotado aguardando ${item.nome}.`);
}

async function baixar(page, row, item){
  ensureDir(CFG.output_dir);
  const destino = path.join(CFG.output_dir, item.arquivo);
  if (fs.existsSync(destino)) {
    const bk = destino.replace(/\.xlsx$/i, `.anterior_${Date.now()}.xlsx`);
    fs.renameSync(destino, bk);
  }

  const icon = row.locator('span.icon-wrapper.icon-clickable').first();
  const dlPromise = page.waitForEvent('download', { timeout: CFG.timeout_ms });
  await icon.click({ timeout: 15000 });
  const dl = await dlPromise;
  await dl.saveAs(destino);

  const st = fs.statSync(destino);
  if (st.size < 1000) throw new Error(`Arquivo muito pequeno: ${item.arquivo}`);
  log(`Baixado: ${item.arquivo} (${(st.size/1024).toFixed(1)} KB)`);
}

async function atualizarPortal(context){
  if (!CFG.portal_enabled) {
    log('Portal automático desativado no config_guardian.json.');
    return null;
  }

  const idx = CFG.portal_index_path;
  if (!fs.existsSync(idx)) throw new Error(`Portal não encontrado: ${idx}`);

  const files = {
    act: path.join(CFG.output_dir, 'Guardian_Comportamento_Risco.xlsx'),
    incident: path.join(CFG.output_dir, 'Guardian_Incidente.xlsx'),
    recognition: path.join(CFG.output_dir, 'Guardian_Reconhecimento.xlsx'),
    condition: path.join(CFG.output_dir, 'Guardian_Condicao_Risco.xlsx'),
  };
  Object.values(files).forEach(f => { if (!fs.existsSync(f)) throw new Error(`Relatório ausente: ${f}`); });

  log('Abrindo Portal Segurança para atualização...');
  const p = await context.newPage();
  await p.goto(pathToFileURL(idx).href, { waitUntil: 'domcontentloaded', timeout: CFG.timeout_ms });

  await p.locator('#fileAct').setInputFiles(files.act);
  await p.locator('#fileIncident').setInputFiles(files.incident);
  await p.locator('#fileRecognition').setInputFiles(files.recognition);
  await p.locator('#fileCondition').setInputFiles(files.condition);

  await p.locator('#processUploads').click();
  await p.waitForFunction(() => {
    const el = document.querySelector('#uploadStatus');
    return el && /Concluída/i.test(el.textContent || '');
  }, { timeout: 120000 });

  log('Portal processou os 4 relatórios.');

  const dlPromise = p.waitForEvent('download', { timeout: 60000 });
  await p.locator('#generateIndex').click();
  const dl = await dlPromise;

  const temp = path.join(path.dirname(idx), `__novo_${Date.now()}.html`);
  await dl.saveAs(temp);

  const stamp = new Date().toISOString().replace(/[:.]/g,'-');
  const backup = idx.replace(/\.html$/i, `_BACKUP_${stamp}.html`);
  fs.copyFileSync(idx, backup);
  fs.copyFileSync(temp, idx);
  fs.unlinkSync(temp);

  log(`Portal atualizado: ${idx}`);
  log(`Backup: ${backup}`);
  await p.close();
  return idx;
}

function gitCmd(args, cwd){
  const r = spawnSync('git', args, { cwd, encoding: 'utf8', shell: false });
  if (r.stdout) process.stdout.write(r.stdout);
  if (r.stderr) process.stderr.write(r.stderr);
  return r;
}

function publicarGit(){
  if (!CFG.git_enabled) {
    log('Git automático desativado no config_guardian.json.');
    return;
  }
  const repo = CFG.git_repo_dir;
  if (!fs.existsSync(path.join(repo, '.git'))) throw new Error(`Não é repositório Git: ${repo}`);

  gitCmd(['add','-A'], repo);
  const msg = `Atualiza Guardian 504 - ${new Date().toLocaleString('pt-BR')}`;
  const commit = gitCmd(['commit','-m',msg], repo);
  if (commit.status !== 0 && !/nothing to commit|nothing added/i.test((commit.stdout||'')+(commit.stderr||''))) {
    throw new Error('Falha no git commit.');
  }

  const push = gitCmd(['push','origin',CFG.git_branch || 'main'], repo);
  if (push.status !== 0) throw new Error('Falha no git push.');
  log('Git/GitHub concluído.');
}

async function main(){
  const periodo = periodoAtual();
  ensureDir(CFG.output_dir);
  ensureDir(CFG.chrome_profile_dir);

  console.log('============================================================');
  console.log(' GUARDIAN 504 - NODE + PLAYWRIGHT + CHROME + GIT');
  console.log('============================================================');
  log(`Período: ${periodo.inicio} até ${periodo.fim}`);

  const context = await chromium.launchPersistentContext(CFG.chrome_profile_dir, {
    channel: 'chrome',
    headless: false,
    acceptDownloads: true,
    viewport: null,
    args: ['--start-maximized']
  });
  const page = context.pages()[0] || await context.newPage();

  try {
    await esperarLoginOuTela(page);

    for (const item of TIPOS) {
      await page.goto(CFG.guardian_url, { waitUntil: 'domcontentloaded', timeout: CFG.timeout_ms });
      await solicitarExportacao(page, item, periodo);
    }

    log('As 4 exportações foram solicitadas. Indo para Downloads...');
    for (const item of TIPOS) {
      const row = await esperarRelatorioPronto(page, item, periodo);
      await baixar(page, row, item);
    }

    log('Os 4 relatórios foram baixados.');
    await atualizarPortal(context);
    publicarGit();

    console.log('');
    log('=== SUCESSO ===');
    log(`Relatórios: ${CFG.output_dir}`);
    console.log('');
    console.log('Pressione ENTER para fechar.');
    await esperarEnter();
  } catch (e) {
    console.error('');
    console.error('=== FALHA ===');
    console.error(e && e.stack ? e.stack : e);
    console.error('');
    console.error('O Chrome ficará aberto para você ver onde o fluxo parou.');
    console.error('Pressione ENTER para encerrar.');
    await esperarEnter();
  } finally {
    await context.close().catch(()=>{});
  }
}

main();
