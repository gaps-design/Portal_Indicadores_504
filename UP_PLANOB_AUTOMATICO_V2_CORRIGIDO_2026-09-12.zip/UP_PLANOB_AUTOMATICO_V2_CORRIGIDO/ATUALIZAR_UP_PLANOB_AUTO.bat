@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "PS1=%~dp0ATUALIZAR_UP_PLANOB_AUTO.ps1"
if not exist "%PS1%" (
  echo ERRO: Script PowerShell nao encontrado:
  echo %PS1%
  pause
  exit /b 1
)
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%PS1%"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo O Plano B do UP terminou com erro. Veja a mensagem acima.
  pause
)
exit /b %RC%
