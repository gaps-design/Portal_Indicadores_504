'use strict';

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFileSync } = require('child_process');
const { pathToFileURL } = require('url');

const ROOT = __dirname;
const config = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
const MODE = (process.argv[2] || 'full').toLowerCase();
const LOG_DIR = path.join(ROOT, 'logs');
const PROFILE_DIR = path.join(ROOT, 'chrome_profile_tpo');
fs.mkdirSync(LOG_DIR, { recursive: true });
fs.mkdirSync(PROFILE_DIR, { recursive: true });

const TIMEOUT = Number(config.tempoMaximoPassoMs || 30000);
const LOGIN_TIMEOUT = Number(config.tempoMaximoLoginMs || 180000);
const downloadsDir = path.join(os.homedir(), 'Downloads');

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function nowStamp() {
  const d = new Date();
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}
function log(msg) { console.log(`[TPO] ${msg}`); }
function step(n, total, msg) { console.log(`\n[${n}/${total}] ${msg}`); }
function currentMonthLabel() {
  return ['JAN','FEV','MAR','ABR','MAI','JUN','JUL','AGO','SET','OUT','NOV','DEZ'][new Date().getMonth()];
}
function ymd(d) {
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`;
}
function dmy(d) {
  const p = n => String(n).padStart(2, '0');
  return `${p(d.getDate())}/${p(d.getMonth()+1)}/${d.getFullYear()}`;
}
function newestExcelInDownloads(afterMs) {
  const exts = new Set(['.xlsx','.xls']);
  const rows = fs.readdirSync(downloadsDir)
    .map(name => ({ name, full: path.join(downloadsDir,name) }))
    .filter(x => exts.has(path.extname(x.name).toLowerCase()))
    .map(x => ({ ...x, st: fs.statSync(x.full) }))
    .filter(x => x.st.mtimeMs >= afterMs - 5000)
    .sort((a,b) => b.st.mtimeMs - a.st.mtimeMs);
  return rows[0]?.full || null;
}
async function saveDebug(page, label) {
  if (!page) return;
  const file = path.join(LOG_DIR, `${nowStamp()}_${label.replace(/[^a-z0-9_-]+/gi,'_')}.png`);
  try {
    await page.screenshot({ path: file, fullPage: true });
    log(`Imagem de diagnóstico salva em: ${file}`);
  } catch (_) {}
}
async function waitVisible(locator, timeout=TIMEOUT) {
  await locator.waitFor({ state: 'visible', timeout });
  return locator;
}
async function clickText(page, text, opts={}) {
  const loc = page.getByText(text, { exact: !!opts.exact }).filter({ visible: true }).first();
  await waitVisible(loc, opts.timeout || TIMEOUT);
  await loc.click();
}
async function clickButtonByText(page, text, timeout=TIMEOUT) {
  const re = typeof text === 'string' ? new RegExp(text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i') : text;
  const btn = page.getByRole('button', { name: re }).first();
  await waitVisible(btn, timeout);
  await btn.click();
}

async function ensureAthenaLogin(page) {
  // O Athena pode abrir diretamente em Relatórios quando a sessão corporativa já existe.
  if (await page.getByText('Relatórios', { exact: true }).count()) return;

  const sso = page.locator('#btn-sso').first();
  if (await sso.count()) {
    log('Botão SSO encontrado. Clicando em "Acesse Aqui"...');
    await sso.click();
  } else {
    const byText = page.getByRole('button', { name: /Acesse Aqui/i }).first();
    if (await byText.count()) await byText.click();
  }

  log('Aguardando autenticação corporativa. Se aparecer MFA/login, conclua manualmente nesta janela.');
  const deadline = Date.now() + LOGIN_TIMEOUT;
  while (Date.now() < deadline) {
    if (await page.getByText('Relatórios', { exact: true }).count()) return;
    if (/relatorios/i.test(page.url())) return;
    await sleep(1000);
  }
  throw new Error('Tempo excedido aguardando o login do Athena.');
}

async function openReports(page) {
  if (/relatorios/i.test(page.url())) return;
  const menu = page.getByText('Relatórios', { exact: true }).first();
  if (await menu.count()) {
    await menu.click();
    await sleep(1200);
    return;
  }
  await page.goto(config.athenaUrl, { waitUntil: 'domcontentloaded', timeout: LOGIN_TIMEOUT });
}

async function findAndOpenReport(page) {
  const name = config.relatorioNome;
  const code = name.split(' ')[0];

  // Usa a busca para reduzir a lista.
  const search = page.locator('input[placeholder*="Buscar" i]').first();
  if (await search.count()) {
    await search.fill(code);
    await search.press('Enter').catch(()=>{});
    await sleep(1200);
  }

  const txt = page.getByText(name, { exact: false }).first();
  await txt.waitFor({ state: 'visible', timeout: TIMEOUT });

  // O Athena mostra, na linha do relatório, ações como editar/excluir/emitir.
  // Na V1 o script podia parar no primeiro link do nome do relatório e abrir
  // a janela de "Clonar". Aqui subimos até o container que possui TODAS as
  // ações e priorizamos explicitamente o ícone de lupa/pesquisa/visualização.
  const info = await txt.evaluate((el) => {
    let p = el;
    let best = null;
    let bestControls = [];

    for (let i = 0; i < 12 && p; i++, p = p.parentElement) {
      const controls = [...p.querySelectorAll('button,a,[role="button"]')].filter(x => {
        const r = x.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      });

      // Preferimos o primeiro ancestral que reúna pelo menos 3 ações da linha.
      if (controls.length >= 3) {
        best = p;
        bestControls = controls;
        break;
      }
      if (controls.length > bestControls.length) {
        best = p;
        bestControls = controls;
      }
    }

    if (!best || !bestControls.length) return { ok:false, reason:'sem controles' };

    const textOf = (x) => [
      x.innerText || '',
      x.getAttribute('title') || '',
      x.getAttribute('aria-label') || '',
      x.getAttribute('data-original-title') || '',
      x.className || '',
      x.innerHTML || ''
    ].join(' ').toLowerCase();

    const scored = bestControls.map((x, idx) => {
      const t = textOf(x);
      const r = x.getBoundingClientRect();
      let score = 0;
      if (/fa-search|pi-search|search|magnif|lupa/.test(t)) score += 500;
      if (/visualiz|pesquis|emitir|export|executar|abrir relat/.test(t)) score += 250;
      if (/edit|editar|pencil|clone|clonar/.test(t)) score -= 400;
      if (/trash|delete|excluir|lixeira/.test(t)) score -= 400;
      // Empate: nas linhas do Athena a lupa fica à direita.
      score += r.left / 10000;
      return { x, idx, score, left:r.left, meta:t.slice(0,180) };
    }).sort((a,b) => b.score - a.score);

    const chosen = scored[0];
    chosen.x.click();
    return { ok:true, idx:chosen.idx, score:chosen.score, meta:chosen.meta, controls:bestControls.length };
  });

  log(`Ação do relatório acionada (controles=${info.controls || 0}, índice=${info.idx ?? '?'}, score=${info.score ?? '?'}).`);
  await sleep(1200);

  // Confirma que abrimos a tela correta de emissão/exportação.
  const exportBtn = page.getByRole('button', { name: /^Exportar$/i }).last();
  if (await exportBtn.count()) return;

  // Se ainda assim o Athena abriu a tela de Clonar/Editar, desfazemos e
  // tentamos especificamente a ação mais à direita da linha (lupa).
  const cloneBtn = page.getByRole('button', { name: /^Clonar$/i }).first();
  if (await cloneBtn.count()) {
    log('Athena abriu a janela de Clonar. Fechando e tentando a lupa da linha...');
    const cancelar = page.getByRole('button', { name: /^Cancelar$/i }).last();
    if (await cancelar.count()) await cancelar.click();
    else await page.keyboard.press('Escape').catch(()=>{});
    await sleep(600);

    const txt2 = page.getByText(name, { exact: false }).first();
    const fallback = await txt2.evaluate((el) => {
      let p = el;
      let candidate = null;
      for (let i = 0; i < 12 && p; i++, p = p.parentElement) {
        const controls = [...p.querySelectorAll('button,a,[role="button"]')].filter(x => {
          const r = x.getBoundingClientRect();
          return r.width > 0 && r.height > 0;
        });
        if (controls.length >= 3) {
          candidate = controls
            .map(x => ({x, r:x.getBoundingClientRect()}))
            .sort((a,b) => b.r.left - a.r.left)[0]?.x || null;
          break;
        }
      }
      if (!candidate) return false;
      candidate.click();
      return true;
    });
    if (!fallback) throw new Error('Não consegui localizar a lupa do relatório 96192.');
    await sleep(1200);
  }

  await exportBtn.waitFor({ state: 'visible', timeout: TIMEOUT }).catch(()=>{});
  if (!(await exportBtn.count())) {
    throw new Error('O relatório foi localizado, mas a janela de Exportar não abriu.');
  }
}

async function setNativeDate(input, value) {
  await input.evaluate((el, v) => {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }, value);
}

async function selectPackaging(page) {
  const value = config.areaFuncional;

  // Primeiro tenta localizar o input dentro do bloco que contém "Área Funcional".
  let areaInput = page.locator('input:not([type="date"]):visible').first();
  const areaLabel = page.getByText(/Área Funcional/i).first();
  if (await areaLabel.count()) {
    const candidate = areaLabel.locator('xpath=ancestor::*[self::div or self::label][1]//input[not(@type="date")]').first();
    if (await candidate.count()) areaInput = candidate;
  }

  await areaInput.click();
  await areaInput.fill(value).catch(()=>{});
  await sleep(600);

  // Opção do autocomplete.
  const option = page.getByText(new RegExp(`^${value}$`, 'i')).last();
  if (await option.count()) {
    await option.click();
  } else {
    await areaInput.press('ArrowDown').catch(()=>{});
    await areaInput.press('Enter').catch(()=>{});
  }
  await sleep(500);
}

async function configureReport(page) {
  const today = new Date();
  const first = new Date(today.getFullYear(), today.getMonth(), 1);

  const dataInicio = page.getByText('Data Início', { exact: false }).first();
  if (await dataInicio.count()) await dataInicio.click().catch(()=>{});

  const dateInputs = page.locator('input[type="date"]:visible');
  const count = await dateInputs.count();
  if (count < 2) throw new Error(`Não encontrei os dois campos de data no relatório (encontrei ${count}).`);
  await setNativeDate(dateInputs.nth(0), ymd(first));
  await setNativeDate(dateInputs.nth(1), ymd(today));
  log(`Período configurado: ${dmy(first)} até ${dmy(today)}.`);

  await selectPackaging(page);
  log('Área Funcional configurada como Packaging. Linha NÃO será preenchida no TPO.');
}

async function exportAthena(page) {
  const start = Date.now();
  const exportBtn = page.getByRole('button', { name: /^Exportar$/i }).last();
  await exportBtn.waitFor({ state: 'visible', timeout: TIMEOUT });

  const [download] = await Promise.all([
    page.waitForEvent('download', { timeout: 120000 }),
    exportBtn.click()
  ]);

  const suggested = download.suggestedFilename() || `TPO_${ymd(new Date())}.xlsx`;
  let filename = suggested;
  if (!/\.xlsx?$/i.test(filename)) filename += '.xlsx';
  const target = path.join(downloadsDir, filename);
  try { if (fs.existsSync(target)) fs.rmSync(target, { force: true }); } catch (_) {}
  await download.saveAs(target);
  await download.path().catch(()=>null);

  if (!fs.existsSync(target) || fs.statSync(target).size < 1000) {
    const fallback = newestExcelInDownloads(start);
    if (fallback) return fallback;
    throw new Error('O Athena iniciou a exportação, mas o Excel não apareceu corretamente em Downloads.');
  }
  return target;
}

function copyExcelToText(excelPath) {
  const temp = path.join(os.tmpdir(), `tpo_clipboard_${Date.now()}.txt`);
  const ps = path.join(ROOT, 'copiar_excel.ps1');
  execFileSync('powershell.exe', [
    '-NoProfile','-STA','-ExecutionPolicy','Bypass','-File', ps,
    '-Arquivo', excelPath,
    '-Saida', temp
  ], { stdio: 'inherit', windowsHide: false });

  if (!fs.existsSync(temp)) throw new Error('O PowerShell não gerou o texto copiado do Excel.');
  const text = fs.readFileSync(temp, 'utf8').replace(/^\uFEFF/, '');
  try { fs.rmSync(temp, { force: true }); } catch (_) {}
  if (!text.trim()) throw new Error('O Excel foi copiado, mas o conteúdo ficou vazio.');
  return text;
}

async function openTpo(page) {
  const portalPath = config.portalTpoPath;
  if (!fs.existsSync(portalPath)) throw new Error(`Index do Portal TPO não encontrado: ${portalPath}`);
  await page.goto(pathToFileURL(portalPath).href, { waitUntil: 'domcontentloaded', timeout: LOGIN_TIMEOUT });
  await sleep(1200);

  // O guard do portal pode redirecionar para o login central.
  const deadline = Date.now() + LOGIN_TIMEOUT;
  while (Date.now() < deadline) {
    if (await page.locator('button[data-page="update"]').count()) return;
    if (/portal indicadores/i.test((await page.title().catch(()=>''))) || /retorno=/i.test(page.url())) {
      log('O Portal TPO pediu o login central. Faça o login manualmente; o script continuará sozinho depois.');
    }
    await sleep(1000);
  }
  throw new Error('Não consegui abrir o Portal TPO após aguardar o login central.');
}

async function updateTpo(page, pastedText) {
  await page.locator('button[data-page="update"]').click();
  await page.locator('#update').waitFor({ state: 'visible', timeout: TIMEOUT });

  const month = currentMonthLabel();
  await page.locator('#importMonth').selectOption({ label: month }).catch(async()=>{
    await page.locator('#importMonth').selectOption(month);
  });
  log(`Mês de destino selecionado: ${month}.`);

  await page.locator('#pasteBox').evaluate((el, value) => {
    el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }, pastedText);

  await page.locator('#analyzePaste').click();
  await sleep(1200);
  let msg = (await page.locator('#importMsg').innerText().catch(()=>'')) || '';
  if (/erro|inválid|não reconhe|antes\./i.test(msg)) {
    throw new Error(`O Portal TPO não aceitou o relatório ao analisar. Mensagem: ${msg}`);
  }

  page.once('dialog', async dialog => {
    log(`Confirmação do Portal TPO: ${dialog.message()}`);
    await dialog.accept();
  });
  await page.locator('#replaceMonth').click();

  const deadline = Date.now() + TIMEOUT;
  while (Date.now() < deadline) {
    msg = (await page.locator('#importMsg').innerText().catch(()=>'')) || '';
    if (/atualizado com segurança|foi atualizado/i.test(msg)) break;
    if (/erro|inválid|falha/i.test(msg)) throw new Error(`Falha ao atualizar mês no Portal TPO: ${msg}`);
    await sleep(500);
  }
  if (!/atualizado com segurança|foi atualizado/i.test(msg)) {
    throw new Error(`O Portal TPO não confirmou a atualização do mês. Mensagem atual: ${msg}`);
  }
  log(msg.replace(/\s+/g,' ').trim());
}

function validateIndex(file) {
  if (!fs.existsSync(file)) throw new Error(`Novo index não encontrado: ${file}`);
  const st = fs.statSync(file);
  if (st.size < 100000) throw new Error(`Novo index.html parece incompleto (${st.size} bytes).`);
  const head = fs.readFileSync(file, 'utf8');
  if (!/PORTAL TPO|Portal TPO/i.test(head) || !/DATA_START|let DATA=/i.test(head)) {
    throw new Error('O arquivo gerado não passou na validação básica do Portal TPO.');
  }
}

function replaceProductionIndex(newIndex) {
  validateIndex(newIndex);
  const dest = config.portalTpoPath;
  const dir = path.dirname(dest);
  const tempDest = path.join(dir, 'index.__novo__.html');
  const oldTemp = path.join(dir, 'index.__anterior__.html');

  try { fs.rmSync(tempDest, { force: true }); } catch (_) {}
  try { fs.rmSync(oldTemp, { force: true }); } catch (_) {}

  fs.copyFileSync(newIndex, tempDest);
  validateIndex(tempDest);

  if (fs.existsSync(dest)) fs.renameSync(dest, oldTemp);
  try {
    fs.renameSync(tempDest, dest);
    validateIndex(dest);
    if (fs.existsSync(oldTemp)) fs.rmSync(oldTemp, { force: true });
    fs.rmSync(newIndex, { force: true });
  } catch (err) {
    if (!fs.existsSync(dest) && fs.existsSync(oldTemp)) fs.renameSync(oldTemp, dest);
    throw err;
  }
}

async function generateAndReplaceIndex(page) {
  const downloadPath = path.join(downloadsDir, 'index.html');
  try { fs.rmSync(downloadPath, { force: true }); } catch (_) {}

  const [download] = await Promise.all([
    page.waitForEvent('download', { timeout: 120000 }),
    page.locator('#generateIndex').click()
  ]);
  await download.saveAs(downloadPath);
  validateIndex(downloadPath);
  replaceProductionIndex(downloadPath);
}

async function main() {
  const total = MODE === 'athena' ? 6 : MODE === 'portal' ? 6 : 12;
  let browser = null;
  let page = null;
  let downloadedExcel = null;
  try {
    step(1, total, 'Abrindo Chrome controlado pela automação...');
    browser = await chromium.launchPersistentContext(PROFILE_DIR, {
      channel: config.browserChannel || 'chrome',
      headless: false,
      acceptDownloads: true,
      viewport: null,
      args: ['--start-maximized']
    });
    page = browser.pages()[0] || await browser.newPage();
    page.setDefaultTimeout(TIMEOUT);

    if (MODE !== 'portal') {
      step(2, total, 'Abrindo Athena...');
      await page.goto(config.athenaUrl, { waitUntil: 'domcontentloaded', timeout: LOGIN_TIMEOUT });
      await ensureAthenaLogin(page);

      step(3, total, 'Abrindo Relatórios...');
      await openReports(page);

      step(4, total, `Localizando ${config.relatorioNome}...`);
      await findAndOpenReport(page);

      step(5, total, 'Configurando período do mês atual e Área Funcional = Packaging...');
      await configureReport(page);

      step(6, total, 'Exportando Excel do Athena para Downloads...');
      downloadedExcel = await exportAthena(page);
      log(`Excel baixado: ${downloadedExcel}`);

      if (MODE === 'athena') {
        log('TESTE ATHENA concluído. O relatório foi baixado e nenhuma alteração foi feita no Portal TPO.');
        return;
      }
    } else {
      // Modo de teste do portal: usa o Excel mais recente de Downloads.
      downloadedExcel = newestExcelInDownloads(0);
      if (!downloadedExcel) throw new Error('Não encontrei nenhum .xlsx/.xls em Downloads para testar o Portal TPO.');
      step(2, total, `Usando o Excel mais recente de Downloads: ${path.basename(downloadedExcel)}`);
    }

    const baseStep = MODE === 'portal' ? 3 : 7;
    step(baseStep, total, 'Abrindo Excel, selecionando todos os dados e copiando...');
    const pastedText = copyExcelToText(downloadedExcel);
    log(`Dados copiados do Excel: ${pastedText.length.toLocaleString('pt-BR')} caracteres.`);

    step(baseStep + 1, total, 'Abrindo o index.html atual do Portal TPO...');
    await openTpo(page);

    step(baseStep + 2, total, `Atualizar Base -> ${currentMonthLabel()} -> colar -> Analisar relatório...`);
    await updateTpo(page, pastedText);

    step(baseStep + 3, total, 'Gerando o novo index.html...');
    await generateAndReplaceIndex(page);

    step(baseStep + 4, total, 'Validando o index.html substituído na pasta do Portal TPO...');
    validateIndex(config.portalTpoPath);

    step(baseStep + 5, total, 'CONCLUÍDO COM SUCESSO.');
    log(`Portal atualizado: ${config.portalTpoPath}`);
  } catch (err) {
    console.error(`\nERRO: ${err.message}`);
    await saveDebug(page, 'erro');
    console.error('\nA versão antiga do index.html não é removida se o novo arquivo não passar na validação.');
    process.exitCode = 1;
    if (page) {
      log('A janela ficará aberta por 60 segundos para você fotografar a tela/DevTools se precisar.');
      await sleep(60000).catch(()=>{});
    }
  } finally {
    if (browser && !config.manterBrowserAbertoAoFinal) {
      try { await browser.close(); } catch (_) {}
    }
  }
}

main();
